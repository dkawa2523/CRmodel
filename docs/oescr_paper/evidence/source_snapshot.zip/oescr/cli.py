"""Installed command-line entry point for the ordinary OESCR workflows."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Sequence

from . import __version__


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="oescr", description="Run or validate an OESCR research model.")
    parser.add_argument("--version", action="version", version=f"oescr {__version__}")
    commands = parser.add_subparsers(dest="command", required=True)
    validate = commands.add_parser("validate", help="Validate a project and its referenced inputs.")
    validate.add_argument("project_yaml")
    for name, help_text in (
        ("run", "Run a project; defaults to inverse when configured, otherwise forward."),
        ("forward", "Predict spectra from a case."),
        ("inverse", "Fit measurements using a case and inverse configuration."),
    ):
        command = commands.add_parser(name, help=help_text)
        command.add_argument("project_yaml" if name == "run" else "case_yaml")
        if name == "run":
            command.add_argument("--task", choices=["forward", "inverse"])
        elif name == "inverse":
            command.add_argument("inverse_yaml")
        command.add_argument("--out", default=None if name == "run" else f"{name}_output")
        command.add_argument("--audit", action="store_true", help="Add optional final scientific audits.")
        if name != "forward":
            command.add_argument("--record-trace", action="store_true", help="Record inverse objective evaluations.")
    return parser


def _validate_project(path: str) -> None:
    from .forward.model import OESCRModel
    from .inverse.optimize import InverseSolver
    from .io.project import load_project
    from .io.yaml_loader import load_yaml

    project = load_project(path)
    inverse = project.load_inverse_config()
    solver = InverseSolver(load_yaml(project.case_yaml), inverse) if inverse is not None else None
    model = solver.model if solver is not None else OESCRModel.from_yaml(project.case_yaml)
    print(f"Project: {project.name}")
    print(f"Case YAML: {project.case_yaml}")
    print(f"Default output: {project.default_output_dir}")
    print(f"Capabilities: {model.capabilities()}")
    print(f"Instruments: {[item['id'] for item in model.instrument_configs_for()]}")
    if solver is not None:
        print(f"Inverse: {project.inverse_yaml or 'inline'}")
        print(f"Parameter count: {len(solver.params.params)}")
        print(f"Measurement groups: {list(solver.measurements)}")
        print(f"Selected windows: {len(solver.windows)}")


def _execute(args: argparse.Namespace) -> int:
    from .io.yaml_loader import load_yaml

    if args.command == "validate":
        _validate_project(args.project_yaml)
        return 0

    if args.command == "run":
        from .io.project import load_project

        project = load_project(args.project_yaml)
        task = args.task or (
            "inverse" if project.inverse_yaml is not None or project.inline_inverse is not None else "forward"
        )
        case_path = project.case_yaml
        inverse = project.load_inverse_config() if task == "inverse" else None
        output = Path(args.out).resolve() if args.out else project.default_output_dir
    else:
        task = args.command
        case_path = Path(args.case_yaml)
        inverse = load_yaml(args.inverse_yaml) if task == "inverse" else None
        output = Path(args.out)

    if task == "forward":
        from .forward.model import OESCRModel
        from .forward.reporting import write_forward_spectra

        model = OESCRModel.from_yaml(case_path)
        result = model.predict() if args.audit else None
        spectra = result.spectra if result is not None else model.predict_spectra()
        write_forward_spectra(spectra, output, diagnostics=result)
    else:
        from .inverse.optimize import InverseSolver
        from .inverse.reporting import write_fit_result

        if inverse is None:
            raise ValueError("Project manifest has no inverse configuration.")
        solver = InverseSolver(load_yaml(case_path), inverse)
        fit = solver.fit(record_trace=args.record_trace, audit=args.audit)
        write_fit_result(fit, output)
        if not fit.success:
            print(f"Inverse results were saved, but optimization did not converge: {output}", file=sys.stderr)
            return 1
    if args.command == "run":
        print(f"Project task '{task}' completed: {output}")
    else:
        print(f"{task.capitalize()} results written to: {output}")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    """Parse arguments and report expected input errors without a traceback."""

    args = _parser().parse_args(argv)
    # Keep help and version usable without importing the numerical workflows.
    from yaml import YAMLError

    from .physics.quality import DiagnosticPolicyError

    try:
        return _execute(args)
    except (ValueError, OSError, YAMLError, DiagnosticPolicyError) as exc:
        print(f"oescr: {exc}", file=sys.stderr)
        return 2
