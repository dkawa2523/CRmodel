"""Support ``python -m oescr`` alongside the installed console command."""

from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
