"""Configuration normalization.

These helpers convert compact, user-friendly YAML into the canonical internal
format consumed by the forward and inverse solvers. The normalization layer is
where we reduce input duplication and preserve backward compatibility.
"""

from __future__ import annotations

from hashlib import sha256
from pathlib import Path
from typing import Any, Dict, Iterable, List

from .pathmap import get_path
from .species_packs import compose_species_packs
from .yaml_loader import deep_merge, resolve_path

_CASE_DEFAULTS: Dict[str, Any] = {
    "plasma_mode": "te",
    "emission_mode": "physical",
    "energy_grid": {"min_eV": 0.0, "max_eV": 50.0, "n_points": 800},
    "numerics": {"wavelength_refinement_factor": 1.0},
    "geometry": {"mode": "axisym_shell", "n_shells": 1},
    "plasma_state": {"metastables": {}, "radicals": {}},
    "residuals": {"mode": "off", "species_density_m3": {}},
    "wall": {"gamma": {}},
}

_INVERSE_DEFAULTS: Dict[str, Any] = {
    "inference_mode": "relative_shape",
    # The ordinary inverse path always owns wavelength selection.  Keeping the
    # default here prevents case-level diagnostic windows from silently
    # changing the numerical objective.
    "window_selection": {"mode": "full_spectrum"},
    "fit": {
        "objective": {
            "spectrum_weight": 1.0,
            "window_fit_weight": 0.0,
            "window_fit_normalization": "area",
            "window_baseline_mode": "local_linear",
            "area_weight": 0.0,
            "peak_weight": 0.0,
            "auto_gain_fit": True,
            "auto_offset_fit": True,
            "auto_gain_tilt_fit": False,
            "auto_gain_scope": "chord",
            "gain_prior_weight": 0.0,
            "gain_prior_sigma_log10": 1.0,
            "gain_tilt_prior_weight": 0.0,
            "gain_tilt_prior_sigma": 1.0,
            "window_ratio_weight": 0.0,
            "window_ratio_metric": "peak",
            "window_ratio_min_relative_signal": 0.02,
            "window_min_relative_signal": 0.02,
            "window_ratio_pairs": [],
        },
        "global": {"enabled": False, "maxiter": 20, "popsize": 8, "seed": 0, "tol": 1.0e-3},
        "local": {"enabled": True, "max_nfev": 200},
        "uncertainty": {"laplace": True},
        "identifiability": {"enabled": True, "rank_rtol": 1.0e-8},
        "profile": {"enabled": False, "max_nfev": 100, "parameters": []},
        "regularization": {"smooth_arrays": []},
    },
    "measurements": [],
    "parameters": [],
    "parameter_groups": [],
    "priors": [],
}

_INVERSE_MODE_DEFAULTS: Dict[str, Dict[str, Any]] = {
    "calibrated_absolute": {
        "fit": {
            "objective": {
                "auto_gain_fit": False,
                "auto_offset_fit": False,
                "auto_gain_tilt_fit": False,
            }
        }
    }
}


def _migrate_legacy_cr_sections(case_cfg: Dict[str, Any]) -> None:
    """Translate legacy loss lists into the canonical reaction process model."""

    reactions = case_cfg.setdefault("reactions", [])
    for index, quenching in enumerate(case_cfg.pop("quenching", [])):
        state = str(quenching["state"])
        collider = str(quenching["collider"])
        reactions.append(
            {
                "id": f"legacy_quenching_{index}_{state}_{collider}",
                "kind": "two_body",
                "source_state": state,
                "colliders": [collider],
                "coefficient_m3_s": float(quenching["rate_coefficient_m3_s"]),
            }
        )
    for index, loss in enumerate(case_cfg.pop("losses", [])):
        state = str(loss["state"])
        reactions.append(
            {
                "id": f"legacy_loss_{index}_{state}",
                "kind": "first_order",
                "source_state": state,
                "coefficient_s-1": float(loss["rate_coefficient_s-1"]),
            }
        )


def normalize_composed_case_config(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize a case whose species packs have already been expanded.

    This is the canonicalization boundary used by the compiler.  Keeping pack
    composition out of this function prevents validation and normalization
    from reloading the same pack several times during one compile.
    """

    out = deep_merge(_CASE_DEFAULTS, cfg)
    if "eedf" in cfg and "plasma_mode" not in cfg:
        out.pop("plasma_mode", None)
    out.setdefault("states", [])
    out.setdefault("reactions", [])
    out.setdefault("transitions", [])
    out.setdefault("bands", [])
    out.setdefault("instruments", [])
    out.setdefault("gas_mixture", {})
    out["plasma_state"].setdefault("metastables", {})
    out["plasma_state"].setdefault("radicals", {})
    out["residuals"].setdefault("species_density_m3", {})
    _migrate_legacy_cr_sections(out)
    return out


def normalize_case_config(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Expand species packs and return the canonical case configuration.

    This public compatibility entry point accepts raw user configuration.
    Compilers that already own pack composition should call
    :func:`normalize_composed_case_config` instead.
    """

    composed, _ = compose_species_packs(cfg)
    return normalize_composed_case_config(composed)


# ---- inverse normalization helpers -----------------------------------------------------------


def _iter_indices(indices_cfg: Any, arr: Iterable[Any]) -> List[int]:
    arr_list = list(arr)
    if indices_cfg is None or isinstance(indices_cfg, str) and indices_cfg in {"all", "*"}:
        return list(range(len(arr_list)))
    return [int(i) for i in indices_cfg]


_GROUP_TEMPLATES = {"shell_array", "array", "radial_array"}


def expand_parameter_groups(case_cfg: Dict[str, Any], inv_cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
    explicit = list(inv_cfg.get("parameters", []))
    groups = inv_cfg.get("parameter_groups", [])
    if not groups:
        return explicit

    out = list(explicit)
    for group in groups:
        template = str(group.get("template", "shell_array"))
        if template not in _GROUP_TEMPLATES:
            raise ValueError(f"Unsupported parameter group template: {template}")
        path = str(group["path"])
        arr = get_path(case_cfg, path)
        indices = _iter_indices(group.get("indices", "all"), arr)
        name_prefix = str(group.get("name_prefix", path.split(".")[-1]))
        scale = str(group.get("scale", "linear"))
        role = str(group.get("role", "target"))
        bounds = [float(group["bounds"][0]), float(group["bounds"][1])]
        suffix_fmt = str(group.get("suffix_format", "{index}"))
        for idx in indices:
            out.append(
                {
                    "name": f"{name_prefix}{suffix_fmt.format(index=idx)}",
                    "path": f"{path}[{idx}]",
                    "scale": scale,
                    "role": role,
                    "bounds": bounds,
                }
            )
    return out


def _normalize_regularization(inv_cfg: Dict[str, Any]) -> None:
    regs = inv_cfg.setdefault("fit", {}).setdefault("regularization", {}).setdefault("smooth_arrays", [])
    for reg in regs:
        if "path" not in reg and "name" in reg:
            reg["path"] = f"plasma_state.{reg['name']}"


def _measurement_source_paths(inv_cfg: Dict[str, Any], item: Dict[str, Any]) -> tuple[List[Path], bool]:
    """Resolve one measurement entry without assigning prediction semantics.

    The boolean identifies the singular ``file`` form.  Keeping the distinction
    makes the user contract unambiguous: singular entries use ``id`` and
    ``prediction_key``; plural entries use ``ids`` and either one shared
    ``prediction_key`` or one ``prediction_keys`` entry per file.
    """

    source_fields = [field for field in ("file", "files", "files_glob") if field in item]
    if len(source_fields) != 1:
        raise ValueError(
            "Measurement entry must define exactly one of file, files, or files_glob; "
            f"found {source_fields or 'none'}."
        )
    base_dir = Path(inv_cfg.get("__base_dir__", "."))
    if "files_glob" in item:
        pattern = Path(str(item["files_glob"]))
        if pattern.is_absolute():
            base_dir = Path(pattern.anchor)
            pattern = pattern.relative_to(base_dir)
        paths = sorted(base_dir.glob(str(pattern)))
        if not paths:
            raise ValueError(f"Measurement files_glob matched no files: {item['files_glob']}")
        return [path.resolve() for path in paths], False
    if "files" in item:
        return [
            (Path(path) if Path(path).is_absolute() else base_dir / path).resolve()
            for path in item["files"]
        ], False
    if "file" in item:
        path = Path(item["file"])
        return [(path if path.is_absolute() else base_dir / path).resolve()], True
    raise AssertionError("unreachable measurement source selection")


def _default_measurement_id(instrument_id: str, path: Path, base_dir: Path) -> str:
    """Return a checkout-independent id for a legacy measurement path.

    Explicit ids are the public contract.  The compatibility id uses a path
    relative to the inverse document so benchmark fingerprints do not depend on
    the machine's absolute checkout directory.  External files fall back to the
    basename; duplicate basenames are then rejected and require explicit ids.
    """

    try:
        source = path.relative_to(base_dir).as_posix()
    except ValueError:
        source = path.name
    digest = sha256(source.encode("utf-8")).hexdigest()[:10]
    stem = path.stem or "measurement"
    return f"{instrument_id}:{stem}:{digest}"


def _normalize_single_measurement_binding(
    item: Dict[str, Any],
    instrument_id: str,
    path: Path,
    base_dir: Path,
    legacy_index: int,
) -> tuple[List[str], List[str]]:
    if "ids" in item or "prediction_keys" in item:
        raise ValueError("A singular measurement file uses id and prediction_key, not ids/prediction_keys.")
    ids = [str(item.get("id") or _default_measurement_id(instrument_id, path, base_dir))]
    prediction_keys = [str(item.get("prediction_key") or f"chord_{legacy_index}")]
    return ids, prediction_keys


def _normalize_plural_measurement_bindings(
    item: Dict[str, Any],
    instrument_id: str,
    paths: List[Path],
    base_dir: Path,
    legacy_start: int,
) -> tuple[List[str], List[str]]:
    if "id" in item:
        raise ValueError("Plural measurement files use ids, not id.")
    if "prediction_key" in item and "prediction_keys" in item:
        raise ValueError(
            "Plural measurement files accept either one shared prediction_key or "
            "an ordered prediction_keys array, not both."
        )
    ids = [str(value) for value in item.get("ids", [])]
    if not ids:
        ids = [_default_measurement_id(instrument_id, path, base_dir) for path in paths]
    if "prediction_key" in item:
        shared_prediction_key = str(item["prediction_key"])
        prediction_keys = [shared_prediction_key] * len(paths)
    else:
        prediction_keys = [str(value) for value in item.get("prediction_keys", [])]
    if not prediction_keys:
        prediction_keys = [f"chord_{legacy_start + index}" for index in range(len(paths))]
    if len(ids) != len(paths):
        raise ValueError("Measurement ids must have the same number and order as the resolved files.")
    if len(prediction_keys) != len(paths):
        raise ValueError(
            "Measurement prediction_keys must have the same number and order as the resolved files."
        )
    return ids, prediction_keys


def _register_measurement_ids(
    ids: List[str],
    prediction_keys: List[str],
    seen_ids: set[str],
) -> None:
    if any(not value.strip() for value in ids):
        raise ValueError("Measurement ids must be non-empty strings.")
    if any(not value.strip() for value in prediction_keys):
        raise ValueError("Measurement prediction keys must be non-empty strings.")
    duplicate_ids = seen_ids.intersection(ids)
    if duplicate_ids:
        raise ValueError(f"Measurement ids must be globally unique; duplicates: {sorted(duplicate_ids)}")
    if len(set(ids)) != len(ids):
        raise ValueError("Measurement ids must be globally unique within a plural entry.")
    seen_ids.update(ids)


def _measurement_covariance_paths(
    inv_cfg: Dict[str, Any], item: Dict[str, Any], count: int, *, singular: bool,
) -> List[Path | None]:
    if "covariance_file" in item and "covariance_files" in item:
        raise ValueError("Measurement may declare covariance_file or covariance_files, not both.")
    if "covariance_file" in item:
        if not singular:
            raise ValueError("covariance_file requires a single measurement file entry.")
        return [resolve_path(inv_cfg, str(item["covariance_file"]))]
    if "covariance_files" in item:
        paths: List[Path | None] = [resolve_path(inv_cfg, str(value)) for value in item["covariance_files"]]
        if len(paths) != count:
            raise ValueError("covariance_files must have the same number and order as the resolved measurement files.")
        return paths
    return [None] * count


_OBSERVATION_METADATA_FIELDS = {
    "condition_id",
    "state_group_id",
    "view_id",
    "replicate_id",
    "stage",
    "output_basis",
    "output_unit",
    "calibration_artifact",
}
_OBSERVATION_TEXT_FIELDS = _OBSERVATION_METADATA_FIELDS - {
    "calibration_artifact"
}
_SINGULAR_OBSERVATION_FIELDS = {"view_id", "replicate_id"}


def _normalize_observation_metadata(item: Dict[str, Any], *, singular: bool) -> None:
    """Validate only the observation metadata that the caller supplied.

    Provenance is optional for numerical fitting.  Complete artifact/hash
    verification belongs to the model-ready package adapter rather than the
    core inverse configuration.  A plural entry may share condition, state,
    calibration, and unit metadata, but view/replicate identities remain
    singular so their meaning cannot depend on implicit parallel arrays.
    """

    supplied = _OBSERVATION_METADATA_FIELDS.intersection(item)
    if not supplied:
        return
    singular_only = _SINGULAR_OBSERVATION_FIELDS.intersection(item)
    if not singular and singular_only:
        raise ValueError(
            "Plural measurement entries cannot declare scalar view_id or replicate_id; "
            "use singular entries when per-observation provenance is required."
        )
    for field in _OBSERVATION_TEXT_FIELDS.intersection(item):
        value = str(item[field]).strip()
        if not value:
            raise ValueError(f"Observation metadata field '{field}' must be non-empty.")
        item[field] = value
    if "stage" in item and item["stage"] != "model_ready":
        raise ValueError("Inverse observation stage must be 'model_ready' when declared.")
    if "calibration_artifact" not in item:
        return
    artifact = item["calibration_artifact"]
    if not isinstance(artifact, dict):
        raise ValueError("calibration_artifact must contain id and sha256.")
    artifact_id = str(artifact.get("id", "")).strip()
    artifact_sha256 = str(artifact.get("sha256", "")).strip().lower()
    try:
        valid_hash = len(artifact_sha256) == 64 and int(artifact_sha256, 16) >= 0
    except ValueError:
        valid_hash = False
    if not artifact_id or not valid_hash:
        raise ValueError("calibration_artifact requires a non-empty id and 64-digit hexadecimal sha256.")
    item["calibration_artifact"] = {"id": artifact_id, "sha256": artifact_sha256}


def _validate_single_inverse_state(items: List[Dict[str, Any]]) -> None:
    """Keep the P0 inverse contract to one condition and shared state group."""

    condition_ids = {str(item["condition_id"]) for item in items if "condition_id" in item}
    state_group_ids = {str(item["state_group_id"]) for item in items if "state_group_id" in item}
    if len(condition_ids) > 1:
        raise ValueError(
            "One inverse run may contain only one condition_id; found "
            f"{sorted(condition_ids)}. Run conditions separately."
        )
    if len(state_group_ids) > 1:
        raise ValueError(
            "One inverse run may contain only one state_group_id; found "
            f"{sorted(state_group_ids)}. Run state-sharing hypotheses separately."
        )
    if condition_ids:
        condition_id = next(iter(condition_ids))
        for item in items:
            item.setdefault("condition_id", condition_id)
    if state_group_ids:
        state_group_id = next(iter(state_group_ids))
        for item in items:
            item.setdefault("state_group_id", state_group_id)


def normalize_measurement_bindings(inv_cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Expand file collections into one canonical binding per observation.

    Legacy files retain their former ``chord_0``, ``chord_1``, ... mapping per
    instrument.  New configurations can bind any number of observations to the
    same prediction key explicitly.  Downstream objective code therefore never
    needs to infer a chord from list position or resolve a glob again.
    """

    normalized: List[Dict[str, Any]] = []
    next_legacy_chord: Dict[str, int] = {}
    seen_ids: set[str] = set()
    base_dir = Path(inv_cfg.get("__base_dir__", ".")).resolve()

    for raw_item in inv_cfg.get("measurements", []):
        item = dict(raw_item)
        instrument_id = str(item["instrument_id"])
        paths, singular = _measurement_source_paths(inv_cfg, item)
        count = len(paths)
        if count == 0:
            raise ValueError("A measurement entry must contain at least one file.")
        start = next_legacy_chord.get(instrument_id, 0)

        if singular:
            ids, prediction_keys = _normalize_single_measurement_binding(
                item,
                instrument_id,
                paths[0],
                base_dir,
                start,
            )
        else:
            ids, prediction_keys = _normalize_plural_measurement_bindings(
                item,
                instrument_id,
                paths,
                base_dir,
                start,
            )

        _normalize_observation_metadata(item, singular=singular)
        _register_measurement_ids(ids, prediction_keys, seen_ids)
        next_legacy_chord[instrument_id] = start + count
        covariance_paths = _measurement_covariance_paths(inv_cfg, item, count, singular=singular)
        shorthand_fields = {
            "file", "files", "files_glob", "id", "ids", "prediction_key", "prediction_keys",
            "covariance_file", "covariance_files",
        }
        shared = {key: value for key, value in item.items() if key not in shorthand_fields}
        for path, observation_id, prediction_key, covariance_path in zip(
            paths, ids, prediction_keys, covariance_paths, strict=True,
        ):
            observation = deep_merge(shared, {
                "file": str(path), "id": observation_id, "prediction_key": prediction_key,
            })
            if covariance_path is not None:
                observation["covariance_file"] = str(covariance_path)
            normalized.append(observation)

    _validate_single_inverse_state(normalized)
    return normalized


def normalize_inverse_config(case_cfg: Dict[str, Any], inv_cfg: Dict[str, Any]) -> Dict[str, Any]:
    mode = str(inv_cfg.get("inference_mode", _INVERSE_DEFAULTS["inference_mode"]))
    defaults = deep_merge(_INVERSE_DEFAULTS, _INVERSE_MODE_DEFAULTS.get(mode, {}))
    out = deep_merge(defaults, inv_cfg)
    out["measurements"] = normalize_measurement_bindings(out)
    out["parameters"] = expand_parameter_groups(case_cfg, out)
    # Groups are input shorthand. A canonical document must be safe to
    # normalize again without expanding its already materialized parameters.
    out.pop("parameter_groups", None)
    _normalize_regularization(out)
    return out
