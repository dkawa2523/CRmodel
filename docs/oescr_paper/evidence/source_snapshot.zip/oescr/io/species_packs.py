"""Composition of reusable OESCR emitter/species fragments.

Species packs group spectroscopic states and reduced-CR processes. They do not
solve gas composition or introduce a global chemistry model.
"""

from __future__ import annotations

import re
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Mapping

from ..data.provenance import file_sha256
from .yaml_loader import load_yaml, resolve_path

_SECTIONS = (
    "states",
    "reactions",
    "transitions",
    "emission_kernels",
    "quenching",
    "losses",
    "bands",
)
_PATH_KEYS = {"cross_section_file", "profile_file"}
_SHA256_RE = re.compile(r"^[0-9a-fA-F]{64}$")


class SpeciesPackError(ValueError):
    pass


def _verify_source_artifacts(pack_cfg: Mapping[str, Any], source: str) -> list[Dict[str, str]]:
    """Verify optional pack-level source manifests before composition.

    Reaction-level hashes remain the responsibility of the emission-kernel
    inventory.  This check covers the coarser artifacts that define the
    imported curve set and atomic branch table.
    """

    metadata = pack_cfg.get("metadata", {})
    if not isinstance(metadata, Mapping):
        raise SpeciesPackError(f"Species pack metadata must be a mapping: {source}")
    artifacts = metadata.get("source_artifacts", {})
    if not artifacts:
        return []
    if not isinstance(artifacts, Mapping):
        raise SpeciesPackError(f"Species pack metadata.source_artifacts must be a mapping: {source}")

    verified: list[Dict[str, str]] = []
    for artifact_id, raw_artifact in artifacts.items():
        if not isinstance(raw_artifact, Mapping):
            raise SpeciesPackError(f"Species pack source artifact '{artifact_id}' must be a mapping: {source}")
        file_value = str(raw_artifact.get("file", "")).strip()
        expected = str(raw_artifact.get("sha256", "")).strip().lower()
        if not file_value:
            raise SpeciesPackError(f"Species pack source artifact '{artifact_id}' requires file: {source}")
        if _SHA256_RE.fullmatch(expected) is None:
            raise SpeciesPackError(
                f"Species pack source artifact '{artifact_id}' requires a 64-digit hexadecimal sha256: {source}"
            )
        artifact_path = resolve_path(dict(pack_cfg), file_value)
        if not artifact_path.is_file():
            raise SpeciesPackError(f"Species pack source artifact '{artifact_id}' does not exist: {artifact_path}")
        actual = file_sha256(artifact_path)
        if actual != expected:
            raise SpeciesPackError(
                f"Species pack source artifact '{artifact_id}' SHA-256 mismatch: expected {expected}, got {actual}."
            )
        verified.append(
            {
                "id": str(artifact_id),
                "file": str(artifact_path.resolve()),
                "sha256": expected,
            }
        )
    return verified


def _namespace_id(namespace: str, value: str) -> str:
    if not namespace or ":" in value:
        return value
    return f"{namespace}:{value}"


def _resolve_pack_paths(value: Any, pack_cfg: Mapping[str, Any], key: str | None = None) -> Any:
    if isinstance(value, dict):
        return {name: _resolve_pack_paths(item, pack_cfg, str(name)) for name, item in value.items()}
    if isinstance(value, list):
        return [_resolve_pack_paths(item, pack_cfg, key) for item in value]
    if key in _PATH_KEYS and isinstance(value, str):
        return str(resolve_path(pack_cfg, value))
    return deepcopy(value)


def _required_id_map(items: list[Dict[str, Any]], namespace: str) -> Dict[str, str]:
    return {str(item["id"]): _namespace_id(namespace, str(item["id"])) for item in items}


def _optional_id_map(items: list[Dict[str, Any]], namespace: str) -> Dict[str, str]:
    return {str(item["id"]): _namespace_id(namespace, str(item["id"])) for item in items if "id" in item}


def _namespace_reference(item: Dict[str, Any], key: str, id_map: Mapping[str, str]) -> None:
    value = str(item.get(key, ""))
    if value in id_map:
        item[key] = id_map[value]


def _namespace_reaction(
    reaction: Dict[str, Any],
    state_map: Mapping[str, str],
    reaction_map: Mapping[str, str],
) -> None:
    reaction["id"] = reaction_map[str(reaction["id"])]
    _namespace_reference(reaction, "source_state", state_map)
    _namespace_reference(reaction, "target_state", state_map)
    reaction["colliders"] = [state_map.get(str(item), str(item)) for item in reaction.get("colliders", [])]


def _namespace_transition(
    transition: Dict[str, Any],
    state_map: Mapping[str, str],
    transition_map: Mapping[str, str],
) -> None:
    if "id" in transition:
        transition["id"] = transition_map[str(transition["id"])]
    _namespace_reference(transition, "upper", state_map)
    _namespace_reference(transition, "lower", state_map)


def _namespace_emission_kernel(
    kernel: Dict[str, Any],
    namespace: str,
    state_map: Mapping[str, str],
    reaction_map: Mapping[str, str],
    transition_map: Mapping[str, str],
) -> None:
    kernel["id"] = _namespace_id(namespace, str(kernel["id"]))
    _namespace_reference(kernel, "upper_state", state_map)
    kernel["process_ids"] = [reaction_map.get(str(item), str(item)) for item in kernel.get("process_ids", [])]
    kernel["transition_ids"] = [transition_map.get(str(item), str(item)) for item in kernel.get("transition_ids", [])]
    evidence = kernel.get("evidence", {})
    for artifact in evidence.get("process_artifacts", []):
        _namespace_reference(artifact, "process_id", reaction_map)


def _namespace_band(
    band: Dict[str, Any],
    namespace: str,
    state_map: Mapping[str, str],
) -> None:
    band["id"] = _namespace_id(namespace, str(band["id"]))
    _namespace_reference(band, "source_density_key", state_map)


def _apply_namespace(pack_cfg: Dict[str, Any], namespace: str) -> Dict[str, Any]:
    out = deepcopy(pack_cfg)
    state_map = _required_id_map(out.get("states", []), namespace)
    reaction_map = _required_id_map(out.get("reactions", []), namespace)
    transition_map = _optional_id_map(out.get("transitions", []), namespace)

    for state in out.get("states", []):
        state["id"] = state_map[str(state["id"])]
    for reaction in out.get("reactions", []):
        _namespace_reaction(reaction, state_map, reaction_map)
    for transition in out.get("transitions", []):
        _namespace_transition(transition, state_map, transition_map)
    for kernel in out.get("emission_kernels", []):
        _namespace_emission_kernel(
            kernel,
            namespace,
            state_map,
            reaction_map,
            transition_map,
        )
    for quenching in out.get("quenching", []):
        _namespace_reference(quenching, "state", state_map)
        _namespace_reference(quenching, "collider", state_map)
    for loss in out.get("losses", []):
        _namespace_reference(loss, "state", state_map)
    for band in out.get("bands", []):
        _namespace_band(band, namespace, state_map)
    return out


def _append_unique(target: list[Dict[str, Any]], additions: list[Dict[str, Any]], section: str) -> None:
    existing = {str(item["id"]) for item in target if "id" in item}
    for item in additions:
        item_id = str(item["id"]) if "id" in item else None
        if item_id is not None and item_id in existing:
            raise SpeciesPackError(f"Duplicate {section} id while composing species packs: {item_id}")
        target.append(deepcopy(item))
        if item_id is not None:
            existing.add(item_id)


def compose_species_packs(cfg: Dict[str, Any]) -> tuple[Dict[str, Any], list[Dict[str, Any]]]:
    """Expand species_packs into ordinary case sections and return provenance."""

    out = deepcopy(cfg)
    pack_entries = list(out.pop("species_packs", []))
    provenance: list[Dict[str, Any]] = []
    for section in _SECTIONS:
        out.setdefault(section, [])

    for index, entry in enumerate(pack_entries):
        if not isinstance(entry, dict):
            raise SpeciesPackError(f"species_packs[{index}] must be a mapping.")
        if "yaml_file" in entry:
            pack_path = resolve_path(cfg, str(entry["yaml_file"]))
            pack_cfg = load_yaml(pack_path)
            source = str(Path(pack_path).resolve())
        else:
            pack_cfg = deepcopy(entry)
            pack_cfg.setdefault("__base_dir__", cfg.get("__base_dir__", "."))
            source = "<inline>"

        kind = str(pack_cfg.get("kind", "oescr_species_pack"))
        if kind != "oescr_species_pack":
            raise SpeciesPackError(f"Unsupported species pack kind: {kind}")
        verified_source_artifacts = _verify_source_artifacts(pack_cfg, source)
        namespace = str(entry.get("namespace", pack_cfg.get("namespace", ""))).strip()
        pack_cfg = _resolve_pack_paths(pack_cfg, pack_cfg)
        pack_cfg = _apply_namespace(pack_cfg, namespace)

        for section in _SECTIONS:
            _append_unique(out[section], list(pack_cfg.get(section, [])), section)

        provenance.append(
            {
                "source": source,
                "namespace": namespace,
                "metadata": deepcopy(pack_cfg.get("metadata", {})),
                "verified_source_artifacts": verified_source_artifacts,
            }
        )

    return out, provenance
