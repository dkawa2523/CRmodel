from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

from .validators import validate_project_structural
from .yaml_loader import load_yaml, resolve_path


@dataclass
class ProjectManifest:
    raw: Dict[str, Any]
    path: Path
    case_yaml: Path
    inverse_yaml: Path | None
    inline_inverse: Dict[str, Any] | None
    default_output_dir: Path

    @property
    def name(self) -> str:
        return str(self.raw.get("project", {}).get("name", self.path.stem))

    def load_inverse_config(self) -> Dict[str, Any] | None:
        """Return the inverse configuration regardless of how it was declared."""

        if self.inline_inverse is not None:
            return deepcopy(self.inline_inverse)
        if self.inverse_yaml is not None:
            return load_yaml(self.inverse_yaml)
        return None


def load_project(path: str | Path) -> ProjectManifest:
    project_path = Path(path).resolve()
    cfg = load_yaml(path)
    validate_project_structural(cfg)
    case_yaml = resolve_path(cfg, str(cfg["case"]))

    inverse = cfg.get("inverse")
    inverse_yaml = resolve_path(cfg, inverse) if isinstance(inverse, str) else None
    inline_inverse = deepcopy(inverse) if isinstance(inverse, dict) else None
    if inline_inverse is not None:
        inline_inverse["__base_dir__"] = str(project_path.parent)
        inline_inverse["__path__"] = str(project_path)

    out_dir = resolve_path(cfg, cfg.get("outputs", {}).get("default_dir", "outputs"))
    assert out_dir is not None
    return ProjectManifest(
        raw=cfg,
        path=project_path,
        case_yaml=case_yaml,
        inverse_yaml=inverse_yaml,
        inline_inverse=inline_inverse,
        default_output_dir=out_dir,
    )
