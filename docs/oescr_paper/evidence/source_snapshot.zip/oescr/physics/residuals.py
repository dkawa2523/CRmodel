
from __future__ import annotations

from math import isfinite
from typing import Any, Dict, Mapping

from scipy import constants as const


def neutral_density_from_pressure(pressure_Pa: float, gas_temperature_K: float) -> float:
    return float(pressure_Pa / (const.k * gas_temperature_K))


def _zone_value(
    x: Any,
    zone_idx: int,
    label: str,
    default: float = 0.0,
) -> float:
    if x is None:
        value = float(default)
    elif isinstance(x, (list, tuple)):
        if zone_idx >= len(x):
            raise ValueError(f"{label} has no value for zone {zone_idx}.")
        value = float(x[zone_idx])
    else:
        value = float(x)
    if not isfinite(value) or value < 0.0:
        raise ValueError(f"{label} must contain finite, non-negative densities.")
    return value


def _register_density_origin(
    origins: Dict[str, str],
    species: str,
    origin: str,
) -> None:
    previous = origins.get(species)
    if previous is not None:
        raise ValueError(
            f"Density species '{species}' is defined by both "
            f"'{previous}' and '{origin}'; each species must have exactly one density origin."
        )
    origins[species] = origin


def validate_external_density_origins(cfg: Mapping[str, Any]) -> None:
    """Give every density one owner: either a solved state or an input."""

    origins: Dict[str, str] = {}
    for state in cfg.get("states", []):
        if state.get("solve", True):
            _register_density_origin(origins, str(state["id"]), "solved state")
    gas = cfg.get("gas_mixture", {})
    for species in gas.get("fractions", {}):
        _register_density_origin(origins, str(species), "gas_mixture.fractions")

    _register_density_origin(origins, "e", "plasma_state.ne_shells_m3")
    plasma = cfg.get("plasma_state", {})
    for section in ("radicals", "metastables"):
        origin = f"plasma_state.{section}"
        for species in plasma.get(section, {}):
            _register_density_origin(origins, str(species), origin)

    residuals = cfg.get("residuals", {})
    mode = str(residuals.get("mode", "off"))
    if mode not in {"off", "custom"}:
        raise ValueError(
            f"Unsupported residuals.mode '{mode}'; use 'off' or provide explicit densities with 'custom'."
        )
    residual_species = residuals.get("species_density_m3", {})
    if mode == "off" and residual_species:
        raise ValueError(
            "residuals.species_density_m3 must be empty when residuals.mode='off'; "
            "use mode='custom' for explicit residual densities."
        )
    if mode == "custom":
        for species in residual_species:
            _register_density_origin(
                origins,
                str(species),
                "residuals.species_density_m3",
            )


def build_external_densities(cfg: Dict[str, Any], zone_idx: int) -> Dict[str, float]:
    gas = cfg.get("gas_mixture", {})
    pressure_Pa = float(gas.get("total_pressure_Pa", 1.0))
    Tg = float(gas.get("gas_temperature_K", 300.0))
    total_neutral = neutral_density_from_pressure(pressure_Pa, Tg)

    dens: Dict[str, float] = {}
    for name, frac in gas.get("fractions", {}).items():
        dens[name] = float(frac) * total_neutral

    plasma = cfg.get("plasma_state", {})
    dens["e"] = _zone_value(
        plasma.get("ne_shells_m3", [0.0]),
        zone_idx,
        "plasma_state.ne_shells_m3",
    )

    for key, arr in plasma.get("radicals", {}).items():
        dens[key] = _zone_value(arr, zone_idx, f"plasma_state.radicals.{key}")

    for key, arr in plasma.get("metastables", {}).items():
        dens[key] = _zone_value(arr, zone_idx, f"plasma_state.metastables.{key}")

    res = cfg.get("residuals", {})
    if res.get("mode", "off") != "off":
        for key, arr in res.get("species_density_m3", {}).items():
            dens[key] = _zone_value(
                arr,
                zone_idx,
                f"residuals.species_density_m3.{key}",
            )

    return dens
