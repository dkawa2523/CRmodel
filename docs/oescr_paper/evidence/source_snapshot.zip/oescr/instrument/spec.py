from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict

import numpy as np

from .baseline import BASELINE_PLUGINS, evaluate_baseline, normalize_baseline_config
from .calibration import CalibrationTransform
from .lsf import LSF_PLUGINS, apply_lsf, lsf_support_nm, normalize_lsf_config
from .throughput import THROUGHPUT_PLUGINS, evaluate_throughput, normalize_throughput_config


@dataclass
class InstrumentSpec:
    cfg: Dict[str, Any]
    validated: bool = False
    calibration: CalibrationTransform = field(init=False)

    def __post_init__(self) -> None:
        self.cfg = normalize_instrument_config(self.cfg)
        if not self.validated:
            THROUGHPUT_PLUGINS.validate(str(self.cfg["throughput"]["kind"]), self.cfg["throughput"])
            LSF_PLUGINS.validate(str(self.cfg["lsf"]["kind"]), self.cfg["lsf"])
            BASELINE_PLUGINS.validate(str(self.cfg["baseline"]["kind"]), self.cfg["baseline"])
        self.calibration = CalibrationTransform.from_instrument_config(self.cfg)
        self.validated = True

    @property
    def instrument_id(self) -> str:
        return str(self.cfg["id"])

    @property
    def wavelength_grid_nm(self) -> np.ndarray:
        return instrument_wavelength_grid_nm(self.cfg)

    def fine_grid_nm(
        self,
        oversample: int = 8,
        padding_nm: float = 5.0,
        *,
        max_step_nm: float | None = None,
    ) -> np.ndarray:
        coarse = self.wavelength_grid_nm
        if np.any(np.diff(coarse) <= 0.0):
            raise ValueError("Instrument wavelength grid must be strictly increasing.")
        dx = float(np.min(np.diff(coarse))) / oversample
        for name in ("fwhm_nm", "fwhm_g_nm", "fwhm_l_nm"):
            if name in self.cfg["lsf"]:
                dx = min(dx, float(self.cfg["lsf"][name]) / oversample)
        if max_step_nm is not None:
            dx = min(dx, max_step_nm)
        padding = max(padding_nm, instrument_padding_nm(self.cfg, dx))
        return np.arange(coarse.min() - padding, coarse.max() + padding + 0.5 * dx, dx)

    def observe(self, fine_wavelength_nm: np.ndarray, fine_intensity: np.ndarray) -> Dict[str, Any]:
        """Observe one spectrum or a batch with wavelength on the last axis."""

        values = np.asarray(fine_intensity, dtype=float)
        if values.ndim == 0 or values.shape[-1] != len(fine_wavelength_nm):
            raise ValueError("The last intensity axis must match the fine wavelength grid.")
        # Transmission and photon conversion use the incident wavelength.
        # A readout wavelength shift or LSF redistribution cannot change the
        # number of photoelectrons produced by a photon of that energy.
        throughput = evaluate_throughput(self.cfg, fine_wavelength_nm, validate=False)
        incident_signal = self.calibration.apply(fine_wavelength_nm, values * throughput)
        shift = float(self.cfg.get("nuisance", {}).get("wavelength_shift_nm", 0.0))
        if abs(shift) > 0.0:
            shifted = np.asarray([
                np.interp(fine_wavelength_nm, fine_wavelength_nm - shift, row, left=0.0, right=0.0)
                for row in incident_signal.reshape(-1, len(fine_wavelength_nm))
            ]).reshape(incident_signal.shape)
        else:
            shifted = incident_signal

        convolved = apply_lsf(self.cfg, fine_wavelength_nm, shifted, validate=False)
        baseline = evaluate_baseline(self.cfg, fine_wavelength_nm, validate=False)
        gain = float(self.cfg.get("nuisance", {}).get("gain", 1.0))
        fine_obs = gain * convolved + baseline

        coarse = self.wavelength_grid_nm
        if np.any(np.diff(coarse) <= 0.0):
            raise ValueError("Instrument wavelength grid must be strictly increasing.")
        midpoints = 0.5 * (coarse[:-1] + coarse[1:])
        edges = np.concatenate(
            [
                [coarse[0] - 0.5 * (coarse[1] - coarse[0])],
                midpoints,
                [coarse[-1] + 0.5 * (coarse[-1] - coarse[-2])],
            ]
        )
        steps = np.diff(fine_wavelength_nm)
        interval_area = 0.5 * (fine_obs[..., :-1] + fine_obs[..., 1:]) * steps
        cumulative_area = np.concatenate(
            (np.zeros(fine_obs.shape[:-1] + (1,)), np.cumsum(interval_area, axis=-1)), axis=-1
        )

        # Evaluate the antiderivative at every detector edge. Within a fine-grid
        # interval the signal is linear, so the partial interval is another
        # trapezoid. Clipping to the first/last node also reproduces np.interp's
        # constant endpoint extension when a detector bin extends past the fine grid.
        interpolation_indices = np.clip(
            np.searchsorted(fine_wavelength_nm, edges, side="right") - 1, 0, len(fine_wavelength_nm) - 2
        )
        fractions = np.clip(
            (edges - fine_wavelength_nm[interpolation_indices]) / steps[interpolation_indices], 0.0, 1.0
        )
        edge_signal = (
            fine_obs[..., interpolation_indices] * (1.0 - fractions)
            + fine_obs[..., interpolation_indices + 1] * fractions
        )
        edge_indices = np.searchsorted(fine_wavelength_nm, edges, side="right") - 1
        edge_indices = np.clip(edge_indices, 0, fine_wavelength_nm.size - 1)
        edge_area = cumulative_area[..., edge_indices] + 0.5 * (fine_obs[..., edge_indices] + edge_signal) * (
            edges - fine_wavelength_nm[edge_indices]
        )
        out = np.diff(edge_area, axis=-1) / np.diff(edges)
        return {
            "wavelength_nm": coarse,
            "intensity": out,
            "output_basis": self.calibration.output_basis,
            "output_unit": self.calibration.output_unit,
            "calibration_reference": self.calibration.reference,
        }


def instrument_wavelength_grid_nm(cfg: Dict[str, Any]) -> np.ndarray:
    if "wavelength_grid_nm" in cfg:
        return np.asarray(cfg["wavelength_grid_nm"], dtype=float)
    wmin = float(cfg["wavelength_min_nm"])
    wmax = float(cfg["wavelength_max_nm"])
    bin_nm = float(cfg["bin_nm"])
    return np.arange(wmin, wmax + 0.5 * bin_nm, bin_nm)


def instrument_padding_nm(cfg: Dict[str, Any], dx_nm: float) -> float:
    """Cover detector edges, the LSF kernel, and the configured spectral shift."""

    coarse = instrument_wavelength_grid_nm(cfg)
    edge_half_width = 0.5 * max(coarse[1] - coarse[0], coarse[-1] - coarse[-2])
    shift = abs(float(cfg.get("nuisance", {}).get("wavelength_shift_nm", 0.0)))
    return max(5.0, float(edge_half_width) + lsf_support_nm(cfg, dx_nm) + shift + dx_nm)


def normalize_instrument_config(cfg: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(cfg)
    out.setdefault("nuisance", {})
    out["throughput"] = normalize_throughput_config(out)
    out["lsf"] = normalize_lsf_config(out)
    out["baseline"] = normalize_baseline_config(out)
    return out
