from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, Sequence

import numpy as np

from .objectives import _ObjectivePlan, residual_vector


def finite_difference_jacobian(
    model,
    case_cfg: Dict[str, Any],
    inv_cfg: Dict[str, Any],
    measurements,
    windows,
    params,
    *,
    include_constraints: bool = False,
    _plan: _ObjectivePlan | None = None,
) -> np.ndarray:
    """Differentiate either measurement data or the complete objective.

    The default is intentionally measurement-only because this module owns
    observability. Callers computing conditional objective curvature must opt
    into priors and regularization explicitly.
    """

    x0 = params.initial_vector(case_cfg)
    r0, _ = residual_vector(
        model,
        deepcopy(case_cfg),
        inv_cfg,
        measurements,
        windows,
        include_constraints=include_constraints,
        collect_details=False,
        _plan=_plan,
    )
    J = np.zeros((len(r0), len(x0)), dtype=float)
    lower, upper = params.bounds()
    for j, x in enumerate(x0):
        dx = 1.0e-4 * max(abs(x), 1.0)
        forward_room = max(float(upper[j] - x), 0.0)
        backward_room = max(float(x - lower[j]), 0.0)
        if forward_room < dx:
            dx = -min(dx, backward_room) if backward_room >= forward_room else forward_room
        xp = x0.copy()
        xp[j] += dx
        cfgp = deepcopy(case_cfg)
        params.apply_to_case(cfgp, xp)
        rp, _ = residual_vector(
            model,
            cfgp,
            inv_cfg,
            measurements,
            windows,
            include_constraints=include_constraints,
            collect_details=False,
            _plan=_plan,
        )
        J[:, j] = (rp - r0) / float(xp[j] - x)
    return J


def identifiability_summary(model, case_cfg, inv_cfg, measurements, windows, params) -> Dict[str, Any]:
    rank_rtol = float(inv_cfg.get("fit", {}).get("identifiability", {}).get("rank_rtol", 1.0e-8))
    J = finite_difference_jacobian(
        model,
        case_cfg,
        inv_cfg,
        measurements,
        windows,
        params,
        include_constraints=False,
    )
    _, aux = residual_vector(
        model,
        deepcopy(case_cfg),
        inv_cfg,
        measurements,
        windows,
        include_constraints=False,
    )
    summary = summarize_identifiability_jacobian(
        J,
        parameter_names=params.names(),
        parameter_roles=params.roles(),
        rank_rtol=rank_rtol,
    )
    summary["basis"] = "measurement_data_only"
    summary["implicit_nuisance_handling"] = implicit_nuisance_handling(inv_cfg)
    summary["selected_windows"] = aux.get("selected_windows", {})
    summary["declared_windows"] = aux.get("declared_windows", {})
    return summary


def project_target_jacobian(
    target_jacobian: np.ndarray,
    nuisance_jacobian: np.ndarray,
    *,
    rank_rtol: float = 1.0e-8,
) -> tuple[np.ndarray, Dict[str, Any]]:
    """Remove measurement-space directions explained by explicit nuisance parameters.

    An SVD-derived orthonormal basis is used instead of forming a pseudoinverse
    product directly.  This computes ``(I - J_eta J_eta^+) J_theta`` without
    constructing the potentially ill-conditioned projector matrix.
    """

    target = np.asarray(target_jacobian, dtype=float)
    nuisance = np.asarray(nuisance_jacobian, dtype=float)
    if target.ndim != 2 or nuisance.ndim != 2:
        raise ValueError("Target and nuisance Jacobians must both be two-dimensional.")
    if target.shape[0] != nuisance.shape[0]:
        raise ValueError("Target and nuisance Jacobians must have the same number of observations.")

    if nuisance.shape[1] == 0:
        return target.copy(), {
            "method": "identity_no_explicit_nuisance",
            "rank": 0,
            "rank_threshold": 0.0,
            "n_columns": 0,
        }

    left_vectors, singular_values, _ = np.linalg.svd(nuisance, full_matrices=False)
    largest = float(singular_values[0]) if len(singular_values) else 0.0
    threshold = max(largest * float(rank_rtol), 1.0e-12)
    rank = int(np.sum(singular_values > threshold))
    if rank:
        nuisance_basis = left_vectors[:, :rank]
        projected = target - nuisance_basis @ (nuisance_basis.T @ target)
    else:
        projected = target.copy()
    return projected, {
        "method": "svd_orthogonal_complement",
        "rank": rank,
        "rank_threshold": threshold,
        "n_columns": int(nuisance.shape[1]),
    }


def summarize_identifiability_jacobian(
    J: np.ndarray,
    *,
    parameter_names: Sequence[str],
    parameter_roles: Sequence[str],
    rank_rtol: float = 1.0e-8,
) -> Dict[str, Any]:
    """Keep the full-J summary and add target observability after nuisance projection."""

    matrix = np.asarray(J, dtype=float)
    names = list(parameter_names)
    roles = list(parameter_roles)
    if matrix.ndim != 2:
        raise ValueError(f"Jacobian must be two-dimensional, got shape {matrix.shape}.")
    if len(names) != matrix.shape[1] or len(roles) != matrix.shape[1]:
        raise ValueError("Parameter names and roles must match the Jacobian column count.")
    invalid_roles = sorted(set(roles) - {"target", "nuisance"})
    if invalid_roles:
        raise ValueError(f"Invalid parameter roles: {invalid_roles}.")

    role_array = np.asarray(roles, dtype=object)
    name_array = np.asarray(names, dtype=object)
    target_indices = np.flatnonzero(role_array == "target")
    nuisance_indices = np.flatnonzero(role_array == "nuisance")
    target_names = name_array[target_indices].tolist()
    nuisance_names = name_array[nuisance_indices].tolist()
    target_jacobian = matrix[:, target_indices]
    nuisance_jacobian = matrix[:, nuisance_indices]
    projected_target, projection = project_target_jacobian(
        target_jacobian,
        nuisance_jacobian,
        rank_rtol=rank_rtol,
    )

    summary = summarize_jacobian(
        matrix,
        rank_rtol=rank_rtol,
        parameter_names=names,
    )
    summary["target_parameter_names"] = target_names
    summary["nuisance_parameter_names"] = nuisance_names
    summary["projected_target"] = summarize_jacobian(
        projected_target,
        rank_rtol=rank_rtol,
        parameter_names=target_names,
    )
    summary["nuisance_projection"] = projection
    return summary


def implicit_nuisance_handling(inv_cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Describe nuisance handling already embedded in measurement residuals."""

    objective = inv_cfg.get("fit", {}).get("objective", {})
    auto_gain = bool(objective.get("auto_gain_fit", True))
    return {
        "auto_gain_offset_tilt": {
            "active": {
                "gain": auto_gain,
                "offset": auto_gain and bool(objective.get("auto_offset_fit", True)),
                "tilt": auto_gain and bool(objective.get("auto_gain_tilt_fit", False)),
            },
            "handling": "profiled_inside_each_residual_evaluation",
            "explicit_projection_columns_added": False,
        },
        "shared_calibration_covariance": {
            "handling": "prewhitened_in_measurement_residual",
            "explicit_projection_columns_added": False,
        },
    }


def summarize_jacobian(
    J: np.ndarray,
    rank_rtol: float = 1.0e-8,
    parameter_names: Sequence[str] | None = None,
    max_direction_components: int = 5,
) -> Dict[str, Any]:
    """Summarize rank and the parameter combinations behind weak directions."""

    matrix = np.asarray(J, dtype=float)
    if matrix.ndim != 2:
        raise ValueError(f"Jacobian must be two-dimensional, got shape {matrix.shape}.")
    n_parameters = int(matrix.shape[1])
    names = list(parameter_names) if parameter_names is not None else [f"parameter_{i}" for i in range(n_parameters)]
    if len(names) != n_parameters:
        raise ValueError(f"Received {len(names)} parameter names for {n_parameters} Jacobian columns.")

    # Only wide Jacobians need the extra right-null-space vectors. A full U
    # for a tall spectrum Jacobian would require O(n_pixels**2) memory.
    _, compact_singular_values, right_vectors = np.linalg.svd(matrix, full_matrices=matrix.shape[0] < n_parameters)
    singular_values = np.zeros(n_parameters, dtype=float)
    singular_values[: len(compact_singular_values)] = compact_singular_values
    largest = float(singular_values[0]) if n_parameters else 0.0
    threshold = max(largest * rank_rtol, 1.0e-12)
    rank = int(np.sum(singular_values > threshold))
    weakest = float(singular_values[-1]) if n_parameters else 0.0
    cond = float(largest / weakest) if weakest > threshold else float("inf")
    column_norms = np.linalg.norm(matrix, axis=0) if n_parameters else np.zeros(0, dtype=float)

    directions = []
    for index, (singular_value, vector) in enumerate(zip(singular_values, right_vectors, strict=True)):
        order = np.argsort(np.abs(vector))[::-1][: max(1, max_direction_components)]
        directions.append(
            {
                "index": index,
                "singular_value": float(singular_value),
                "relative_strength": float(singular_value / largest) if largest > 0.0 else 0.0,
                "identifiable": bool(singular_value > threshold),
                "dominant_parameters": [
                    {
                        "name": names[column],
                        "coefficient": float(vector[column]),
                    }
                    for column in order
                    if abs(float(vector[column])) > 1.0e-12
                ],
            }
        )

    return {
        "singular_values": singular_values.tolist(),
        "singular_directions": directions,
        "parameter_column_norms": {name: float(norm) for name, norm in zip(names, column_norms, strict=True)},
        "inactive_parameters": [
            name for name, norm in zip(names, column_norms, strict=True) if float(norm) <= threshold
        ],
        "condition_number": cond,
        "rank_estimate": rank,
        "rank_threshold": threshold,
        "n_observations": int(matrix.shape[0]),
        "n_parameters": n_parameters,
    }
