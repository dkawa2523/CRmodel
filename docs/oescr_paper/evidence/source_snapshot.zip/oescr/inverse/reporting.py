"""Small, stable serialization boundary for inverse results.

The numerical solver returns Python objects.  Command-line entry points should
not each decide which fields constitute the public result, so this module owns
the one YAML summary used by both direct and project-based runs.
"""

from __future__ import annotations

import csv
import re
from collections.abc import Mapping
from pathlib import Path
from typing import TYPE_CHECKING, Any, Sequence

import yaml

from ..io.yaml_loader import rebase_config_paths, save_yaml

if TYPE_CHECKING:
    from .optimize import FitResult
    from .spectral_fit import SpectralFit


_SAFE_STEM = re.compile(r"[^A-Za-z0-9_.-]+")

_AUDIT_ARTIFACTS = (
    ("uncertainty", "uncertainty.yaml"),
    ("identifiability", "identifiability.yaml"),
    ("forward_quality", "forward_quality.yaml"),
    ("optimization_trace", "optimization_trace.yaml"),
    ("parameter_profiles", "parameter_profiles.yaml"),
)

_AUDIT_FIELDS = tuple(field for field, _ in _AUDIT_ARTIFACTS)


def load_fit_result(
    path: str | Path,
    *,
    include_audit: bool = False,
) -> dict[str, Any]:
    """Load a persisted inverse result.

    The default read returns the compact ``result.yaml`` document.  Set
    ``include_audit=True`` when a caller needs optional scientific-audit
    payloads; manifest-backed artifacts are then restored under the same
    logical top-level field names used by legacy result files.

    Audit references must stay below the directory containing the result.
    Report files are deliberately read as plain YAML rather than as OESCR
    configuration, so configuration-only features such as ``include`` cannot
    redirect an artifact read.
    """

    result_path = Path(path).resolve()
    result = _load_report_mapping(result_path)
    if not include_audit:
        return result

    manifest = result.get("audit")
    if manifest is None:
        return result
    if not isinstance(manifest, Mapping):
        raise ValueError("result.yaml 'audit' must be a mapping.")

    result_dir = result_path.parent.resolve()
    for field in _AUDIT_FIELDS:
        _restore_audit_field(result, manifest, result_dir, field)
    return result


def _restore_audit_field(
    result: dict[str, Any],
    manifest: Mapping[str, Any],
    result_dir: Path,
    field: str,
) -> None:
    """Restore one sidecar while preserving a legacy top-level payload."""

    if result.get(field) is not None:
        return
    entry = manifest.get(field)
    if entry is None:
        return
    if not isinstance(entry, Mapping) or not isinstance(entry.get("file"), str):
        raise ValueError(f"result.yaml audit.{field} must contain a string 'file'.")

    artifact_path = _resolve_audit_path(result_dir, entry["file"], field=field)
    document = _load_report_mapping(artifact_path)
    # Sequence payloads (currently the optimization trace) are wrapped by the
    # writer so every artifact remains a top-level YAML mapping.
    result[field] = document[field] if len(document) == 1 and field in document else document


def _load_report_mapping(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as stream:
        document = yaml.safe_load(stream) or {}
    if not isinstance(document, Mapping):
        raise ValueError(f"Report YAML must contain a top-level mapping: {path}")
    return dict(document)


def _resolve_audit_path(result_dir: Path, value: str, *, field: str) -> Path:
    relative = Path(value)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError(
            f"result.yaml audit.{field}.file must be a relative path below the result directory."
        )
    candidate = (result_dir / relative).resolve()
    try:
        candidate.relative_to(result_dir)
    except ValueError as exc:
        raise ValueError(
            f"result.yaml audit.{field}.file resolves outside the result directory."
        ) from exc
    return candidate


def _gain_offset_records(raw: Any) -> list[dict[str, Any]]:
    """Serialize private tuple-keyed gain data as stable public records."""

    if not isinstance(raw, Mapping):
        return []

    records: list[dict[str, Any]] = []
    for key, correction in raw.items():
        if isinstance(key, (tuple, list)) and len(key) == 2:
            binding = {
                "instrument_id": str(key[0]),
                "observation_id": str(key[1]),
            }
        else:
            binding = {"binding_id": str(key)}

        record = dict(binding)
        if isinstance(correction, Mapping):
            record.update(correction)
        else:
            record["value"] = correction
        records.append(record)

    return sorted(
        records,
        key=lambda record: (
            str(record.get("instrument_id", "")),
            str(record.get("observation_id", "")),
            str(record.get("binding_id", "")),
        ),
    )


def _public_assessment(
    assessment: Any,
) -> tuple[list[str], dict[str, Any] | Any | None, str | None]:
    """Separate prominent warnings from compact interpretation metadata."""

    if not isinstance(assessment, Mapping):
        return [], assessment, None

    warnings = [str(value) for value in assessment.get("warnings", [])]
    compact: dict[str, Any] = {}
    for key, value in assessment.items():
        if key == "warnings" or value is None:
            continue
        if isinstance(value, (list, dict)) and not value:
            continue
        compact[key] = value
    mode = str(assessment["mode"]) if assessment.get("mode") is not None else None
    return warnings, compact or None, mode


def _add_nonempty_window_maps(summary: dict[str, Any], aux: Mapping[str, Any]) -> None:
    for field in ("selected_windows", "declared_windows"):
        window_map = aux.get(field, {})
        if isinstance(window_map, Mapping) and any(window_map.values()):
            summary[field] = window_map


def fit_result_summary(
    fit: "FitResult",
) -> dict[str, Any]:
    """Return the compact, user-facing summary of one inverse fit.

    Optional scientific audits and optimizer traces deliberately stay out of
    this mapping. :func:`write_fit_result` stores those payloads separately
    and adds only their file manifest to the persisted summary.
    """

    warnings, assessment, mode = _public_assessment(fit.assessment)
    summary: dict[str, Any] = {
        "success": bool(fit.success),
        "message": str(fit.message),
        "cost": float(fit.cost),
        "parameters": {name: float(value) for name, value in fit.parameters.items()},
    }
    if warnings:
        summary["warnings"] = warnings

    gain_offset = _gain_offset_records(fit.aux.get("gain_offset", {}))
    if gain_offset and mode != "calibrated_absolute":
        summary["gain_offset"] = gain_offset

    _add_nonempty_window_maps(summary, fit.aux)
    if assessment is not None:
        summary["assessment"] = assessment
    if fit.calibration_uncertainty is not None:
        summary["calibration_uncertainty"] = fit.calibration_uncertainty
    return summary


def write_fit_result(
    fit: "FitResult",
    out_dir: str | Path,
) -> None:
    """Write one canonical result summary and the optimized case."""

    destination = Path(out_dir)
    destination.mkdir(parents=True, exist_ok=True)
    result_path = destination / "result.yaml"
    previous = _load_report_mapping(result_path) if result_path.is_file() else {}
    summary = fit_result_summary(fit)
    if fit.spectral_fits:
        summary["spectral_fits"] = _write_spectral_fits(
            fit.spectral_fits,
            destination / "spectra",
        )
    audit_manifest = _write_audit_artifacts(fit, destination / "audit")
    if audit_manifest:
        summary["audit"] = audit_manifest
    save_yaml(summary, result_path)
    save_yaml(
        rebase_config_paths(fit.case_opt, destination),
        destination / "case_opt.yaml",
    )
    _remove_stale_outputs(destination, previous, summary)


def _remove_stale_outputs(destination: Path, previous: Mapping[str, Any], current: Mapping[str, Any]) -> None:
    """Remove superseded writer-owned files while retaining user additions."""

    active_spectra = {entry["file"] for entry in current.get("spectral_fits", [])}
    for entry in previous.get("spectral_fits", []):
        relative = Path(entry["file"])
        if relative.parent != Path("spectra") or str(relative.as_posix()) in active_spectra:
            continue
        path = (destination / relative).resolve()
        if path.is_relative_to(destination.resolve()):
            path.unlink(missing_ok=True)
    for field, filename in _AUDIT_ARTIFACTS:
        if field not in current.get("audit", {}):
            (destination / "audit" / filename).unlink(missing_ok=True)
    for name in ("spectra", "audit"):
        directory = destination / name
        if directory.is_dir() and not any(directory.iterdir()):
            directory.rmdir()


def _write_audit_artifacts(
    fit: "FitResult",
    out_dir: Path,
) -> dict[str, dict[str, str]]:
    """Write optional diagnostics outside the normal result document."""

    manifest: dict[str, dict[str, str]] = {}
    for field, filename in _AUDIT_ARTIFACTS:
        payload = getattr(fit, field, None)
        if payload is None:
            continue

        out_dir.mkdir(parents=True, exist_ok=True)
        document = payload if isinstance(payload, Mapping) else {field: payload}
        save_yaml(dict(document), out_dir / filename)
        manifest[field] = {"file": f"audit/{filename}"}
    return manifest


def _write_spectral_fits(
    records: Sequence["SpectralFit"],
    out_dir: Path,
) -> list[dict[str, Any]]:
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest: list[dict[str, Any]] = []
    for index, record in enumerate(records):
        safe_id = _SAFE_STEM.sub("_", record.observation_id).strip("._") or "observation"
        filename = f"{index:02d}_{safe_id}.csv"
        path = out_dir / filename
        with path.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(
                [
                    "wavelength_nm",
                    "measured",
                    "predicted",
                    "residual",
                    "sigma",
                    "used_for_fit",
                ]
            )
            sigma = record.sigma
            residual = record.residual
            for row_index, wavelength_nm in enumerate(record.wavelength_nm):
                writer.writerow(
                    [
                        float(wavelength_nm),
                        float(record.measured[row_index]),
                        float(record.predicted[row_index]),
                        float(residual[row_index]),
                        "" if sigma is None else float(sigma[row_index]),
                        int(record.used_for_fit[row_index]),
                    ]
                )
        manifest.append(
            {
                "observation_id": record.observation_id,
                "instrument_id": record.instrument_id,
                "prediction_key": record.prediction_key,
                "output_basis": record.output_basis,
                "output_unit": record.output_unit,
                "file": f"spectra/{filename}",
            }
        )
    return manifest
