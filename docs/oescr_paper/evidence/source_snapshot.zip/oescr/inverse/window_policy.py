"""Window-level model coverage and analysis-role policy.

The three declarations in this module answer independent questions:

``analysis_role``
    How the observation is used by an analysis.
``model_coverage``
    Whether the forward model represents the emitting physics.
``evidence_status``
    How strongly the window has been supported by external evidence.

Only a physically covered fit window is allowed into a plasma-state inverse
objective.  Evidence maturity is reported, but deliberately does not change
the numerical objective.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Mapping

import numpy as np

ANALYSIS_ROLES = frozenset({"fit", "score", "qc", "ignore"})
MODEL_COVERAGE_LEVELS = frozenset({"physical", "empirical", "unmodeled"})
EVIDENCE_STATUSES = frozenset(
    {"illustrative", "literature_anchored", "validation_candidate", "qualified"}
)
_SELECTION_FIELDS = frozenset({"analysis_role", "model_coverage"})


@dataclass(frozen=True)
class WindowPolicy:
    """Resolved policy for one diagnostic window."""

    analysis_role: str
    model_coverage: str
    evidence_status: str
    explicit: bool

    @property
    def contributes_to_fit(self) -> bool:
        return self.analysis_role == "fit" and self.model_coverage == "physical"


def _validated_value(
    window: Mapping[str, Any],
    field: str,
    default: str,
    choices: frozenset[str],
) -> str:
    value = str(window.get(field, default))
    if value not in choices:
        name = str(window.get("name", "<unnamed>"))
        allowed = ", ".join(sorted(choices))
        raise ValueError(f"Window '{name}' has invalid {field}='{value}'; expected one of: {allowed}.")
    return value


def resolve_window_policy(window: Mapping[str, Any]) -> WindowPolicy:
    """Resolve one window without mutating its user-facing declaration.

    Missing policy fields retain historical behaviour: the window is treated
    as a physical fit window with illustrative evidence.  The ``explicit``
    flag lets the objective distinguish a legacy registry (full-spectrum fit)
    from a registry that opts into wavelength-window selection. Evidence alone
    never changes selection.
    """

    analysis_role = _validated_value(window, "analysis_role", "fit", ANALYSIS_ROLES)
    model_coverage = _validated_value(
        window,
        "model_coverage",
        "physical",
        MODEL_COVERAGE_LEVELS,
    )
    if analysis_role == "fit" and model_coverage != "physical":
        name = str(window.get("name", "<unnamed>"))
        raise ValueError(
            f"Window '{name}' declares analysis_role='fit' but model_coverage="
            f"'{model_coverage}'; empirical or unmodeled windows must use score, qc, or ignore."
        )
    return WindowPolicy(
        analysis_role=analysis_role,
        model_coverage=model_coverage,
        evidence_status=_validated_value(
            window,
            "evidence_status",
            "illustrative",
            EVIDENCE_STATUSES,
        ),
        explicit=any(field in window for field in _SELECTION_FIELDS),
    )


def has_explicit_window_policy(windows: List[Dict[str, Any]]) -> bool:
    """Return whether a registry opted into explicit wavelength selection."""

    explicit = False
    for window in windows:
        # Resolve every row so an invalid declaration cannot hide behind the
        # short-circuit of an earlier explicit window.
        explicit = resolve_window_policy(window).explicit or explicit
    return explicit


def windows_for_analysis_role(
    windows: List[Dict[str, Any]],
    role: str,
) -> List[Dict[str, Any]]:
    """Select windows by declared role without applying model-coverage rules."""

    if role not in ANALYSIS_ROLES:
        allowed = ", ".join(sorted(ANALYSIS_ROLES))
        raise ValueError(f"Invalid analysis role '{role}'; expected one of: {allowed}.")
    return [window for window in windows if resolve_window_policy(window).analysis_role == role]


def fit_windows(windows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Return only windows eligible for Te/ne/EEDF objective residuals."""

    return [window for window in windows if resolve_window_policy(window).contributes_to_fit]


def fit_pixel_mask(
    wavelength_nm: np.ndarray,
    windows: List[Dict[str, Any]],
    *,
    selection_mode: str | None = None,
) -> np.ndarray | None:
    """Build the union of physical-fit windows for full-spectrum residuals.

    ``None`` means legacy full-spectrum behaviour.  Once any window declares
    policy metadata, the registry opts into explicit selection and a boolean
    mask is returned, including an all-false mask when no window is eligible.
    """

    mode = selection_mode or (
        "window_union" if has_explicit_window_policy(windows) else "legacy_full_spectrum"
    )
    if mode not in {"window_union", "full_spectrum", "legacy_full_spectrum"}:
        raise ValueError(f"Unknown window selection mode: {mode}")
    if mode != "window_union":
        return None
    wavelength = np.asarray(wavelength_nm, dtype=float)
    mask = np.zeros(wavelength.shape, dtype=bool)
    for window in fit_windows(windows):
        center = float(window["center_nm"])
        half_width = float(window.get("half_width_nm", 1.0))
        mask |= (wavelength >= center - half_width) & (wavelength <= center + half_width)
    return mask


def window_coverage_report(
    windows: List[Dict[str, Any]],
    *,
    selection_mode: str | None = None,
) -> Dict[str, Any]:
    """Return a serializable audit of declared and effective window policy."""

    rows: List[Dict[str, Any]] = []
    for window in windows:
        policy = resolve_window_policy(window)
        row: Dict[str, Any] = {"name": str(window.get("name", "")), **asdict(policy)}
        for field in ("kernel_id", "transition_id"):
            if field in window:
                row[field] = str(window[field])
        row["contributes_to_fit"] = policy.contributes_to_fit
        if policy.analysis_role != "fit":
            row["fit_exclusion_reason"] = f"analysis_role={policy.analysis_role}"
        elif policy.model_coverage != "physical":
            row["fit_exclusion_reason"] = f"model_coverage={policy.model_coverage}"
        else:
            row["fit_exclusion_reason"] = None
        rows.append(row)

    mode = selection_mode or (
        "window_union" if has_explicit_window_policy(windows) else "legacy_full_spectrum"
    )
    if mode not in {"window_union", "full_spectrum", "legacy_full_spectrum"}:
        raise ValueError(f"Unknown window selection mode: {mode}")
    return {
        "selection_mode": mode,
        "window_count": len(rows),
        "fit_window_count": sum(bool(row["contributes_to_fit"]) for row in rows),
        "windows": rows,
    }
