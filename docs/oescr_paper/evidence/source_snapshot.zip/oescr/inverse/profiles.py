"""Focused nonlinear profiles of the measurement-only inverse objective.

The routines in this module deliberately do not own model evaluation, priors,
or reporting.  They receive the already-defined measurement residual and scan
at most a small, explicitly selected set of target parameters.
"""

from __future__ import annotations

from typing import Any, Callable, Mapping, Sequence

import numpy as np
from scipy.optimize import least_squares

from .params import Parameter, ParameterSet

ResidualFunction = Callable[[np.ndarray], np.ndarray]


def _validated_residual_vector(
    residual: ResidualFunction,
    x: np.ndarray,
) -> np.ndarray:
    vector = np.asarray(residual(x), dtype=float)
    if vector.ndim != 1:
        raise ValueError(
            "Focused profile residual must be a one-dimensional vector; "
            f"received shape {vector.shape}."
        )
    if np.any(~np.isfinite(vector)):
        raise ValueError("Focused profile residual must contain only finite values.")
    return vector


def _bounded_start(values: np.ndarray, lower: np.ndarray, upper: np.ndarray) -> np.ndarray:
    start = np.clip(np.asarray(values, dtype=float), lower, upper)
    scale = np.maximum.reduce((np.ones_like(start), np.abs(lower), np.abs(upper)))
    near_zero = (
        (lower < 0.0)
        & (upper > 0.0)
        & (np.abs(start) <= np.sqrt(np.finfo(float).eps) * scale)
    )
    start[near_zero] = 0.0
    return start


def _active_bounds(
    x: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
    names: Sequence[str],
) -> list[dict[str, str]]:
    active: list[dict[str, str]] = []
    for name, value, lo, hi in zip(names, x, lower, upper, strict=True):
        tolerance = 1.0e-7 * max(1.0, abs(float(lo)), abs(float(hi)))
        if abs(float(value - lo)) <= tolerance:
            active.append({"name": name, "side": "lower"})
        elif abs(float(value - hi)) <= tolerance:
            active.append({"name": name, "side": "upper"})
    return active


def _physical_values(params: ParameterSet, x: np.ndarray) -> dict[str, float]:
    return {
        parameter.name: parameter.from_opt(float(value))
        for parameter, value in zip(params.params, x, strict=True)
    }


def _profile_grid(parameter: Parameter, physical_range: Sequence[float], points: int) -> np.ndarray:
    low, high = (float(physical_range[0]), float(physical_range[1]))
    if parameter.scale == "log":
        physical = np.geomspace(low, high, points)
    else:
        physical = np.linspace(low, high, points)
    return np.asarray([parameter.to_opt(value) for value in physical], dtype=float)


def _fit_all_parameters(
    residual: ResidualFunction,
    x_start: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
    *,
    max_nfev: int,
) -> tuple[np.ndarray, dict[str, Any]]:
    def checked_residual(values: np.ndarray) -> np.ndarray:
        return _validated_residual_vector(residual, values)

    result = least_squares(
        checked_residual,
        _bounded_start(np.asarray(x_start, dtype=float), lower, upper),
        bounds=(lower, upper),
        x_scale="jac",
        max_nfev=max_nfev,
    )
    x = np.asarray(result.x, dtype=float)
    vector = np.asarray(result.fun, dtype=float)
    return x, {
        "success": bool(result.success),
        "message": str(result.message),
        "nfev": int(result.nfev),
        "loss": 0.5 * float(np.dot(vector, vector)),
    }


def _fit_with_fixed_parameter(
    residual: ResidualFunction,
    x_start: np.ndarray,
    fixed_index: int,
    fixed_value: float,
    lower: np.ndarray,
    upper: np.ndarray,
    *,
    max_nfev: int,
) -> tuple[np.ndarray, dict[str, Any]]:
    all_indices = np.arange(len(x_start), dtype=int)
    free_indices = all_indices[all_indices != fixed_index]
    x_template = np.asarray(x_start, dtype=float).copy()
    x_template[fixed_index] = fixed_value

    if len(free_indices) == 0:
        vector = _validated_residual_vector(residual, x_template)
        return x_template, {
            "success": True,
            "message": "No remaining parameters to re-optimize.",
            "nfev": 1,
            "loss": 0.5 * float(np.dot(vector, vector)),
        }

    def conditional_residual(free_values: np.ndarray) -> np.ndarray:
        x = x_template.copy()
        x[free_indices] = free_values
        return _validated_residual_vector(residual, x)

    result = least_squares(
        conditional_residual,
        _bounded_start(
            x_template[free_indices],
            lower[free_indices],
            upper[free_indices],
        ),
        bounds=(lower[free_indices], upper[free_indices]),
        x_scale="jac",
        max_nfev=max_nfev,
    )
    x = x_template.copy()
    x[free_indices] = result.x
    vector = np.asarray(result.fun, dtype=float)
    return x, {
        "success": bool(result.success),
        "message": str(result.message),
        "nfev": int(result.nfev),
        "loss": 0.5 * float(np.dot(vector, vector)),
    }


def _reference_fit(
    residual: ResidualFunction,
    params: ParameterSet,
    x_start: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
    *,
    max_nfev: int,
) -> tuple[np.ndarray, dict[str, Any]]:
    x, fit = _fit_all_parameters(
        residual,
        x_start,
        lower,
        upper,
        max_nfev=max_nfev,
    )
    fit["parameters"] = _physical_values(params, x)
    fit["active_bounds"] = _active_bounds(x, lower, upper, params.names())
    return x, fit


def _evaluate_profiles_from_reference(
    residual: ResidualFunction,
    params: ParameterSet,
    reference_x: np.ndarray,
    profile_configs: Sequence[Mapping[str, Any]],
    lower: np.ndarray,
    upper: np.ndarray,
    *,
    max_nfev: int,
) -> tuple[dict[str, Any], list[tuple[str, dict[str, Any], np.ndarray]]]:
    names = params.names()
    name_to_index = {name: index for index, name in enumerate(names)}
    profiles: dict[str, Any] = {}
    all_points: list[tuple[str, dict[str, Any], np.ndarray]] = []
    for profile_config in profile_configs:
        name = str(profile_config["name"])
        index = name_to_index[name]
        parameter = params.params[index]
        configured_grid = _profile_grid(
            parameter,
            profile_config["range"],
            int(profile_config.get("points", 9)),
        )
        reference_coordinate = float(reference_x[index])
        reference_on_grid = bool(
            np.any(np.isclose(configured_grid, reference_coordinate, rtol=1.0e-12, atol=1.0e-12))
        )
        grid = (
            np.asarray(configured_grid, dtype=float)
            if reference_on_grid
            else np.unique(np.append(configured_grid, reference_coordinate))
        )
        evaluation_order = sorted(
            grid,
            key=lambda value: abs(float(value - reference_x[index])),
        )
        solutions = [reference_x.copy()]
        rows_by_value: dict[float, tuple[dict[str, Any], np.ndarray]] = {}
        for fixed_value in evaluation_order:
            start = min(solutions, key=lambda item: abs(float(item[index] - fixed_value)))
            x, fit = _fit_with_fixed_parameter(
                residual,
                start,
                index,
                float(fixed_value),
                lower,
                upper,
                max_nfev=max_nfev,
            )
            solutions.append(x)
            active_bounds = _active_bounds(x, lower, upper, names)
            row = {
                "value": parameter.from_opt(float(fixed_value)),
                "opt_value": float(fixed_value),
                "point_source": (
                    "configured_grid"
                    if bool(
                        np.any(
                            np.isclose(
                                configured_grid,
                                float(fixed_value),
                                rtol=1.0e-12,
                                atol=1.0e-12,
                            )
                        )
                    )
                    else "inserted_reference"
                ),
                "is_reference": bool(
                    np.isclose(
                        float(fixed_value),
                        reference_coordinate,
                        rtol=1.0e-12,
                        atol=1.0e-12,
                    )
                ),
                "measurement_sum_squares": 2.0 * float(fit["loss"]),
                "success": bool(fit["success"]),
                "message": str(fit["message"]),
                "nfev": int(fit["nfev"]),
                "conditional_parameters": _physical_values(params, x),
                "active_bounds": active_bounds,
                "conditional_active_bounds": [
                    bound for bound in active_bounds if bound["name"] != name
                ],
                "profile_value_at_bound": any(
                    bound["name"] == name for bound in active_bounds
                ),
            }
            rows_by_value[float(fixed_value)] = (row, x)
            all_points.append((name, row, x))

        physical_grid = [parameter.from_opt(float(value)) for value in sorted(grid)]
        reference_value = parameter.from_opt(float(reference_x[index]))
        configured_low = float(profile_config["range"][0])
        configured_high = float(profile_config["range"][1])
        profiles[name] = {
            "role": parameter.role,
            "scale": parameter.scale,
            "configured_range": [configured_low, configured_high],
            "effective_range": [float(physical_grid[0]), float(physical_grid[-1])],
            "reference_value": reference_value,
            "reference_inside_configured_range": bool(
                configured_low <= reference_value <= configured_high
            ),
            "requested_points": int(profile_config.get("points", 9)),
            "points": [rows_by_value[float(value)][0] for value in sorted(grid)],
        }
    return profiles, all_points


def _best_finite_profile_point(
    all_points: Sequence[tuple[str, dict[str, Any], np.ndarray]],
) -> tuple[str, dict[str, Any], np.ndarray] | None:
    finite_points = [
        point
        for point in all_points
        if np.isfinite(float(point[1]["measurement_sum_squares"]))
    ]
    if not finite_points:
        return None
    return min(
        finite_points,
        key=lambda item: float(item[1]["measurement_sum_squares"]),
    )


def _meaningfully_improves(candidate_loss: float, reference_loss: float) -> bool:
    tolerance = 1.0e-10 * max(1.0, abs(float(reference_loss)))
    return bool(
        np.isfinite(candidate_loss)
        and candidate_loss < float(reference_loss) - tolerance
    )


def evaluate_parameter_profiles(
    residual: ResidualFunction,
    params: ParameterSet,
    x_start: np.ndarray,
    config: Mapping[str, Any],
) -> dict[str, Any]:
    """Evaluate local conditional profiles for explicitly selected targets.

    Each selected target is fixed on its configured physical range.  Every
    other fitted parameter, including other targets and explicit nuisance
    parameters, is re-optimized against the measurement residual only.
    """

    lower, upper = params.bounds()
    profile_configs = list(config.get("parameters", []))
    max_nfev = int(config.get("max_nfev", 100))
    reference_x, reference_fit = _reference_fit(
        residual,
        params,
        np.asarray(x_start, dtype=float),
        lower,
        upper,
        max_nfev=max_nfev,
    )
    initial_reference_success = bool(reference_fit["success"])
    reference_source = "measurement_only_all_free"
    refinement_count = 0
    any_conditional_failure = False
    profiles, all_points = _evaluate_profiles_from_reference(
        residual,
        params,
        reference_x,
        profile_configs,
        lower,
        upper,
        max_nfev=max_nfev,
    )

    # A conditional scan can cross a basin boundary that the initial all-free
    # local solve did not.  Refine from the best discovered point, then rebuild
    # every requested profile from the same reference.  The number of passes is
    # bounded by the public maximum number of profile axes (currently two).
    for _ in range(len(profile_configs)):
        any_conditional_failure = any_conditional_failure or any(
            not bool(row["success"]) for _, row, _ in all_points
        )
        best_point = _best_finite_profile_point(all_points)
        if best_point is None:
            break
        best_name, best_row, best_x = best_point
        best_loss = 0.5 * float(best_row["measurement_sum_squares"])
        if not _meaningfully_improves(best_loss, float(reference_fit["loss"])):
            break
        reference_x, reference_fit = _reference_fit(
            residual,
            params,
            best_x,
            lower,
            upper,
            max_nfev=max_nfev,
        )
        refinement_count += 1
        reference_source = f"measurement_only_all_free_refined_from_profile_grid:{best_name}"
        profiles, all_points = _evaluate_profiles_from_reference(
            residual,
            params,
            reference_x,
            profile_configs,
            lower,
            upper,
            max_nfev=max_nfev,
        )

    any_conditional_failure = any_conditional_failure or any(
        not bool(row["success"]) for _, row, _ in all_points
    )
    reference_loss = float(reference_fit["loss"])
    unresolved_better_point = False
    best_final_point = _best_finite_profile_point(all_points)
    if best_final_point is not None:
        final_best_loss = 0.5 * float(best_final_point[1]["measurement_sum_squares"])
        unresolved_better_point = _meaningfully_improves(final_best_loss, reference_loss)

    for profile in profiles.values():
        for row in profile["points"]:
            row["delta_measurement_sum_squares"] = max(
                0.0,
                float(row["measurement_sum_squares"]) - 2.0 * reference_loss,
            )

    warnings: list[str] = []
    if not initial_reference_success:
        warnings.append("The initial all-free measurement-only reference optimization did not converge.")
    if not bool(reference_fit["success"]):
        warnings.append("The final all-free measurement-only reference optimization did not converge.")
    if refinement_count:
        warnings.append(
            "A fixed-grid point improved the all-free local reference; this is a local diagnostic, "
            "not a globally optimized profile."
        )
    if unresolved_better_point:
        warnings.append(
            "A fixed-grid point still improves the reference after bounded local refinement; "
            "zero-clipped deltas may represent more than one local basin."
        )
    if any_conditional_failure:
        warnings.append("At least one conditional profile optimization did not converge.")

    return {
        "kind": "local_conditional_measurement_objective",
        "basis": "measurement_data_only",
        "objective": "sum(whitened_measurement_residual**2)",
        "constraints_included": False,
        "other_parameters": "reoptimized_with_bounds",
        "global_search_per_grid_point": False,
        "reference": {
            "success": bool(reference_fit["success"]),
            "message": str(reference_fit["message"]),
            "nfev": int(reference_fit["nfev"]),
            "active_bounds": list(reference_fit["active_bounds"]),
            "measurement_sum_squares": 2.0 * reference_loss,
            "source": reference_source,
            "refinement_count": refinement_count,
            "parameters": dict(reference_fit["parameters"]),
        },
        "profiles": profiles,
        "warnings": warnings,
        "interpretation": (
            "delta_measurement_sum_squares is descriptive. It is not a calibrated confidence interval "
            "without an independently justified Gaussian likelihood and coverage study."
        ),
    }
