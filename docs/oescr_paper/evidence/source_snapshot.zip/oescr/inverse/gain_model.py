from __future__ import annotations

from collections.abc import Callable

import numpy as np
from scipy.optimize import least_squares, lsq_linear


def normalized_wavelength_axis(wavelength_nm: np.ndarray) -> np.ndarray:
    wl = np.asarray(wavelength_nm, dtype=float)
    if len(wl) == 0:
        return np.zeros(0, dtype=float)
    center = float(np.mean(wl))
    half_span = max(float(np.ptp(wl)) * 0.5, 1.0e-12)
    return (wl - center) / half_span


def apply_gain_offset_tilt(
    wavelength_nm: np.ndarray,
    y_pred: np.ndarray,
    gain: float,
    tilt: float = 0.0,
    offset: float = 0.0,
    wavelength_center_nm: float | None = None,
    wavelength_half_span_nm: float | None = None,
) -> np.ndarray:
    wl_axis = (
        normalized_wavelength_axis(wavelength_nm)
        if wavelength_center_nm is None
        else (np.asarray(wavelength_nm, dtype=float) - wavelength_center_nm)
        / max(float(wavelength_half_span_nm or 0.0), 1.0e-12)
    )
    return float(gain) * (1.0 + float(tilt) * wl_axis) * np.asarray(y_pred, dtype=float) + float(offset)


def fit_nuisance_corrections(
    residual: Callable[[np.ndarray], np.ndarray],
    initial: np.ndarray,
    lower_bounds: np.ndarray,
    *,
    linear: bool,
) -> np.ndarray:
    """Fit corrections against the caller's complete, already-whitened residual."""

    if linear:
        baseline = residual(np.zeros_like(initial))
        matrix = np.column_stack([residual(direction) - baseline for direction in np.eye(len(initial))])
        coefficients, *_ = np.linalg.lstsq(matrix, -baseline, rcond=None)
        if np.all(coefficients >= lower_bounds):
            return coefficients
        result = lsq_linear(matrix, -baseline, bounds=(lower_bounds, np.inf), tol=1.0e-12)
    else:
        result = least_squares(residual, initial, bounds=(lower_bounds, np.inf), x_scale="jac", max_nfev=100)
    if not result.success:
        raise ValueError(f"Nuisance optimization failed: {result.message}")
    return result.x
