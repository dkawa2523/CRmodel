from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any, Dict, List, Tuple

import numpy as np

from ..data.emission_kernels import compile_emission_kernel_inventory
from ..instrument.capability import instrument_capabilities
from ..instrument.spec import InstrumentSpec
from ..io.pathmap import get_path
from ..io.species_packs import compose_species_packs
from ..io.validators import validate_window_registry
from ..io.yaml_loader import load_yaml, resolve_path
from .gain_model import fit_nuisance_corrections
from .measurements import (
    Measurement,
    combined_residual_mask,
    spectrum_residual_blocks,
    whiten_feature_residuals,
)
from .priors import prior_residuals
from .spectral_fit import SpectralFit
from .window_metrics import (
    compute_window_feature_maps,
    low_signal_window_names,
    window_fit_residuals,
    window_mask,
    window_ratio_pair_residuals,
    window_ratio_residuals,
)
from .window_policy import (
    fit_pixel_mask,
    fit_windows,
    has_explicit_window_policy,
    window_coverage_report,
    windows_for_analysis_role,
)


def _validate_window_kernel_bindings(
    case_cfg: Dict[str, Any],
    windows: List[Dict[str, Any]],
    emission_kernel_inventory: Dict[str, Any] | None = None,
) -> None:
    linked_windows = [window for window in windows if "kernel_id" in window or "transition_id" in window]
    if not linked_windows:
        return

    if emission_kernel_inventory is None:
        inventory_cfg, _ = compose_species_packs(case_cfg)
        inventory = compile_emission_kernel_inventory(inventory_cfg)
    else:
        inventory_cfg = case_cfg
        inventory = emission_kernel_inventory
    kernels = {str(record["id"]): record for record in inventory["records"]}
    transitions = {
        str(transition["id"]): transition for transition in inventory_cfg.get("transitions", []) if "id" in transition
    }
    for window in linked_windows:
        name = str(window.get("name", "<unnamed>"))
        kernel_id = str(window.get("kernel_id", "")).strip()
        transition_id = str(window.get("transition_id", "")).strip()
        kernel = kernels.get(kernel_id)
        if kernel is None:
            raise ValueError(f"Window '{name}' references unknown emission kernel '{kernel_id}'.")
        if transition_id not in kernel["transition_ids"]:
            raise ValueError(
                f"Window '{name}' transition '{transition_id}' does not belong to emission kernel '{kernel_id}'."
            )
        transition = transitions.get(transition_id)
        if transition is None:
            raise ValueError(f"Window '{name}' references unknown transition '{transition_id}'.")
        wavelength_nm = float(transition["wavelength_nm"])
        center_nm = float(window["center_nm"])
        half_width_nm = float(window["half_width_nm"])
        if not center_nm - half_width_nm <= wavelength_nm <= center_nm + half_width_nm:
            raise ValueError(
                f"Window '{name}' does not contain transition '{transition_id}' wavelength "
                f"{wavelength_nm:g} nm within center_nm +/- half_width_nm "
                f"[{center_nm - half_width_nm:g}, {center_nm + half_width_nm:g}] nm."
            )


def _validate_held_out_window_separation(windows: List[Dict[str, Any]]) -> None:
    if not has_explicit_window_policy(windows):
        return
    fit_declared = fit_windows(windows)
    score_declared = windows_for_analysis_role(windows, "score")
    for fit_window in fit_declared:
        fit_center = float(fit_window["center_nm"])
        fit_half_width = float(fit_window["half_width_nm"])
        fit_interval = (fit_center - fit_half_width, fit_center + fit_half_width)
        for score_window in score_declared:
            score_center = float(score_window["center_nm"])
            score_half_width = float(score_window["half_width_nm"])
            score_interval = (
                score_center - score_half_width,
                score_center + score_half_width,
            )
            if max(fit_interval[0], score_interval[0]) <= min(fit_interval[1], score_interval[1]):
                raise ValueError(
                    "Explicit window policy has held-out leakage: fit window "
                    f"'{fit_window.get('name', '')}' overlaps score window "
                    f"'{score_window.get('name', '')}'."
                )


def load_windows(
    case_cfg: Dict[str, Any],
    inverse_cfg: Dict[str, Any] | None = None,
    *,
    emission_kernel_inventory: Dict[str, Any] | None = None,
) -> List[Dict[str, Any]]:
    if inverse_cfg is not None:
        # Any inverse mapping, normalized or not, owns wavelength selection.
        # Only the explicit ``None`` compatibility entry point may consult the
        # former case-level diagnostic registry.
        selection = inverse_cfg.get("window_selection", {"mode": "full_spectrum"})
        path_owner = inverse_cfg
        wf = selection.get("registry")
        include_names = set(selection.get("names", []))
        include_families = set(selection.get("families", []))
        exclude_names = set(selection.get("exclude_names", []))
        include_disabled = bool(selection.get("include_disabled", False))
    else:
        # Compatibility path for pre-v2 cases. New inverse configurations own
        # fit/score selection through ``window_selection``.
        selection = case_cfg.get("diagnostics", {})
        path_owner = case_cfg
        wf = selection.get("window_registry")
        include_names = set(selection.get("window_names", []))
        include_families = set(selection.get("window_families", []))
        exclude_names = set(selection.get("exclude_window_names", []))
        include_disabled = bool(selection.get("include_disabled_windows", False))
    if not wf:
        return []
    cfg = load_yaml(resolve_path(path_owner, wf))
    validate_window_registry(cfg)
    windows = list(cfg.get("windows", []))
    names: set[str] = set()
    for window in windows:
        name = str(window["name"])
        if name in names:
            raise ValueError(
                f"Window registry contains duplicate name '{name}'; window references must be unambiguous."
            )
        names.add(name)
    _validate_window_kernel_bindings(
        case_cfg,
        windows,
        emission_kernel_inventory,
    )

    filtered = []
    for w in windows:
        name = str(w.get("name", ""))
        fam = str(w.get("family", ""))
        if include_names and name not in include_names:
            continue
        if include_families and fam not in include_families:
            continue
        if name in exclude_names:
            continue
        filtered.append(w)
    selected_windows = filtered
    if not include_disabled:
        selected_windows = [
            window
            for window in filtered
            if bool(window.get("enabled", True)) and bool(window.get("default_enabled", True))
        ]
    _validate_held_out_window_separation(selected_windows)
    return selected_windows


def select_windows_for_instrument(
    inst_cfg: Dict[str, Any],
    windows: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    cap = instrument_capabilities(inst_cfg)
    inst = InstrumentSpec(inst_cfg)
    grid = inst.wavelength_grid_nm
    selected = []
    for w in windows:
        center = float(w["center_nm"])
        half = float(w.get("half_width_nm", 1.0))
        if center - half < grid.min() or center + half > grid.max():
            continue
        max_bin = w.get("max_bin_nm")
        if max_bin is not None:
            if "bin_nm" in inst_cfg:
                local_bin_nm = float(inst_cfg["bin_nm"])
            else:
                local_grid = grid[(grid >= center - half) & (grid <= center + half)]
                if len(local_grid) < 2:
                    continue
                local_bin_nm = float(np.max(np.diff(local_grid)))
            if local_bin_nm > float(max_bin):
                continue
        if w.get("requires_high_res", False) and not cap["high_res"]:
            continue
        selected.append(w)
    return selected


@dataclass(frozen=True)
class ObjectiveOptions:
    spectrum_weight: float
    window_fit_weight: float
    area_weight: float
    peak_weight: float
    window_min_relative_signal: float
    auto_gain: bool
    auto_offset: bool
    auto_gain_tilt: bool
    gain_scope: str
    baseline_mode: str
    window_normalization: str
    window_local_gain: bool
    ratio_weight: float
    ratio_metric: str
    ratio_reference: Any
    ratio_min_signal: float
    ratio_pairs: List[Dict[str, Any]]
    gain_prior_weight: float
    gain_prior_target: Any
    gain_prior_sigma: float
    gain_tilt_prior_weight: float
    gain_tilt_prior_sigma: float

    @classmethod
    def from_config(cls, cfg: Dict[str, Any]) -> "ObjectiveOptions":
        return cls(
            spectrum_weight=float(cfg.get("spectrum_weight", 1.0)),
            window_fit_weight=float(cfg.get("window_fit_weight", 0.0)),
            area_weight=float(cfg.get("area_weight", 0.0)),
            peak_weight=float(cfg.get("peak_weight", 0.0)),
            window_min_relative_signal=float(cfg.get("window_min_relative_signal", 0.02)),
            auto_gain=bool(cfg.get("auto_gain_fit", True)),
            auto_offset=bool(cfg.get("auto_offset_fit", True)),
            auto_gain_tilt=bool(cfg.get("auto_gain_tilt_fit", False)),
            gain_scope=str(cfg.get("auto_gain_scope", "chord")),
            baseline_mode=str(cfg.get("window_baseline_mode", "local_linear")),
            window_normalization=str(cfg.get("window_fit_normalization", "area")),
            window_local_gain=bool(cfg.get("window_fit_local_gain", False)),
            ratio_weight=float(cfg.get("window_ratio_weight", 0.0)),
            ratio_metric=str(cfg.get("window_ratio_metric", "peak")),
            ratio_reference=cfg.get("window_ratio_reference"),
            ratio_min_signal=float(cfg.get("window_ratio_min_relative_signal", 0.02)),
            ratio_pairs=list(cfg.get("window_ratio_pairs", [])),
            gain_prior_weight=float(cfg.get("gain_prior_weight", 0.0)),
            gain_prior_target=cfg.get("gain_prior_target"),
            gain_prior_sigma=float(cfg.get("gain_prior_sigma_log10", 1.0)),
            gain_tilt_prior_weight=float(cfg.get("gain_tilt_prior_weight", 0.0)),
            gain_tilt_prior_sigma=float(cfg.get("gain_tilt_prior_sigma", 1.0)),
        )


@dataclass(frozen=True)
class _ObjectiveInstrumentPlan:
    """Invariant measurement/window binding for one instrument."""

    instrument_id: str
    config: Dict[str, Any]
    fit_windows: List[Dict[str, Any]]
    measurements: tuple[Measurement, ...]
    analysis_masks: tuple[np.ndarray | None, ...]
    prediction_indices: tuple[np.ndarray, ...]
    declared_window_names: tuple[str, ...]
    fit_window_names: tuple[str, ...]
    window_coverage: Dict[str, Any]


@dataclass(frozen=True)
class _ObjectivePlan:
    """Static objective preparation reused across optimizer evaluations."""

    options: ObjectiveOptions
    instruments: tuple[_ObjectiveInstrumentPlan, ...]


@dataclass(frozen=True)
class _PreparedMeasurement:
    measurement: Measurement
    prediction: np.ndarray
    gain_offset: Dict[str, float]
    aux_key: tuple[str, str]
    analysis_mask: np.ndarray | None
    base_prediction: np.ndarray
    wavelength_axis: np.ndarray


@dataclass(frozen=True)
class _PreparedInstrument:
    config: Dict[str, Any]
    windows: List[Dict[str, Any]]
    measurements: List[_PreparedMeasurement]


def _objective_selection_mode(
    inv_cfg: Dict[str, Any],
    windows: List[Dict[str, Any]],
) -> str:
    if "window_selection" in inv_cfg:
        return str(inv_cfg["window_selection"]["mode"])
    return "window_union" if has_explicit_window_policy(windows) else "legacy_full_spectrum"


def _ordered_measurements(
    instrument_id: str,
    measurements: List[Measurement],
) -> tuple[Measurement, ...]:
    measurement_ids = [measurement.id for measurement in measurements]
    if any(not measurement_id for measurement_id in measurement_ids):
        raise ValueError("Every measurement must have a stable non-empty id before objective evaluation.")
    if len(set(measurement_ids)) != len(measurement_ids):
        raise ValueError(f"Measurement ids must be unique within instrument '{instrument_id}'.")

    ordered = tuple(sorted(measurements, key=lambda measurement: measurement.id))
    missing_bindings = [measurement.id for measurement in ordered if not measurement.prediction_key]
    if missing_bindings:
        raise ValueError(
            "Measurements must be normalized with explicit prediction_key bindings before "
            f"objective evaluation: {', '.join(missing_bindings)}."
        )
    return ordered


def _compile_instrument_objective_plan(
    instrument_id: str,
    instrument_config: Dict[str, Any],
    measurements: List[Measurement],
    windows: List[Dict[str, Any]],
    selection_mode: str,
) -> tuple[_ObjectiveInstrumentPlan, bool]:
    instrument_windows = select_windows_for_instrument(instrument_config, windows)
    fitted_windows = fit_windows(instrument_windows)
    ordered = _ordered_measurements(instrument_id, measurements)
    detector_grid = InstrumentSpec(instrument_config).wavelength_grid_nm
    prediction_indices = tuple(
        _measurement_pixel_indices(instrument_id, detector_grid, measurement) for measurement in ordered
    )
    analysis_masks = tuple(
        fit_pixel_mask(
            measurement.wavelength_nm,
            instrument_windows,
            selection_mode=selection_mode,
        )
        for measurement in ordered
    )
    has_selected_pixel = selection_mode != "window_union" or any(
        np.any(combined_residual_mask(measurement, analysis_mask))
        for measurement, analysis_mask in zip(
            ordered,
            analysis_masks,
            strict=True,
        )
    )
    plan = _ObjectiveInstrumentPlan(
        instrument_id=instrument_id,
        config=instrument_config,
        fit_windows=fitted_windows,
        measurements=ordered,
        analysis_masks=analysis_masks,
        prediction_indices=prediction_indices,
        declared_window_names=tuple(str(window.get("name", "")) for window in instrument_windows),
        fit_window_names=tuple(str(window.get("name", "")) for window in fitted_windows),
        window_coverage=window_coverage_report(
            instrument_windows,
            selection_mode=selection_mode,
        ),
    )
    return plan, has_selected_pixel


def _measurement_pixel_indices(
    instrument_id: str,
    detector_grid: np.ndarray,
    measurement: Measurement,
) -> np.ndarray:
    """Bind bin-average samples to detector pixels, allowing CSV rounding."""

    wavelength = measurement.wavelength_nm
    insertion = np.searchsorted(detector_grid, wavelength)
    left = np.maximum(insertion - 1, 0)
    right = np.minimum(insertion, len(detector_grid) - 1)
    indices = np.where(
        np.abs(wavelength - detector_grid[left]) <= np.abs(wavelength - detector_grid[right]),
        left,
        right,
    )
    matched = np.isclose(wavelength, detector_grid[indices], rtol=0.0, atol=1.0e-8)
    invalid = combined_residual_mask(measurement) & ~matched
    if np.any(invalid):
        value = float(wavelength[np.flatnonzero(invalid)[0]])
        raise ValueError(
            f"Instrument '{instrument_id}', measurement '{measurement.id}': valid pixel at {value:.12g} nm "
            "does not match the detector grid. Set instrument.wavelength_grid_nm to the actual detector "
            "pixel centers; retain the measured bin averages without resampling."
        )
    indices[~matched] = -1
    return indices


def _compile_objective_plan(
    instrument_configs: List[Dict[str, Any]],
    measurements: Dict[str, List[Measurement]],
    windows: List[Dict[str, Any]],
    inv_cfg: Dict[str, Any],
) -> _ObjectivePlan:
    """Compile only data that cannot change during one inverse problem."""

    selection_mode = _objective_selection_mode(inv_cfg, windows)
    options = ObjectiveOptions.from_config(inv_cfg.get("fit", {}).get("objective", {}))
    _validate_objective_window_references(windows, options)
    instrument_config_by_id = {str(config["id"]): config for config in instrument_configs}
    instrument_plans: List[_ObjectiveInstrumentPlan] = []
    selected_pixel_flags: List[bool] = []
    for instrument_id in sorted(measurements):
        if instrument_id not in instrument_config_by_id:
            raise ValueError(f"Measurements reference unknown instrument '{instrument_id}'.")
        instrument_plan, has_selected_pixel = _compile_instrument_objective_plan(
            instrument_id,
            instrument_config_by_id[instrument_id],
            measurements[instrument_id],
            windows,
            selection_mode,
        )
        instrument_plans.append(instrument_plan)
        selected_pixel_flags.append(has_selected_pixel)
    if selection_mode == "window_union" and not any(selected_pixel_flags):
        raise ValueError(
            "Explicit window policy selected no valid physical-fit pixels across the inverse "
            "problem. Declare at least one analysis_role='fit', model_coverage='physical' "
            "window that overlaps a valid measured wavelength."
        )
    return _ObjectivePlan(
        options=options,
        instruments=tuple(instrument_plans),
    )


def _validate_objective_window_references(
    windows: List[Dict[str, Any]],
    options: ObjectiveOptions,
) -> None:
    names = {str(window.get("name", "")) for window in fit_windows(windows)}
    for pair in options.ratio_pairs:
        for key in ("numerator", "denominator"):
            if str(pair[key]) not in names:
                raise ValueError(f"Ratio {key} references unknown or non-fit window '{pair[key]}'.")
        if pair["numerator"] == pair["denominator"]:
            raise ValueError("A ratio must reference two different fit windows.")
    if options.ratio_reference is not None and str(options.ratio_reference) not in names:
        raise ValueError(f"Ratio reference uses unknown or non-fit window '{options.ratio_reference}'.")


def _gain_prior_terms(
    gain_offset: Dict[str, float],
    inst_cfg: Dict[str, Any],
    options: ObjectiveOptions,
) -> List[float]:
    terms: List[float] = []
    if options.gain_prior_weight > 0.0:
        gain = max(float(gain_offset["gain"]), 1.0e-12)
        target = options.gain_prior_target
        if target is None:
            target = inst_cfg.get("nuisance", {}).get("gain", 1.0)
        difference = np.log10(gain) - np.log10(max(float(target), 1.0e-12))
        terms.append(float(np.sqrt(options.gain_prior_weight) * difference / max(options.gain_prior_sigma, 1.0e-12)))
    if options.gain_tilt_prior_weight > 0.0:
        terms.append(
            float(
                np.sqrt(options.gain_tilt_prior_weight)
                * gain_offset["tilt"]
                / max(options.gain_tilt_prior_sigma, 1.0e-12)
            )
        )
    return terms


def _window_residual_terms(
    measurement: Measurement,
    predicted: np.ndarray,
    windows: List[Dict[str, Any]],
    options: ObjectiveOptions,
    covariance_names: set[str],
) -> tuple[
    List[float],
    Dict[str, float],
    Dict[str, Dict[str, float]],
    Dict[str, Dict[str, float]],
    List[str],
]:
    valid = combined_residual_mask(measurement)
    wavelength_nm = measurement.wavelength_nm[valid]
    predicted_valid = predicted[valid]
    measured_valid = measurement.intensity[valid]
    predicted_features, measured_features = compute_window_feature_maps(
        wavelength_nm,
        predicted_valid,
        measured_valid,
        windows,
        default_baseline_mode=options.baseline_mode,
    )
    low_signal = set(
        low_signal_window_names(
            windows,
            measured_features,
            options.window_min_relative_signal,
        )
    )
    terms: List[float] = []
    feature_residuals: Dict[str, float] = {}
    for window in windows:
        name = str(window.get("name", ""))
        if name in low_signal:
            continue
        center = float(window["center_nm"])
        half_width = float(window.get("half_width_nm", 1.0))
        baseline = str(window.get("baseline_mode", options.baseline_mode))
        normalization = str(window.get("window_fit_normalization", options.window_normalization))
        local_gain = bool(window.get("window_fit_local_gain", options.window_local_gain))
        window_weight = float(window.get("window_fit_weight", options.window_fit_weight))
        area_weight = float(window.get("area_weight", options.area_weight))
        peak_weight = float(window.get("peak_weight", options.peak_weight))
        sample_count = int(np.count_nonzero(window_mask(wavelength_nm, center, half_width)))

        if (
            bool(window.get("use_window_fit", window_weight > 0.0))
            and window_weight > 0.0
            and (sample_count >= 2 or normalization in {"none", "off", "disabled"})
        ):
            values = window_fit_residuals(
                wavelength_nm,
                predicted_valid,
                measured_valid,
                center,
                half_width,
                baseline_mode=baseline,
                normalization=normalization,
                local_gain=local_gain,
            )
            terms.extend((np.sqrt(window_weight) * values).tolist())

        predicted_feature = predicted_features[name]
        measured_feature = measured_features[name]
        area_key = f"window:{name}:area"
        if (
            sample_count >= 2
            and bool(window.get("use_area", True))
            and (area_weight > 0.0 or area_key in covariance_names)
        ):
            denominator = max(abs(measured_feature["area"]), 1.0e-30)
            area_residual = (predicted_feature["area"] - measured_feature["area"]) / denominator
            feature_residuals[area_key] = area_residual
            if area_weight > 0.0 and area_key not in covariance_names:
                terms.append(np.sqrt(area_weight) * area_residual)
        peak_key = f"window:{name}:peak"
        if bool(window.get("use_peak", True)) and (peak_weight > 0.0 or peak_key in covariance_names):
            denominator = max(abs(measured_feature["peak"]), 1.0e-30)
            peak_residual = (predicted_feature["peak"] - measured_feature["peak"]) / denominator
            feature_residuals[peak_key] = peak_residual
            if peak_weight > 0.0 and peak_key not in covariance_names:
                terms.append(np.sqrt(peak_weight) * peak_residual)
    return terms, feature_residuals, predicted_features, measured_features, sorted(low_signal)


def _ratio_residual_terms(
    windows: List[Dict[str, Any]],
    predicted_features: Dict[str, Dict[str, float]],
    measured_features: Dict[str, Dict[str, float]],
    options: ObjectiveOptions,
    covariance_names: set[str],
) -> tuple[List[float], List[str], Dict[str, float]]:
    if options.ratio_weight <= 0.0 and not options.ratio_pairs:
        return [], [], {}
    if not options.ratio_pairs:
        values = window_ratio_residuals(
            windows,
            predicted_features,
            measured_features,
            metric=options.ratio_metric,
            reference_window=(str(options.ratio_reference) if options.ratio_reference is not None else None),
            min_relative_signal=options.ratio_min_signal,
        )
        return (np.sqrt(options.ratio_weight) * values).tolist(), [], {}

    residual_map = window_ratio_pair_residuals(
        predicted_features,
        measured_features,
        options.ratio_pairs,
        default_metric=options.ratio_metric,
        default_min_relative_signal=options.ratio_min_signal,
    )
    terms: List[float] = []
    names: List[str] = []
    feature_residuals: Dict[str, float] = {}
    for pair_index in sorted(residual_map):
        pair = options.ratio_pairs[pair_index]
        pair_weight = float(pair.get("weight", options.ratio_weight))
        values = residual_map[pair_index]
        pair_name = str(pair.get("name", f"pair_{pair_index}"))
        feature_key = f"ratio:{pair_name}"
        feature_residuals[feature_key] = float(values[0])
        if pair_weight > 0.0 and feature_key not in covariance_names:
            terms.extend((np.sqrt(pair_weight) * values).tolist())
        names.append(pair_name)
    return terms, names, feature_residuals


def _uses_window_objective(
    windows: List[Dict[str, Any]],
    options: ObjectiveOptions,
    covariance_names: set[str],
) -> bool:
    """Return whether this observation needs any window feature work."""

    if not windows:
        return False
    if covariance_names or options.ratio_weight > 0.0:
        return True
    if any(float(pair.get("weight", options.ratio_weight)) > 0.0 for pair in options.ratio_pairs):
        return True
    for window in windows:
        window_weight = float(window.get("window_fit_weight", options.window_fit_weight))
        if bool(window.get("use_window_fit", window_weight > 0.0)) and window_weight > 0.0:
            return True
        area_weight = float(window.get("area_weight", options.area_weight))
        if bool(window.get("use_area", True)) and area_weight > 0.0:
            return True
        peak_weight = float(window.get("peak_weight", options.peak_weight))
        if bool(window.get("use_peak", True)) and peak_weight > 0.0:
            return True
    return False


def _prepare_instrument_measurements(
    plan: _ObjectiveInstrumentPlan,
    predictions: Dict[str, Dict[str, np.ndarray]],
    options: ObjectiveOptions,
    details: Dict[str, Any] | None,
) -> _PreparedInstrument:
    unknown_bindings = {
        measurement.prediction_key for measurement in plan.measurements if measurement.prediction_key not in predictions
    }
    if unknown_bindings:
        raise ValueError(
            f"Instrument '{plan.instrument_id}' has no forward predictions for keys: "
            f"{', '.join(sorted(unknown_bindings))}."
        )

    basis_wavelengths = [
        measurement.wavelength_nm[combined_residual_mask(measurement, analysis_mask)]
        for measurement, analysis_mask in zip(plan.measurements, plan.analysis_masks, strict=True)
    ]
    if options.gain_scope == "instrument":
        shared_wavelengths = np.concatenate(basis_wavelengths)
        basis_wavelengths = [shared_wavelengths] * len(plan.measurements)

    prepared_measurements: List[_PreparedMeasurement] = []
    for measurement_index, measurement in enumerate(plan.measurements):
        prediction = predictions[measurement.prediction_key]
        indices = plan.prediction_indices[measurement_index]
        matched = indices >= 0
        sampled = np.full(measurement.wavelength_nm.shape, np.nan, dtype=float)
        sampled[matched] = prediction["intensity"][indices[matched]]
        gain_offset = {"gain": 1.0, "offset": 0.0, "tilt": 0.0}
        wavelength = np.asarray(measurement.wavelength_nm, dtype=float)
        basis = basis_wavelengths[measurement_index]
        center = float(np.mean(basis)) if len(basis) else 0.0
        half_span = max(float(np.ptp(basis)) * 0.5, 1.0e-12) if len(basis) else 1.0
        if options.auto_gain_tilt:
            gain_offset.update(wavelength_center_nm=center, wavelength_half_span_nm=half_span)
        aux_key = (plan.instrument_id, measurement.id)
        analysis_mask = plan.analysis_masks[measurement_index]
        if details is not None:
            combined_mask = combined_residual_mask(measurement, analysis_mask)
            details["fit_pixel_selection"][aux_key] = {
                "mode": plan.window_coverage["selection_mode"],
                "selected_count": int(np.sum(combined_mask)),
                "total_count": int(len(combined_mask)),
            }
        prepared_measurements.append(
            _PreparedMeasurement(
                measurement=measurement,
                prediction=sampled,
                gain_offset=gain_offset,
                aux_key=aux_key,
                analysis_mask=analysis_mask,
                base_prediction=sampled,
                wavelength_axis=(wavelength - center) / half_span,
            )
        )

    return _PreparedInstrument(
        config=plan.config,
        windows=plan.fit_windows,
        measurements=prepared_measurements,
    )


def _append_window_objective(
    residuals: List[float],
    details: Dict[str, Any] | None,
    prepared: _PreparedMeasurement,
    windows: List[Dict[str, Any]],
    options: ObjectiveOptions,
) -> None:
    measurement = prepared.measurement
    covariance_names = (
        set(measurement.feature_covariance.names) if measurement.feature_covariance is not None else set()
    )
    if details is not None:
        details["feature_covariance_used"][prepared.aux_key] = sorted(covariance_names)
    if not covariance_names and not _uses_window_objective(windows, options, covariance_names):
        if details is not None:
            details["skipped_windows_low_signal"][prepared.aux_key] = []
            details["ratio_pairs_used"][prepared.aux_key] = []
        return

    valid_wavelength = measurement.wavelength_nm[combined_residual_mask(measurement)]
    windows = [
        window
        for window in windows
        if np.any(window_mask(valid_wavelength, float(window["center_nm"]), float(window.get("half_width_nm", 1.0))))
    ]
    window_terms, feature_residuals, pred_feats, meas_feats, low_signal = _window_residual_terms(
        measurement,
        prepared.prediction,
        windows,
        options,
        covariance_names,
    )
    residuals.extend(window_terms)
    if details is not None:
        details["skipped_windows_low_signal"][prepared.aux_key] = low_signal
    ratio_terms, pair_names, ratio_feature_residuals = _ratio_residual_terms(
        windows,
        pred_feats,
        meas_feats,
        options,
        covariance_names,
    )
    residuals.extend(ratio_terms)
    if details is not None:
        details["ratio_pairs_used"][prepared.aux_key] = pair_names
    feature_residuals.update(ratio_feature_residuals)
    residuals.extend(whiten_feature_residuals(measurement, feature_residuals).tolist())


def _regularization_residuals(case_cfg: Dict[str, Any], inv_cfg: Dict[str, Any]) -> List[float]:
    terms: List[float] = []
    for regularizer in inv_cfg.get("fit", {}).get("regularization", {}).get("smooth_arrays", []):
        path = regularizer.get("path")
        if path is None:
            continue
        values = np.asarray(get_path(case_cfg, str(path)), dtype=float)
        weight = float(regularizer.get("weight", 0.1))
        order = int(regularizer.get("order", 2))
        scale = max(float(np.std(values)), 1.0)
        if len(values) >= 3 and order == 2:
            terms.extend((np.sqrt(weight) * np.diff(values, n=2) / scale).tolist())
        elif len(values) >= 2 and order == 1:
            terms.extend((np.sqrt(weight) * np.diff(values) / scale).tolist())
    return terms


def _prepare_objective_instruments(
    plan: _ObjectivePlan,
    forward_spectra: Dict[str, Dict[str, Dict[str, np.ndarray]]],
    details: Dict[str, Any] | None,
) -> List[_PreparedInstrument]:
    """Resolve window policy and bind all observations before whitening."""

    prepared_instruments: List[_PreparedInstrument] = []
    for instrument_plan in plan.instruments:
        instrument_id = instrument_plan.instrument_id
        if instrument_id not in forward_spectra:
            raise ValueError(f"Forward prediction did not produce instrument '{instrument_id}'.")
        if details is not None:
            details["declared_windows"][instrument_id] = list(instrument_plan.declared_window_names)
            details["selected_windows"][instrument_id] = list(instrument_plan.fit_window_names)
            details["fit_windows"][instrument_id] = list(instrument_plan.fit_window_names)
            details["window_coverage"][instrument_id] = instrument_plan.window_coverage
        prepared_instruments.append(
            _prepare_instrument_measurements(
                instrument_plan,
                forward_spectra[instrument_id],
                plan.options,
                details,
            )
        )
    return prepared_instruments


def _spectrum_blocks_for_objective(
    prepared_instruments: List[_PreparedInstrument],
    options: ObjectiveOptions,
) -> List[np.ndarray]:
    if options.spectrum_weight <= 0.0:
        return []
    prepared_measurements = [prepared for instrument in prepared_instruments for prepared in instrument.measurements]
    return spectrum_residual_blocks(
        [(prepared.measurement, prepared.prediction) for prepared in prepared_measurements],
        analysis_masks=[prepared.analysis_mask for prepared in prepared_measurements],
    )


def _data_residual_vector(
    instruments: List[_PreparedInstrument],
    options: ObjectiveOptions,
    include_constraints: bool,
    details: Dict[str, Any] | None = None,
) -> np.ndarray:
    terms: List[float] = []
    nuisance_priors: List[float] = []
    spectrum_blocks = iter(_spectrum_blocks_for_objective(instruments, options))
    for instrument in instruments:
        active_measurements = [
            prepared
            for prepared in instrument.measurements
            if np.any(combined_residual_mask(prepared.measurement, prepared.analysis_mask))
        ]
        prior_measurements = active_measurements[:1] if options.gain_scope == "instrument" else active_measurements
        if include_constraints:
            for prepared in prior_measurements:
                nuisance_priors.extend(_gain_prior_terms(prepared.gain_offset, instrument.config, options))
        for prepared in instrument.measurements:
            if options.spectrum_weight > 0.0:
                terms.extend((np.sqrt(options.spectrum_weight) * next(spectrum_blocks)).tolist())
            _append_window_objective(terms, details, prepared, instrument.windows, options)
    if not terms:
        raise ValueError(
            "The inverse problem has no effective measurement objective after window coverage, QC, and signal selection."
        )
    terms.extend(nuisance_priors)
    return np.asarray(terms, dtype=float)


def _profile_nuisance(
    instruments: List[_PreparedInstrument],
    options: ObjectiveOptions,
    include_constraints: bool,
) -> List[_PreparedInstrument]:
    """Use the final objective for nuisance fitting, including its whitening.

    Spectra alone are affine in gain, gain-times-tilt, and offset. Solve that
    small WLS problem directly; only feature objectives or nuisance priors need
    a nonlinear inner solve. Calibration groups are whitened together here.
    """

    if not options.auto_gain:
        return instruments
    groups: List[tuple[int, List[int], float, float]] = []
    for instrument_index, instrument in enumerate(instruments):
        member_groups = (
            [list(range(len(instrument.measurements)))]
            if options.gain_scope == "instrument"
            else [[index] for index in range(len(instrument.measurements))]
        )
        for members in member_groups:
            measured = np.concatenate(
                [
                    instrument.measurements[i].measurement.intensity[
                        combined_residual_mask(
                            instrument.measurements[i].measurement, instrument.measurements[i].analysis_mask
                        )
                    ]
                    for i in members
                ]
            )
            predicted = np.concatenate(
                [
                    instrument.measurements[i].base_prediction[
                        combined_residual_mask(
                            instrument.measurements[i].measurement, instrument.measurements[i].analysis_mask
                        )
                    ]
                    for i in members
                ]
            )
            if len(measured) == 0:
                continue
            signal_scale = max(float(np.max(np.abs(measured), initial=0.0)), 1.0e-30)
            prediction_scale = float(np.max(np.abs(predicted), initial=0.0))
            gain_scale = signal_scale / prediction_scale if prediction_scale > 0.0 else 1.0
            if include_constraints and options.gain_prior_weight > 0.0:
                gain_scale = float(options.gain_prior_target or instrument.config.get("nuisance", {}).get("gain", 1.0))
            groups.append((instrument_index, members, gain_scale, signal_scale))
    if not groups:
        return instruments
    width = 1 + int(options.auto_gain_tilt) + int(options.auto_offset)
    gain_indices = list(range(0, len(groups) * width, width))
    lower = np.full(len(groups) * width, -np.inf)
    lower[gain_indices] = [1.0e-12 / group[2] for group in groups]

    def corrected(x: np.ndarray) -> List[_PreparedInstrument]:
        updated = [replace(instrument, measurements=list(instrument.measurements)) for instrument in instruments]
        for group_index, (instrument_index, members, gain_scale, offset_scale) in enumerate(groups):
            coordinates = x[group_index * width : (group_index + 1) * width]
            gain = float(coordinates[0]) * gain_scale
            tilt_coefficient = float(coordinates[1]) * gain_scale if options.auto_gain_tilt else 0.0
            offset = float(coordinates[-1]) * offset_scale if options.auto_offset else 0.0
            instrument = updated[instrument_index]
            for index in members:
                original = instruments[instrument_index].measurements[index]
                correction = dict(original.gain_offset)
                correction.update(gain=gain, tilt=tilt_coefficient / max(gain, 1.0e-300), offset=offset)
                instrument.measurements[index] = replace(
                    original,
                    prediction=original.base_prediction * (gain + tilt_coefficient * original.wavelength_axis) + offset,
                    gain_offset=correction,
                )
        return updated

    def objective(x: np.ndarray) -> np.ndarray:
        return _data_residual_vector(corrected(x), options, include_constraints)

    x0 = np.zeros(len(groups) * width, dtype=float)
    x0[gain_indices] = 1.0
    x0 = np.maximum(x0, lower)
    has_features = any(
        _uses_window_objective(
            instrument.windows,
            options,
            set(prepared.measurement.feature_covariance.names)
            if prepared.measurement.feature_covariance is not None
            else set(),
        )
        for instrument in instruments
        for prepared in instrument.measurements
    )
    nonlinear = has_features or (
        include_constraints and (options.gain_prior_weight > 0.0 or options.gain_tilt_prior_weight > 0.0)
    )
    x_opt = fit_nuisance_corrections(objective, x0, lower, linear=not nonlinear)
    return corrected(x_opt)


def _spectral_fit_records(
    prepared_instruments: List[_PreparedInstrument],
) -> List[SpectralFit]:
    records: List[SpectralFit] = []
    for instrument in prepared_instruments:
        instrument_id = str(instrument.config["id"])
        for prepared in instrument.measurements:
            measurement = prepared.measurement
            records.append(
                SpectralFit(
                    instrument_id=instrument_id,
                    observation_id=measurement.id,
                    prediction_key=measurement.prediction_key,
                    output_basis=measurement.output_basis,
                    output_unit=measurement.output_unit,
                    wavelength_nm=np.asarray(measurement.wavelength_nm, dtype=float).copy(),
                    measured=np.asarray(measurement.intensity, dtype=float).copy(),
                    predicted=np.asarray(prepared.prediction, dtype=float).copy(),
                    sigma=(None if measurement.sigma is None else np.asarray(measurement.sigma, dtype=float).copy()),
                    used_for_fit=combined_residual_mask(
                        measurement,
                        prepared.analysis_mask,
                    ).copy(),
                )
            )
    return records


def residual_vector(
    model,
    case_cfg: Dict[str, Any],
    inv_cfg: Dict[str, Any],
    measurements: Dict[str, List[Measurement]],
    windows: List[Dict[str, Any]],
    *,
    include_constraints: bool = True,
    collect_details: bool = True,
    collect_spectral_fits: bool = False,
    _plan: _ObjectivePlan | None = None,
) -> Tuple[np.ndarray, Dict[str, Any]]:
    """Build measurement residuals, optionally followed by prior constraints.

    Optimization and conditional-curvature calculations use the complete
    objective. Local observability must set ``include_constraints=False`` so
    priors and smoothness cannot create artificial measurement rank.
    """

    predict_context = getattr(model, "predict_spectra_context", None)
    if callable(predict_context):
        predicted_spectra, instrument_configs = predict_context(case_cfg)
    else:
        predict_spectra = getattr(model, "predict_spectra", None)
        predicted_spectra = predict_spectra(case_cfg) if callable(predict_spectra) else model.predict(case_cfg).spectra
        instrument_configs = model.instrument_configs_for(case_cfg)
    plan = _plan or _compile_objective_plan(
        instrument_configs,
        measurements,
        windows,
        inv_cfg,
    )
    options = plan.options
    residuals: List[float] = []
    aux: Dict[str, Any] = {}
    details: Dict[str, Any] | None = None
    if collect_details:
        aux = {
            "gain_offset": {},
            "declared_windows": {},
            "selected_windows": {},
            "fit_windows": {},
            "window_coverage": {},
            "fit_pixel_selection": {},
            "ratio_pairs_used": {},
            "skipped_windows_low_signal": {},
            "feature_covariance_used": {},
        }
        details = aux

    # Prepare every fitted spectrum before whitening.  Calibration group ids
    # are global, so repeated observations can share one scale systematic even
    # when they were collected through different instrument definitions.
    prepared_instruments = _prepare_objective_instruments(
        plan,
        predicted_spectra,
        details,
    )
    prepared_instruments = _profile_nuisance(prepared_instruments, options, include_constraints)
    residuals.extend(_data_residual_vector(prepared_instruments, options, include_constraints, details).tolist())
    if details is not None:
        for instrument in prepared_instruments:
            for prepared in instrument.measurements:
                details["gain_offset"][prepared.aux_key] = dict(prepared.gain_offset)
    if collect_spectral_fits:
        aux["spectral_fits"] = _spectral_fit_records(prepared_instruments)

    if include_constraints:
        residuals.extend(prior_residuals(case_cfg, inv_cfg).tolist())
        residuals.extend(_regularization_residuals(case_cfg, inv_cfg))
    return np.asarray(residuals, dtype=float), aux
