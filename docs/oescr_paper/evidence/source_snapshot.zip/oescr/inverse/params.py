
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Sequence, Tuple

import numpy as np

from ..io.pathmap import get_path, set_path


@dataclass
class Parameter:
    name: str
    path: str
    bounds: Tuple[float, float]
    scale: str = "linear"
    role: str = "target"

    def to_opt(self, physical: float) -> float:
        if self.scale == "log":
            return float(np.log10(physical))
        return float(physical)

    def from_opt(self, opt_value: float) -> float:
        if self.scale == "log":
            return float(10.0 ** opt_value)
        return float(opt_value)

    @property
    def opt_bounds(self) -> Tuple[float, float]:
        if self.scale == "log":
            return float(np.log10(self.bounds[0])), float(np.log10(self.bounds[1]))
        return self.bounds


class ParameterSet:
    def __init__(self, params_cfg: Sequence[Dict[str, Any]]) -> None:
        self.params: List[Parameter] = []
        for p in params_cfg:
            role = str(p.get("role", "target"))
            if role not in {"target", "nuisance"}:
                raise ValueError(
                    f"Parameter '{p['name']}' has invalid role '{role}'; "
                    "expected 'target' or 'nuisance'."
                )
            self.params.append(
                Parameter(
                    name=p["name"],
                    path=p["path"],
                    bounds=(float(p["bounds"][0]), float(p["bounds"][1])),
                    scale=p.get("scale", "linear"),
                    role=role,
                )
            )

    def initial_vector(self, case_cfg: Dict[str, Any]) -> np.ndarray:
        vals = []
        for p in self.params:
            vals.append(p.to_opt(float(get_path(case_cfg, p.path))))
        return np.asarray(vals, dtype=float)

    def bounds(self) -> Tuple[np.ndarray, np.ndarray]:
        lo = []
        hi = []
        for p in self.params:
            a, b = p.opt_bounds
            lo.append(a)
            hi.append(b)
        return np.asarray(lo, dtype=float), np.asarray(hi, dtype=float)

    def apply_to_case(self, case_cfg: Dict[str, Any], x: np.ndarray) -> Dict[str, Any]:
        out = case_cfg
        for p, xv in zip(self.params, x, strict=True):
            set_path(out, p.path, p.from_opt(float(xv)))
        return out

    def physical_values(self, x: np.ndarray) -> Dict[str, float]:
        """Return named physical values from the optimizer-coordinate vector."""

        if len(x) != len(self.params):
            raise ValueError("Optimization vector length does not match the parameter definition.")
        return {
            parameter.name: parameter.from_opt(float(value))
            for parameter, value in zip(self.params, x, strict=True)
        }

    def names(self, role: str | None = None) -> List[str]:
        if role is None:
            return [p.name for p in self.params]
        return [p.name for p in self.params if p.role == role]

    def roles(self) -> List[str]:
        return [p.role for p in self.params]
