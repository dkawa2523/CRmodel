from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Dict

import numpy as np
from scipy.optimize import differential_evolution, least_squares

from ..forward.model import OESCRModel
from ..instrument.calibration import CalibrationTransform
from ..instrument.capability import all_instruments_low_res
from ..io.normalize import normalize_inverse_config
from ..io.validators import validate_inverse_config, validate_inverse_structural
from ..io.yaml_loader import load_yaml
from ..physics.eedf import eedf_model_kind
from .identifiability import (
    finite_difference_jacobian,
    implicit_nuisance_handling,
    summarize_identifiability_jacobian,
)
from .laplace import covariance_from_jacobian, summarize_covariance
from .measurements import load_canonical_measurements
from .objectives import _compile_objective_plan, load_windows, residual_vector
from .params import ParameterSet
from .profiles import evaluate_parameter_profiles
from .spectral_fit import SpectralFit
from .use_cases import assess_inference_use_case


@dataclass
class FitResult:
    x_opt: np.ndarray
    case_opt: Dict[str, Any]
    cost: float
    success: bool
    message: str
    aux: Dict[str, Any]
    parameters: Dict[str, float] = field(default_factory=dict)
    spectral_fits: list[SpectralFit] = field(default_factory=list)
    uncertainty: Dict[str, Any] | None = None
    identifiability: Dict[str, Any] | None = None
    forward_quality: Dict[str, Any] | None = None
    assessment: Dict[str, Any] | None = None
    calibration_uncertainty: Dict[str, float] | None = None
    optimization_trace: list[Dict[str, Any]] | None = None
    parameter_profiles: Dict[str, Any] | None = None


_RUNTIME_PARAMETER_ROOTS = {"plasma_state", "eedf", "residuals"}


def _parameter_root(path: str) -> str:
    return path.split(".", 1)[0].split("[", 1)[0]


class InverseSolver:
    def __init__(self, case_cfg: Dict[str, Any], inv_cfg: Dict[str, Any]) -> None:
        validate_inverse_structural(inv_cfg)
        self.model = OESCRModel(case_cfg)
        case_cfg = self.model.cfg
        inv_cfg = normalize_inverse_config(case_cfg, inv_cfg)
        validate_inverse_config(case_cfg, inv_cfg)
        self.case_cfg = deepcopy(case_cfg)
        self.inv_cfg = deepcopy(inv_cfg)
        self.params = ParameterSet(self.inv_cfg["parameters"])
        instrument_cfgs = self.model.instrument_configs_for()
        self._instrument_cfgs = instrument_cfgs
        self.assessment = assess_inference_use_case(
            self.case_cfg,
            self.inv_cfg,
            (parameter.path for parameter in self.params.params),
            instrument_cfgs,
        )
        self.measurements = load_canonical_measurements(self.inv_cfg, instrument_cfgs)
        self.windows = load_windows(
            self.case_cfg,
            self.inv_cfg,
            emission_kernel_inventory=self.model.emission_kernel_inventory(),
        )
        runtime_only = bool(self.params.params) and all(
            _parameter_root(parameter.path) in _RUNTIME_PARAMETER_ROOTS for parameter in self.params.params
        )
        self._residual_model = self.model.runtime_spectrum_model() if runtime_only else self.model
        self._objective_plan = (
            _compile_objective_plan(
                instrument_cfgs,
                self.measurements,
                self.windows,
                self.inv_cfg,
            )
            if runtime_only
            else None
        )
        self._enforce_capabilities()

    @classmethod
    def from_yaml(cls, case_path: str | Path, inverse_path: str | Path) -> "InverseSolver":
        case_cfg = load_yaml(case_path)
        inv_cfg = load_yaml(inverse_path)
        return cls(case_cfg, inv_cfg)

    def _enforce_capabilities(self) -> None:
        if eedf_model_kind(self.case_cfg) == "eedf_tabulated" and all_instruments_low_res(
            self.model.instrument_configs_for()
        ):
            raise ValueError("Low-resolution instruments are restricted to 'te' or 'eedf_bimaxwell' inverse modes.")

    def _objective_residual(self, x: np.ndarray) -> np.ndarray:
        cfg = deepcopy(self.case_cfg)
        self.params.apply_to_case(cfg, x)
        r, _ = residual_vector(
            self._residual_model,
            cfg,
            self.inv_cfg,
            self.measurements,
            self.windows,
            collect_details=False,
            _plan=self._objective_plan,
        )
        return r

    def _measurement_residual(self, x: np.ndarray) -> np.ndarray:
        cfg = deepcopy(self.case_cfg)
        self.params.apply_to_case(cfg, x)
        residual, _ = residual_vector(
            self._residual_model,
            cfg,
            self.inv_cfg,
            self.measurements,
            self.windows,
            include_constraints=False,
            collect_details=False,
            _plan=self._objective_plan,
        )
        return residual

    def fit(self, *, record_trace: bool = False, audit: bool = False) -> FitResult:
        """Optimize the configured parameters and optionally run post-fit audits.

        The default path performs only optimization and the final residual
        evaluation. Identifiability, Laplace covariance, and parameter profiles
        are scientific audits and run only when ``audit=True`` or when the
        returned result is passed to :meth:`audit_fit`.
        """

        x0 = self.params.initial_vector(self.case_cfg)
        lb, ub = self.params.bounds()
        current = x0.copy()
        optimization_trace: list[Dict[str, Any]] = []

        def recorded_residual(x: np.ndarray, stage: str) -> np.ndarray:
            residual = self._objective_residual(x)
            if record_trace:
                optimization_trace.append(
                    {
                        "evaluation": len(optimization_trace),
                        "stage": stage,
                        "loss": 0.5 * float(np.dot(residual, residual)),
                        "x": np.asarray(x, dtype=float).tolist(),
                    }
                )
            return residual

        def global_objective(x: np.ndarray) -> float:
            residual = recorded_residual(x, "global")
            return 0.5 * float(np.dot(residual, residual))

        def local_objective(x: np.ndarray) -> np.ndarray:
            return recorded_residual(x, "local")

        fit_cfg = self.inv_cfg.get("fit", {})
        global_enabled = bool(fit_cfg.get("global", {}).get("enabled", False))
        local_enabled = bool(fit_cfg.get("local", {}).get("enabled", True))
        result_de = None
        if not global_enabled and not local_enabled:
            raise ValueError("Enable at least one global or local optimization stage.")

        if global_enabled:
            de_cfg = fit_cfg["global"]
            bounds = list(zip(lb, ub, strict=True))
            result_de = differential_evolution(
                global_objective,
                bounds=bounds,
                maxiter=int(de_cfg.get("maxiter", 20)),
                popsize=int(de_cfg.get("popsize", 8)),
                polish=False,
                seed=int(de_cfg.get("seed", 0)),
                tol=float(de_cfg.get("tol", 1.0e-3)),
                updating="deferred",
                workers=1,
            )
            current = result_de.x

        if local_enabled:
            lsq = least_squares(
                local_objective,
                current,
                bounds=(lb, ub),
                x_scale="jac",
                verbose=0,
                max_nfev=int(fit_cfg.get("local", {}).get("max_nfev", 200)),
            )
            x_opt = lsq.x
            success = bool(lsq.success)
            message = str(lsq.message)
        else:
            assert result_de is not None
            x_opt = current
            success = bool(result_de.success)
            message = str(result_de.message)

        case_opt = deepcopy(self.case_cfg)
        self.params.apply_to_case(case_opt, x_opt)
        r_opt, aux = residual_vector(
            self._residual_model,
            case_opt,
            self.inv_cfg,
            self.measurements,
            self.windows,
            collect_spectral_fits=True,
            _plan=self._objective_plan,
        )
        spectral_fits = aux.pop("spectral_fits", [])
        cost = 0.5 * float(np.dot(r_opt, r_opt))
        if record_trace:
            optimization_trace.append(
                {
                    "evaluation": len(optimization_trace),
                    "stage": "final",
                    "loss": cost,
                    "x": np.asarray(x_opt, dtype=float).tolist(),
                }
            )

        result = FitResult(
            x_opt=x_opt,
            case_opt=case_opt,
            cost=cost,
            success=success,
            message=message,
            aux=aux,
            parameters=self.params.physical_values(x_opt),
            spectral_fits=spectral_fits,
            assessment=self.assessment.as_dict(),
            calibration_uncertainty={
                str(instrument["id"]): CalibrationTransform.from_instrument_config(
                    instrument
                ).relative_standard_uncertainty
                for instrument in self._instrument_cfgs
            },
            optimization_trace=optimization_trace if record_trace else None,
        )
        return self.audit_fit(result) if audit else result

    def audit_fit(self, result: FitResult) -> FitResult:
        """Add configured post-fit scientific audits without changing the fit."""

        fit_cfg = self.inv_cfg.get("fit", {})
        forward_quality = self.model.predict(result.case_opt).quality_report.as_dict()
        uncertainty = None
        identifiability = None
        assessment = deepcopy(result.assessment or self.assessment.as_dict())
        calculate_laplace = bool(fit_cfg.get("uncertainty", {}).get("laplace", True))
        ident_cfg = fit_cfg.get("identifiability", {})
        calculate_identifiability = bool(ident_cfg.get("enabled", True))
        if calculate_identifiability:
            data_jacobian = finite_difference_jacobian(
                self._residual_model,
                result.case_opt,
                self.inv_cfg,
                self.measurements,
                self.windows,
                self.params,
                include_constraints=False,
                _plan=self._objective_plan,
            )
            identifiability = summarize_identifiability_jacobian(
                data_jacobian,
                rank_rtol=float(ident_cfg.get("rank_rtol", 1.0e-8)),
                parameter_names=self.params.names(),
                parameter_roles=self.params.roles(),
            )
            identifiability["basis"] = "measurement_data_only"
            identifiability["implicit_nuisance_handling"] = implicit_nuisance_handling(self.inv_cfg)
            identifiability["selected_windows"] = result.aux.get(
                "fit_windows",
                result.aux.get("selected_windows", {}),
            )
            identifiability["declared_windows"] = result.aux.get(
                "declared_windows",
                result.aux.get("selected_windows", {}),
            )
            projected_target = identifiability["projected_target"]
            full_rank = (
                projected_target["n_parameters"] > 0
                and projected_target["rank_estimate"] == projected_target["n_parameters"]
            )
            if assessment.get("mode") == "calibrated_absolute":
                assessment["absolute_scale_locally_identifiable"] = full_rank
            if not full_rank:
                warning = (
                    "The measurement Jacobian is rank deficient after explicit nuisance projection; "
                    "at least one target-parameter combination is not locally identifiable."
                )
                warnings = assessment.setdefault("warnings", [])
                if warning not in warnings:
                    warnings.append(warning)
        if calculate_laplace:
            objective_jacobian = finite_difference_jacobian(
                self._residual_model,
                result.case_opt,
                self.inv_cfg,
                self.measurements,
                self.windows,
                self.params,
                include_constraints=True,
                _plan=self._objective_plan,
            )
            cov = covariance_from_jacobian(objective_jacobian)
            uncertainty = summarize_covariance(cov, self.params.names())

        parameter_profiles = None
        profile_cfg = fit_cfg.get("profile", {})
        if bool(profile_cfg.get("enabled", False)):
            parameter_profiles = evaluate_parameter_profiles(
                self._measurement_residual,
                self.params,
                result.x_opt,
                profile_cfg,
            )

        return replace(
            result,
            uncertainty=uncertainty,
            identifiability=identifiability,
            forward_quality=forward_quality,
            assessment=assessment,
            parameter_profiles=parameter_profiles,
        )
