"""User-facing records for measured and fitted spectra."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class SpectralFit:
    """One observation aligned with its final model prediction."""

    instrument_id: str
    observation_id: str
    prediction_key: str
    output_basis: str
    output_unit: str
    wavelength_nm: np.ndarray
    measured: np.ndarray
    predicted: np.ndarray
    sigma: np.ndarray | None
    used_for_fit: np.ndarray

    @property
    def residual(self) -> np.ndarray:
        """Return the unweighted model-minus-measurement residual."""

        return self.predicted - self.measured
