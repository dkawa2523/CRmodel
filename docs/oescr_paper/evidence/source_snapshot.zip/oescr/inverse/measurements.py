"""Measurement loading, uncertainty validation, and residual whitening."""

from __future__ import annotations

import csv
from collections import defaultdict
from collections.abc import Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
from scipy.linalg import solve_triangular

from ..instrument.calibration import CalibrationTransform
from ..io.normalize import normalize_measurement_bindings
from ..io.yaml_loader import resolve_path

PIXEL_STATUSES = frozenset(
    {
        "valid",
        "invalid",
        "saturated",
        "missing",
        "spike",
        "outside_calibration",
        "user_excluded",
    }
)


@dataclass
class Measurement:
    wavelength_nm: np.ndarray
    intensity: np.ndarray
    sigma: np.ndarray | None = None
    covariance: np.ndarray | None = None
    covariance_cholesky: np.ndarray | None = None
    metadata: Dict[str, str] | None = None
    feature_covariance: "FeatureCovariance | None" = None
    calibration_relative_standard_uncertainty: float = 0.0
    calibration_group_id: str | None = None
    id: str = ""
    prediction_key: str = ""
    condition_id: str = "legacy"
    state_group_id: str = "legacy"
    view_id: str = ""
    replicate_id: str = ""
    stage: str = "legacy_scaled"
    output_basis: str = "unspecified"
    output_unit: str = "arb"
    calibration_artifact_id: str | None = None
    calibration_artifact_sha256: str | None = None
    pixel_status: np.ndarray | None = None
    ordinary_residual_mask: np.ndarray | None = None
    lower_bound: np.ndarray | None = None
    upper_bound: np.ndarray | None = None
    _covariance_cholesky_cache: Dict[bytes, np.ndarray] = field(
        default_factory=dict,
        init=False,
        repr=False,
        compare=False,
    )


@dataclass(frozen=True)
class FeatureCovariance:
    names: tuple[str, ...]
    covariance: np.ndarray
    cholesky: np.ndarray


def _factor_covariance(
    covariance: np.ndarray,
    size: int,
    label: str,
) -> tuple[np.ndarray, np.ndarray]:
    matrix = np.atleast_2d(np.asarray(covariance, dtype=float))
    if matrix.shape != (size, size):
        raise ValueError(f"{label} has shape {matrix.shape}; expected {(size, size)}.")
    if np.any(~np.isfinite(matrix)):
        raise ValueError(f"{label} must contain only finite values.")
    scale = max(float(np.max(np.abs(np.diag(matrix)))), 1.0)
    if not np.allclose(matrix, matrix.T, rtol=1.0e-10, atol=1.0e-12 * scale):
        raise ValueError(f"{label} must be symmetric.")
    try:
        cholesky = np.linalg.cholesky(matrix)
    except np.linalg.LinAlgError as exc:
        raise ValueError(f"{label} must be positive definite.") from exc
    return matrix, cholesky


def _load_covariance_csv(path: str | Path, size: int) -> tuple[np.ndarray, np.ndarray]:
    covariance = np.loadtxt(path, delimiter=",", dtype=float)
    return _factor_covariance(covariance, size, f"Measurement covariance '{path}'")


def _feature_covariance_from_config(item: Dict[str, Any]) -> FeatureCovariance | None:
    config = item.get("feature_covariance")
    if config is None:
        return None
    names = tuple(str(name) for name in config["names"])
    if len(set(names)) != len(names):
        raise ValueError("Feature covariance names must be unique.")
    covariance, cholesky = _factor_covariance(
        np.asarray(config["matrix"], dtype=float),
        len(names),
        "Feature covariance",
    )
    return FeatureCovariance(names=names, covariance=covariance, cholesky=cholesky)


def _read_measurement_metadata(path: str | Path) -> Dict[str, str]:
    metadata: Dict[str, str] = {}
    with open(path, "r", encoding="utf-8") as stream:
        for line in stream:
            stripped = line.strip()
            if not stripped.startswith("#"):
                continue
            key, separator, value = stripped[1:].partition(":")
            if separator:
                metadata[key.strip()] = value.strip()
    return metadata


def _optional_float(value: str | None, *, column: str, row_number: int, path: str | Path) -> float:
    if value is None or not value.strip():
        return float("nan")
    try:
        return float(value)
    except ValueError as exc:
        raise ValueError(f"Measurement '{path}' row {row_number} has invalid {column}={value!r}.") from exc


def _read_measurement_columns(
    path: str | Path,
) -> tuple[
    np.ndarray,
    np.ndarray,
    np.ndarray | None,
    np.ndarray,
    np.ndarray | None,
    np.ndarray | None,
]:
    wavelength: List[float] = []
    intensity: List[float] = []
    sigma: List[float] = []
    pixel_status: List[str] = []
    lower_bound: List[float] = []
    upper_bound: List[float] = []
    with open(path, "r", encoding="utf-8") as stream:
        reader = csv.DictReader(row for row in stream if not row.lstrip().startswith("#"))
        required_columns = {"wavelength_nm", "intensity"}
        if reader.fieldnames is None:
            raise ValueError(f"Measurement '{path}' is empty or has no CSV header.")
        missing_columns = required_columns.difference(reader.fieldnames)
        if missing_columns:
            raise ValueError(f"Measurement '{path}' is missing required columns: {', '.join(sorted(missing_columns))}.")
        has_sigma = "sigma" in reader.fieldnames
        has_status = "pixel_status" in reader.fieldnames
        has_lower_bound = "lower_bound" in reader.fieldnames
        has_upper_bound = "upper_bound" in reader.fieldnames
        for row_number, row in enumerate(reader, start=2):
            wavelength.append(
                _optional_float(row["wavelength_nm"], column="wavelength_nm", row_number=row_number, path=path)
            )
            intensity.append(_optional_float(row["intensity"], column="intensity", row_number=row_number, path=path))
            if has_sigma:
                sigma.append(_optional_float(row.get("sigma"), column="sigma", row_number=row_number, path=path))
            if has_status:
                status = str(row.get("pixel_status") or "").strip().lower()
                if not status:
                    raise ValueError(f"Measurement '{path}' row {row_number} has an empty pixel_status.")
                pixel_status.append(status)
            else:
                pixel_status.append("valid")
            if has_lower_bound:
                lower_bound.append(
                    _optional_float(row.get("lower_bound"), column="lower_bound", row_number=row_number, path=path)
                )
            if has_upper_bound:
                upper_bound.append(
                    _optional_float(row.get("upper_bound"), column="upper_bound", row_number=row_number, path=path)
                )
    return (
        np.asarray(wavelength, dtype=float),
        np.asarray(intensity, dtype=float),
        np.asarray(sigma, dtype=float) if sigma else None,
        np.asarray(pixel_status, dtype=str),
        np.asarray(lower_bound, dtype=float) if lower_bound else None,
        np.asarray(upper_bound, dtype=float) if upper_bound else None,
    )


def _validate_optional_bounds(
    path: str | Path,
    lower_bound: np.ndarray | None,
    upper_bound: np.ndarray | None,
    size: int,
) -> None:
    for name, values in (("lower_bound", lower_bound), ("upper_bound", upper_bound)):
        if values is None:
            continue
        if len(values) != size or np.any(np.isinf(values)):
            raise ValueError(f"Measurement '{path}' {name} must be finite where provided and complete by row.")
    if lower_bound is not None and upper_bound is not None:
        both = np.isfinite(lower_bound) & np.isfinite(upper_bound)
        if np.any(lower_bound[both] > upper_bound[both]):
            raise ValueError(f"Measurement '{path}' has lower_bound greater than upper_bound.")


def _validate_measurement_samples(
    path: str | Path,
    wavelength: np.ndarray,
    intensity: np.ndarray,
    pixel_status: np.ndarray,
    lower_bound: np.ndarray | None,
    upper_bound: np.ndarray | None,
) -> np.ndarray:
    if len(wavelength) == 0:
        raise ValueError(f"Measurement '{path}' contains no data rows.")
    if len(wavelength) != len(intensity):
        raise ValueError(f"Measurement '{path}' wavelength and intensity columns differ in length.")
    if len(pixel_status) != len(wavelength):
        raise ValueError(f"Measurement '{path}' pixel_status must be complete by row.")
    unknown = sorted(set(pixel_status).difference(PIXEL_STATUSES))
    if unknown:
        raise ValueError(f"Measurement '{path}' has unknown pixel_status values: {', '.join(unknown)}.")
    if np.any(~np.isfinite(wavelength)):
        raise ValueError(f"Measurement '{path}' wavelength values must be finite.")
    ordinary_mask = pixel_status == "valid"
    if not np.any(ordinary_mask):
        raise ValueError(f"Measurement '{path}' contains no valid pixels for ordinary residuals.")
    if np.any(~np.isfinite(intensity[ordinary_mask])):
        raise ValueError(f"Measurement '{path}' valid intensity values must be finite.")
    if np.any(np.isinf(intensity)):
        raise ValueError(f"Measurement '{path}' intensity values must be finite when present.")
    nonfinite_intensity = ~np.isfinite(intensity)
    missing_like = np.isin(pixel_status, ["missing", "invalid"])
    if np.any(nonfinite_intensity & ~missing_like):
        raise ValueError(f"Measurement '{path}' non-finite intensity is allowed only for missing or invalid pixels.")
    spacing = np.diff(wavelength)
    if np.any(spacing == 0.0):
        raise ValueError(f"Measurement '{path}' contains duplicate wavelength values.")
    if np.any(spacing < 0.0):
        raise ValueError(f"Measurement '{path}' wavelength_nm must be strictly increasing.")
    _validate_optional_bounds(path, lower_bound, upper_bound, len(wavelength))
    saturated = pixel_status == "saturated"
    if np.any(saturated) and (lower_bound is None or np.any(~np.isfinite(lower_bound[saturated]))):
        raise ValueError(f"Measurement '{path}' saturated pixels require a finite lower_bound.")
    return ordinary_mask


def _validate_pointwise_sigma(
    path: str | Path,
    sigma: np.ndarray | None,
    size: int,
    ordinary_mask: np.ndarray,
) -> None:
    if sigma is None:
        return
    if len(sigma) != size:
        raise ValueError(f"Measurement '{path}' sigma must have one entry per pixel.")
    supplied = np.isfinite(sigma)
    if np.any(supplied & (sigma <= 0.0)) or np.any(np.isinf(sigma)):
        raise ValueError(f"Measurement '{path}' sigma values must be positive where provided.")
    if np.any(~supplied[ordinary_mask]):
        raise ValueError(f"Measurement '{path}' valid pixels require finite positive sigma values.")


def load_measurement_csv(
    path: str | Path,
    covariance_path: str | Path | None = None,
    *,
    measurement_id: str = "",
    prediction_key: str = "",
    calibration_group_id: str | None = None,
    condition_id: str = "legacy",
    state_group_id: str = "legacy",
    view_id: str = "",
    replicate_id: str = "",
    stage: str = "legacy_scaled",
    output_basis: str | None = None,
    output_unit: str | None = None,
    calibration_artifact_id: str | None = None,
    calibration_artifact_sha256: str | None = None,
) -> Measurement:
    wavelength, intensity, sigma_array, pixel_status, lower_bound, upper_bound = _read_measurement_columns(path)
    ordinary_mask = _validate_measurement_samples(
        path,
        wavelength,
        intensity,
        pixel_status,
        lower_bound,
        upper_bound,
    )
    metadata = _read_measurement_metadata(path)
    for metadata_field, declared in (("output_basis", output_basis), ("output_unit", output_unit)):
        csv_value = metadata.get(metadata_field)
        if declared is not None and csv_value is not None and str(declared) != csv_value:
            raise ValueError(f"Measurement '{path}' declares conflicting {metadata_field} in YAML and CSV metadata.")
    _validate_pointwise_sigma(path, sigma_array, len(wavelength), ordinary_mask)
    if sigma_array is not None and covariance_path is not None:
        raise ValueError(f"Measurement '{path}' cannot declare both pointwise sigma and covariance.")
    covariance = None
    cholesky = None
    if covariance_path is not None:
        covariance, cholesky = _load_covariance_csv(covariance_path, len(wavelength))
        if not np.all(ordinary_mask):
            _, cholesky = _factor_covariance(
                covariance[np.ix_(ordinary_mask, ordinary_mask)],
                int(np.sum(ordinary_mask)),
                f"Valid-pixel covariance subset for measurement '{path}'",
            )
    return Measurement(
        wavelength,
        intensity,
        sigma_array,
        covariance,
        cholesky,
        metadata,
        calibration_group_id=calibration_group_id,
        id=measurement_id,
        prediction_key=prediction_key,
        condition_id=condition_id,
        state_group_id=state_group_id,
        view_id=view_id or prediction_key,
        replicate_id=replicate_id or measurement_id,
        stage=stage,
        output_basis=output_basis or metadata.get("output_basis", "unspecified"),
        output_unit=output_unit or metadata.get("output_unit", "arb"),
        calibration_artifact_id=calibration_artifact_id,
        calibration_artifact_sha256=calibration_artifact_sha256,
        pixel_status=pixel_status,
        ordinary_residual_mask=ordinary_mask,
        lower_bound=lower_bound,
        upper_bound=upper_bound,
    )


def _validate_absolute_measurement_metadata(
    instrument_id: str,
    measurement: Measurement,
    instrument_cfg: Dict[str, Any],
) -> None:
    calibration = CalibrationTransform.from_instrument_config(instrument_cfg)
    expected = {
        "output_basis": calibration.output_basis,
        "output_unit": calibration.output_unit,
        "calibration_reference": str(calibration.reference),
    }
    metadata = measurement.metadata or {}
    actual = {
        "output_basis": measurement.output_basis,
        "output_unit": measurement.output_unit,
        "calibration_reference": metadata.get("calibration_reference"),
    }
    mismatches = [key for key, value in expected.items() if actual.get(key) != value]
    if mismatches:
        raise ValueError(
            f"Absolute measurement {instrument_id}/{measurement.id} metadata does not match the instrument "
            f"calibration for: {', '.join(mismatches)}."
        )
    relative_uncertainty = calibration.relative_standard_uncertainty
    measurement.calibration_relative_standard_uncertainty = relative_uncertainty
    if relative_uncertainty <= 0.0:
        return
    if measurement.covariance is None and measurement.sigma is None:
        raise ValueError(
            f"Absolute measurement {instrument_id}/{measurement.id} has calibration uncertainty but no "
            "pointwise sigma or measurement covariance."
        )
    if measurement.calibration_group_id is None:
        measurement.calibration_group_id = f"{instrument_id}:{calibration.reference}"


def load_measurements(
    inv_cfg: Dict[str, Any],
    instrument_cfgs: List[Dict[str, Any]] | None = None,
) -> Dict[str, List[Measurement]]:
    """Normalize legacy bindings, then load their measurement arrays.

    New solver code owns normalization before loading and uses
    :func:`load_canonical_measurements`; this wrapper remains the explicit
    compatibility boundary for direct callers with legacy plural bindings.
    """

    return load_canonical_measurements(
        {**inv_cfg, "measurements": normalize_measurement_bindings(inv_cfg)},
        instrument_cfgs,
    )


def load_canonical_measurements(
    inv_cfg: Dict[str, Any],
    instrument_cfgs: List[Dict[str, Any]] | None = None,
) -> Dict[str, List[Measurement]]:
    """Load already-normalized one-file measurement bindings."""

    bindings = inv_cfg.get("measurements", [])
    if not isinstance(bindings, list):
        raise ValueError("Normalized inverse measurements must be a list.")
    out: Dict[str, List[Measurement]] = {}
    instrument_map = {str(item["id"]): item for item in (instrument_cfgs or [])}
    absolute = inv_cfg.get("inference_mode") == "calibrated_absolute"
    for item in bindings:
        instrument_id = str(item["instrument_id"])
        calibration_group_id = item.get("calibration_group_id")
        if calibration_group_id is not None:
            calibration_group_id = str(calibration_group_id).strip()
            if not calibration_group_id:
                raise ValueError("calibration_group_id must be a non-empty string when provided.")
        calibration_artifact = item.get("calibration_artifact") or {}
        measurement = load_measurement_csv(
            resolve_path(inv_cfg, item["file"]),
            resolve_path(inv_cfg, item["covariance_file"]) if "covariance_file" in item else None,
            measurement_id=str(item["id"]),
            prediction_key=str(item["prediction_key"]),
            calibration_group_id=calibration_group_id,
            condition_id=str(item.get("condition_id", "legacy")),
            state_group_id=str(item.get("state_group_id", "legacy")),
            view_id=str(item.get("view_id", item["prediction_key"])),
            replicate_id=str(item.get("replicate_id", item["id"])),
            stage=str(item.get("stage", "legacy_scaled")),
            output_basis=item.get("output_basis"),
            output_unit=item.get("output_unit"),
            calibration_artifact_id=calibration_artifact.get("id"),
            calibration_artifact_sha256=calibration_artifact.get("sha256"),
        )
        measurement.feature_covariance = _feature_covariance_from_config(item)
        if absolute:
            if instrument_id not in instrument_map:
                raise ValueError(
                    f"No compiled instrument configuration found for absolute measurement '{instrument_id}'."
                )
            _validate_absolute_measurement_metadata(instrument_id, measurement, instrument_map[instrument_id])
        out.setdefault(instrument_id, []).append(measurement)
    return out


def combined_residual_mask(
    measurement: Measurement,
    analysis_mask: np.ndarray | None = None,
) -> np.ndarray:
    """Return the full-grid QC mask optionally intersected with an analysis mask."""

    size = len(measurement.intensity)
    status_mask: np.ndarray | None = None
    if measurement.pixel_status is not None:
        statuses = np.asarray(measurement.pixel_status, dtype=str)
        if statuses.shape != (size,):
            raise ValueError(
                f"Measurement '{measurement.id}' pixel_status has shape {statuses.shape}; expected {(size,)}."
            )
        unknown = sorted(set(statuses).difference(PIXEL_STATUSES))
        if unknown:
            raise ValueError(f"Measurement '{measurement.id}' has unknown pixel_status values: {', '.join(unknown)}.")
        status_mask = statuses == "valid"
    if measurement.ordinary_residual_mask is not None:
        ordinary_mask = np.asarray(measurement.ordinary_residual_mask, dtype=bool)
        if status_mask is not None and not np.array_equal(ordinary_mask, status_mask):
            raise ValueError(f"Measurement '{measurement.id}' ordinary_residual_mask conflicts with pixel_status.")
    elif status_mask is not None:
        ordinary_mask = status_mask
    else:
        ordinary_mask = np.ones(size, dtype=bool)
    if ordinary_mask.shape != (size,):
        raise ValueError(
            f"Measurement '{measurement.id}' ordinary_residual_mask has shape "
            f"{ordinary_mask.shape}; expected {(size,)}."
        )
    if analysis_mask is None:
        return ordinary_mask
    requested = np.asarray(analysis_mask, dtype=bool)
    if requested.shape != (size,):
        raise ValueError(
            f"Measurement '{measurement.id}' analysis mask has shape {requested.shape}; expected {(size,)}."
        )
    return ordinary_mask & requested


def _covariance_cholesky_for_mask(
    measurement: Measurement,
    mask: np.ndarray,
) -> np.ndarray:
    cache_key = np.ascontiguousarray(mask, dtype=bool).tobytes()
    cached = measurement._covariance_cholesky_cache.get(cache_key)
    if cached is not None:
        return cached
    selected_size = int(np.sum(mask))
    ordinary_mask = combined_residual_mask(measurement)
    existing = measurement.covariance_cholesky
    if (
        existing is not None
        and existing.shape == (selected_size, selected_size)
        and np.array_equal(mask, ordinary_mask)
    ):
        measurement._covariance_cholesky_cache[cache_key] = existing
        return existing

    covariance = measurement.covariance
    if covariance is None:
        if existing is None or existing.shape != (len(mask), len(mask)):
            raise ValueError(f"Measurement '{measurement.id}' has no covariance matrix for the requested mask.")
        covariance = existing @ existing.T
    _, cholesky = _factor_covariance(
        covariance[np.ix_(mask, mask)],
        selected_size,
        f"Masked covariance for measurement '{measurement.id}'",
    )
    measurement._covariance_cholesky_cache[cache_key] = cholesky
    return cholesky


def _whiten_independent_noise(
    measurement: Measurement,
    values: np.ndarray,
    mask: np.ndarray,
) -> np.ndarray:
    """Whiten selected samples by only the observation's independent noise model."""

    values_array = np.asarray(values, dtype=float)
    if values_array.shape != measurement.intensity.shape:
        raise ValueError(
            f"Values for measurement '{measurement.id}' have shape {values_array.shape}; "
            f"expected {measurement.intensity.shape}."
        )
    selected = values_array[mask]
    if len(selected) == 0:
        return np.zeros(0, dtype=float)
    if measurement.covariance_cholesky is not None or measurement.covariance is not None:
        return np.asarray(solve_triangular(_covariance_cholesky_for_mask(measurement, mask), selected, lower=True))
    if measurement.sigma is not None:
        return selected / measurement.sigma[mask]
    scale = max(float(np.std(measurement.intensity[mask])), 1.0e-12)
    return selected / scale


def spectrum_residual_blocks(
    observations: Sequence[tuple[Measurement, np.ndarray]],
    analysis_masks: Sequence[np.ndarray | None] | None = None,
) -> List[np.ndarray]:
    """Whiten spectra while sharing one calibration scale per group.

    Independent pointwise or within-spectrum covariance remains block diagonal.
    A calibration group adds one rank-one covariance component across every
    observation in that group.  The symmetric rank-one inverse square root
    below has linear overhead and keeps both the number and ordering of residual
    samples unchanged.
    """

    residual_blocks: List[np.ndarray] = []
    calibration_blocks: List[np.ndarray | None] = []
    group_members: Dict[object, List[int]] = defaultdict(list)
    if analysis_masks is not None and len(analysis_masks) != len(observations):
        raise ValueError("analysis_masks must have the same length and order as observations.")

    for index, (measurement, predicted) in enumerate(observations):
        predicted_array = np.asarray(predicted, dtype=float)
        if predicted_array.shape != measurement.intensity.shape:
            raise ValueError(
                f"Prediction for measurement '{measurement.id}' has shape {predicted_array.shape}; "
                f"expected {measurement.intensity.shape}."
            )
        analysis_mask = None if analysis_masks is None else analysis_masks[index]
        mask = combined_residual_mask(measurement, analysis_mask)
        residual_blocks.append(
            _whiten_independent_noise(
                measurement,
                predicted_array - measurement.intensity,
                mask,
            )
        )

        relative_uncertainty = float(measurement.calibration_relative_standard_uncertainty)
        if relative_uncertainty <= 0.0:
            calibration_blocks.append(None)
            continue
        if measurement.covariance is None and measurement.covariance_cholesky is None and measurement.sigma is None:
            raise ValueError(
                f"Measurement '{measurement.id}' has calibration uncertainty but no pointwise sigma "
                "or measurement covariance."
            )
        calibration_blocks.append(
            _whiten_independent_noise(
                measurement,
                relative_uncertainty * measurement.intensity,
                mask,
            )
        )
        group_id: object = measurement.calibration_group_id or ("ungrouped", index)
        group_members[group_id].append(index)

    for member_indices in group_members.values():
        calibration_norm_sq = 0.0
        residual_projection = 0.0
        for index in member_indices:
            calibration = calibration_blocks[index]
            if calibration is None:
                continue
            calibration_norm_sq += float(np.dot(calibration, calibration))
            residual_projection += float(np.dot(calibration, residual_blocks[index]))
        root = float(np.sqrt(1.0 + calibration_norm_sq))
        coefficient = residual_projection / (root * (root + 1.0))
        for index in member_indices:
            calibration = calibration_blocks[index]
            if calibration is not None:
                residual_blocks[index] = residual_blocks[index] - coefficient * calibration

    return residual_blocks


def whiten_feature_residuals(
    measurement: Measurement,
    residuals_by_name: Dict[str, float],
) -> np.ndarray:
    feature_covariance = measurement.feature_covariance
    if feature_covariance is None:
        return np.zeros(0, dtype=float)
    missing = [name for name in feature_covariance.names if name not in residuals_by_name]
    if missing:
        raise ValueError(
            "Feature covariance references residuals that were not produced; "
            f"check enabled/low-signal windows and named ratio pairs: {', '.join(missing)}."
        )
    residual = np.asarray([residuals_by_name[name] for name in feature_covariance.names], dtype=float)
    return np.asarray(solve_triangular(feature_covariance.cholesky, residual, lower=True))
