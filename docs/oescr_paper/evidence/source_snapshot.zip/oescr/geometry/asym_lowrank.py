
from __future__ import annotations

import numpy as np


def apply_lowrank_asymmetry(
    chord_spectra: np.ndarray,
    chord_angles_rad: np.ndarray | None,
    mode1_amplitude: np.ndarray | None = None,
) -> np.ndarray:
    """Apply one wavelength-independent m=1 factor per projected chord."""

    spectra = np.asarray(chord_spectra, dtype=float)
    if mode1_amplitude is None:
        return spectra.copy()
    if chord_angles_rad is None:
        raise ValueError("mode1_amplitude requires chord_angles_rad for each chord.")
    if spectra.ndim != 2:
        raise ValueError("Asymmetry correction requires a chord-by-wavelength array.")
    angles = np.asarray(chord_angles_rad, dtype=float)
    amplitudes = np.asarray(mode1_amplitude, dtype=float)
    expected = (spectra.shape[0],)
    if angles.shape != expected or amplitudes.shape != expected:
        raise ValueError("chord_angles_rad and mode1_amplitude must each contain one value per chord.")
    factors = 1.0 + amplitudes * np.cos(angles)
    if not np.all(np.isfinite(factors)) or np.any(factors < 0.0):
        raise ValueError("The asymmetry factors 1 + amplitude*cos(angle) must be finite and non-negative.")
    return spectra * factors[:, None]
