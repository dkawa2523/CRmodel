
from __future__ import annotations

import csv
from pathlib import Path
from typing import Dict

import numpy as np


def load_profile_csv(path: str | Path) -> Dict[str, np.ndarray]:
    wl = []
    val = []
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(row for row in f if not row.lstrip().startswith("#"))
        for row in reader:
            wl.append(float(row["wavelength_nm"]))
            val.append(float(row["relative_intensity"]))
    wl_arr = np.asarray(wl, dtype=float)
    val_arr = np.asarray(val, dtype=float)
    if wl_arr.size < 2 or not np.all(np.isfinite(wl_arr)) or not np.all(np.isfinite(val_arr)):
        raise ValueError(f"Band profile '{path}' requires at least two finite wavelength/intensity rows.")
    if np.any(np.diff(wl_arr) <= 0.0):
        raise ValueError(f"Band profile '{path}' wavelength_nm must be strictly increasing.")
    if np.any(val_arr < 0.0):
        raise ValueError(f"Band profile '{path}' relative_intensity must be non-negative.")
    area = float(np.trapezoid(val_arr, wl_arr))
    if not np.isfinite(area) or area <= 0.0:
        raise ValueError(f"Band profile '{path}' must have a positive finite integrated intensity.")
    return {"wavelength_nm": wl_arr, "relative_intensity": val_arr / area}
