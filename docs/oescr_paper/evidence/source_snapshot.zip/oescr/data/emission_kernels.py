"""Compile auditable emission-kernel declarations into a serializable inventory."""

from __future__ import annotations

import re
from collections import Counter
from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping, Sequence

from .provenance import file_sha256

EVIDENCE_STATUSES = (
    "illustrative",
    "literature_anchored",
    "validation_candidate",
    "qualified",
)
PATHWAYS = (
    "direct_ground",
    "metastable_stepwise",
    "cascade_effective",
    "dissociative",
)

_ARTIFACT_REQUIRED_STATUSES = {"validation_candidate", "qualified"}
_SHA256_RE = re.compile(r"^[0-9a-fA-F]{64}$")


class EmissionKernelError(ValueError):
    """Raised when an emission-kernel declaration is internally inconsistent."""


def _required_text(value: Any, field: str, kernel_id: str) -> str:
    text = str(value).strip()
    if not text:
        raise EmissionKernelError(f"Emission kernel '{kernel_id}' requires a non-empty {field}.")
    return text


def _reference_ids(value: Any, field: str, kernel_id: str) -> list[str]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)) or not value:
        raise EmissionKernelError(f"Emission kernel '{kernel_id}' requires a non-empty {field} array.")
    identifiers = [_required_text(item, field, kernel_id) for item in value]
    if len(set(identifiers)) != len(identifiers):
        raise EmissionKernelError(f"Emission kernel '{kernel_id}' has duplicate entries in {field}.")
    return identifiers


def _index_by_id(items: Sequence[Mapping[str, Any]], section: str) -> dict[str, Mapping[str, Any]]:
    indexed: dict[str, Mapping[str, Any]] = {}
    for item in items:
        if "id" not in item:
            continue
        item_id = str(item["id"])
        if item_id in indexed:
            raise EmissionKernelError(f"Duplicate {section} id: {item_id}")
        indexed[item_id] = item
    return indexed


def _artifact_path(case_cfg: Mapping[str, Any], reaction: Mapping[str, Any], process_id: str) -> Path:
    path_value = reaction.get("cross_section_file")
    if path_value is None:
        rate_model = reaction.get("rate_model")
        if isinstance(rate_model, Mapping):
            path_value = rate_model.get("cross_section_file")
    if path_value is None:
        raise EmissionKernelError(
            f"Emission-kernel process artifact '{process_id}' has no cross_section_file to verify."
        )

    path = Path(str(path_value))
    if not path.is_absolute():
        path = Path(str(case_cfg.get("__base_dir__", "."))) / path
    path = path.resolve()
    if not path.is_file():
        raise EmissionKernelError(f"Emission-kernel process artifact '{process_id}' file does not exist: {path}")
    return path


def _compile_artifacts(
    case_cfg: Mapping[str, Any],
    kernel_id: str,
    process_ids: list[str],
    reactions: Mapping[str, Mapping[str, Any]],
    evidence: Mapping[str, Any],
) -> list[dict[str, str]]:
    artifacts = evidence.get("process_artifacts", [])
    if not isinstance(artifacts, list):
        raise EmissionKernelError(f"Emission kernel '{kernel_id}' evidence.process_artifacts must be an array.")

    normalized: list[dict[str, str]] = []
    seen: set[str] = set()
    for artifact in artifacts:
        if not isinstance(artifact, Mapping):
            raise EmissionKernelError(f"Emission kernel '{kernel_id}' process artifacts must be mappings.")
        process_id = _required_text(artifact.get("process_id", ""), "artifact process_id", kernel_id)
        if process_id not in process_ids:
            raise EmissionKernelError(
                f"Emission kernel '{kernel_id}' artifact process_id '{process_id}' is not listed in process_ids."
            )
        if process_id in seen:
            raise EmissionKernelError(f"Emission kernel '{kernel_id}' has duplicate process artifact '{process_id}'.")
        seen.add(process_id)

        expected = str(artifact.get("sha256", "")).strip().lower()
        if _SHA256_RE.fullmatch(expected) is None:
            raise EmissionKernelError(
                f"Emission kernel '{kernel_id}' process artifact '{process_id}' requires a 64-digit hexadecimal sha256."
            )
        actual = file_sha256(_artifact_path(case_cfg, reactions[process_id], process_id))
        if actual != expected:
            raise EmissionKernelError(
                f"Emission kernel '{kernel_id}' process artifact '{process_id}' SHA-256 mismatch: "
                f"expected {expected}, got {actual}."
            )
        normalized.append({"process_id": process_id, "sha256": expected})
    return normalized


def _validate_process_references(
    kernel_id: str,
    upper_state: str,
    process_ids: list[str],
    reactions: Mapping[str, Mapping[str, Any]],
) -> None:
    for process_id in process_ids:
        reaction = reactions.get(process_id)
        if reaction is None:
            raise EmissionKernelError(f"Emission kernel '{kernel_id}' references unknown reaction '{process_id}'.")
        if str(reaction.get("target_state", "")) != upper_state:
            raise EmissionKernelError(
                f"Emission kernel '{kernel_id}' reaction '{process_id}' must target upper_state "
                f"'{upper_state}', got '{reaction.get('target_state')}'."
            )


def _validate_transition_references(
    kernel_id: str,
    upper_state: str,
    transition_ids: list[str],
    transitions: Mapping[str, Mapping[str, Any]],
) -> None:
    for transition_id in transition_ids:
        transition = transitions.get(transition_id)
        if transition is None:
            raise EmissionKernelError(f"Emission kernel '{kernel_id}' references unknown transition '{transition_id}'.")
        if str(transition.get("upper", "")) != upper_state:
            raise EmissionKernelError(
                f"Emission kernel '{kernel_id}' transition '{transition_id}' must use upper_state "
                f"'{upper_state}', got '{transition.get('upper')}'."
            )


def _compile_evidence(
    case_cfg: Mapping[str, Any],
    kernel_id: str,
    process_ids: list[str],
    reactions: Mapping[str, Mapping[str, Any]],
    raw_evidence: Any,
) -> dict[str, Any]:
    if not isinstance(raw_evidence, Mapping):
        raise EmissionKernelError(f"Emission kernel '{kernel_id}' requires evidence metadata.")
    status = _required_text(raw_evidence.get("status", ""), "evidence status", kernel_id)
    if status not in EVIDENCE_STATUSES:
        raise EmissionKernelError(
            f"Emission kernel '{kernel_id}' evidence status must be one of {list(EVIDENCE_STATUSES)}; got '{status}'."
        )
    reference = _required_text(raw_evidence.get("reference", ""), "evidence reference", kernel_id)
    limitations = raw_evidence.get("limitations")
    if not isinstance(limitations, list):
        raise EmissionKernelError(f"Emission kernel '{kernel_id}' evidence.limitations must be an array.")
    normalized_artifacts = _compile_artifacts(
        case_cfg,
        kernel_id,
        process_ids,
        reactions,
        raw_evidence,
    )
    artifact_processes = {item["process_id"] for item in normalized_artifacts}
    if status in _ARTIFACT_REQUIRED_STATUSES:
        missing = [process_id for process_id in process_ids if process_id not in artifact_processes]
        if missing:
            raise EmissionKernelError(
                f"Emission kernel '{kernel_id}' with evidence status '{status}' requires verified "
                f"artifacts for every process; missing: {', '.join(missing)}."
            )

    normalized: dict[str, Any] = {
        "status": status,
        "reference": reference,
        "limitations": deepcopy(limitations),
    }
    if "process_artifacts" in raw_evidence:
        normalized["process_artifacts"] = normalized_artifacts
    return normalized


def _compile_kernel_record(
    case_cfg: Mapping[str, Any],
    index: int,
    raw_record: Any,
    existing_kernel_ids: set[str],
    state_ids: set[str],
    reactions: Mapping[str, Mapping[str, Any]],
    transitions: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    if not isinstance(raw_record, Mapping):
        raise EmissionKernelError(f"emission_kernels[{index}] must be a mapping.")
    kernel_id = _required_text(raw_record.get("id", ""), "id", f"<index {index}>")
    if kernel_id in existing_kernel_ids:
        raise EmissionKernelError(f"Duplicate emission kernel id: {kernel_id}")
    upper_state = _required_text(raw_record.get("upper_state", ""), "upper_state", kernel_id)
    if upper_state not in state_ids:
        raise EmissionKernelError(f"Emission kernel '{kernel_id}' upper_state '{upper_state}' is not a known state.")
    process_ids = _reference_ids(raw_record.get("process_ids"), "process_ids", kernel_id)
    transition_ids = _reference_ids(raw_record.get("transition_ids"), "transition_ids", kernel_id)
    _validate_process_references(kernel_id, upper_state, process_ids, reactions)
    _validate_transition_references(kernel_id, upper_state, transition_ids, transitions)

    pathway = _required_text(raw_record.get("pathway", ""), "pathway", kernel_id)
    if pathway not in PATHWAYS:
        raise EmissionKernelError(
            f"Emission kernel '{kernel_id}' pathway must be one of {list(PATHWAYS)}; got '{pathway}'."
        )
    return {
        "id": kernel_id,
        "upper_state": upper_state,
        "process_ids": process_ids,
        "transition_ids": transition_ids,
        "pathway": pathway,
        "evidence": _compile_evidence(
            case_cfg,
            kernel_id,
            process_ids,
            reactions,
            raw_record.get("evidence"),
        ),
    }


def compile_emission_kernel_inventory(case_cfg: Mapping[str, Any]) -> dict[str, Any]:
    """Validate emission-kernel references and return a JSON-serializable summary."""

    reactions = _index_by_id(list(case_cfg.get("reactions", [])), "reaction")
    transitions = _index_by_id(list(case_cfg.get("transitions", [])), "transition")
    state_ids = {str(item["id"]) for item in case_cfg.get("states", []) if "id" in item}

    records: list[dict[str, Any]] = []
    kernel_ids: set[str] = set()
    upper_states: set[str] = set()
    referenced_processes: set[str] = set()
    referenced_transitions: set[str] = set()
    evidence_counts: Counter[str] = Counter()

    for index, raw_record in enumerate(case_cfg.get("emission_kernels", [])):
        record = _compile_kernel_record(
            case_cfg,
            index,
            raw_record,
            kernel_ids,
            state_ids,
            reactions,
            transitions,
        )
        kernel_id = record["id"]
        kernel_ids.add(kernel_id)
        records.append(record)
        upper_states.add(record["upper_state"])
        referenced_processes.update(record["process_ids"])
        referenced_transitions.update(record["transition_ids"])
        evidence_counts[record["evidence"]["status"]] += 1

    return {
        "kernel_count": len(records),
        "upper_state_count": len(upper_states),
        "process_count": len(referenced_processes),
        "transition_count": len(referenced_transitions),
        "evidence_counts": dict(sorted(evidence_counts.items())),
        "records": records,
    }
