"""Serialization of forward spectra, diagnostics, and provenance."""

from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict

from ..io.spectrum_csv import write_spectrum_csv
from ..io.yaml_loader import save_yaml
from .model import ForwardResult


def forward_diagnostics_payload(result: ForwardResult) -> Dict[str, Any]:
    zones = []
    for zone_index, diagnostics in enumerate(result.zone_diagnostics):
        zones.append(
            {
                "zone_index": zone_index,
                "eedf": asdict(diagnostics.eedf),
                "cr": asdict(diagnostics.cr),
                "reactions": diagnostics.reactions,
                "processes": diagnostics.processes,
                "state_balances": {
                    state_id: balance.as_dict()
                    for state_id, balance in diagnostics.state_balances.items()
                },
                "bands": diagnostics.bands,
            }
        )
    return {
        "quality": result.quality_report.as_dict(),
        "emission_basis": result.emission_basis,
        "emission_component_bases": result.emission_component_bases,
        "provenance": result.provenance,
        "zones": zones,
    }


def write_forward_diagnostics(result: ForwardResult, path: str | Path) -> None:
    save_yaml(forward_diagnostics_payload(result), path)


def write_forward_spectra(
    spectra: Dict[str, Dict[str, Dict[str, Any]]],
    directory: str | Path,
    *,
    diagnostics: ForwardResult | None = None,
) -> None:
    """Write the same forward output for direct and project-based runs."""

    destination = Path(directory)
    destination.mkdir(parents=True, exist_ok=True)
    for instrument_id, chord_map in spectra.items():
        for chord_key, spectrum in chord_map.items():
            write_spectrum_csv(
                destination / f"{instrument_id}_{chord_key}.csv",
                spectrum["wavelength_nm"],
                spectrum["intensity"],
                metadata={
                    name: spectrum[name]
                    for name in ("output_basis", "output_unit", "calibration_reference")
                },
            )
    diagnostic_path = destination / "diagnostics.yaml"
    if diagnostics is not None:
        write_forward_diagnostics(diagnostics, diagnostic_path)
    else:
        # An earlier audit must not describe the newly written spectra.
        diagnostic_path.unlink(missing_ok=True)
