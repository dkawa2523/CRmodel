"""Compilation boundary between user configuration and numerical execution.

The compiled case owns objects whose structure is fixed for a forward solve.
Plasma-state values may change between evaluations without rebuilding those
objects; changes to reactions, states, geometry, instruments, or other static
sections produce a new compiled case.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

import numpy as np

from ..data.atomic_db import StateRegistry
from ..data.cross_section_db import CrossSectionLibrary
from ..data.emission_kernels import compile_emission_kernel_inventory
from ..instrument.spec import instrument_padding_nm, normalize_instrument_config
from ..io.normalize import normalize_composed_case_config
from ..io.species_packs import compose_species_packs
from ..io.validators import (
    validate_case_config,
    validate_composed_case_structural,
    validate_instrument_config,
)
from ..io.yaml_loader import load_yaml, resolve_path
from ..physics.bands import (
    BAND_EMISSION_PLUGINS,
    PHYSICAL_EMISSION_BASIS,
    compile_band_profiles,
    load_tabulated_band_profiles,
)
from ..physics.cr_atomic import AtomicCRSolver
from ..physics.cr_processes import CompiledReactionProcess, compile_reaction_processes
from ..physics.eedf import build_energy_grid
from ..physics.rates import RateCalculator
from .emissivity import compile_atomic_line_bases
from .observe import ObservationPlan

# These sections contain values evaluated for every zone or are reporting-only.
# All other public case sections are structural and trigger recompilation when
# changed. Keeping this list short makes the safe behavior the default.
_RUNTIME_SECTIONS = {"plasma_state", "eedf", "residuals", "diagnostics", "metadata"}
_TRANSPORT_KEYS = {"_instrument_cfgs", "_fine_wavelength_nm", "__path__"}


def static_case_view(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Return the part of a normalized case that defines compiled structure."""

    return {
        key: deepcopy(value)
        for key, value in cfg.items()
        if key not in _RUNTIME_SECTIONS and key not in _TRANSPORT_KEYS
    }


def load_instrument_configs(cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Load, validate, and normalize all instruments referenced by a case."""

    out: List[Dict[str, Any]] = []
    instrument_ids: set[str] = set()
    for item in cfg.get("instruments", []):
        if "yaml_file" in item:
            inst_cfg = load_yaml(resolve_path(cfg, item["yaml_file"]))
            inst_cfg["id"] = item.get("id", inst_cfg.get("id", Path(item["yaml_file"]).stem))
        else:
            inst_cfg = dict(item)
        validate_instrument_config(inst_cfg)
        instrument_id = str(inst_cfg["id"])
        if instrument_id in instrument_ids:
            raise ValueError(f"Duplicate effective instrument id after loading: {instrument_id}")
        instrument_ids.add(instrument_id)
        out.append(normalize_instrument_config(inst_cfg))
    return out


def _validate_emission_calibration_basis(
    cfg: Dict[str, Any], instrument_cfgs: List[Dict[str, Any]],
) -> None:
    """Require radiant-power emitters before converting chord radiance units."""

    component_bases = {"atomic_lines": PHYSICAL_EMISSION_BASIS}
    component_bases.update({
        str(band["id"]): BAND_EMISSION_PLUGINS.get(str(band["kind"])).output_basis
        for band in cfg.get("bands", [])
    })
    incompatible = [
        f"{component} ({basis})" for component, basis in component_bases.items()
        if basis != PHYSICAL_EMISSION_BASIS
    ]
    if not incompatible:
        return
    for instrument in instrument_cfgs:
        calibration = instrument.get("calibration")
        if calibration is not None:
            raise ValueError(
                f"Instrument '{instrument['id']}' calibration.input_basis='{calibration['input_basis']}' "
                f"is incompatible with emission components: {', '.join(incompatible)}. "
                "Use physical emission or an instrument without dimensional calibration."
            )


def build_fine_wavelength_grid(
    cfg: Dict[str, Any],
    instrument_cfgs: List[Dict[str, Any]],
    *,
    tabulated_profiles: Dict[str, Dict[str, np.ndarray]] | None = None,
) -> np.ndarray:
    """Build a shared grid that resolves detector bins, LSFs, and atomic lines.

    Narrow-line atomic-only cases use a segmented union of the padded instrument
    coverages. Cases with bands, or atomic profiles too broad for the padding to
    suppress their tails, retain a contiguous grid. Profiles are normalized on
    their complete intrinsic contours rather than this observing grid.
    """

    coverages: List[tuple[float, float]] = []
    step_candidates: List[float] = []

    for inst_cfg in instrument_cfgs:
        if "wavelength_grid_nm" in inst_cfg:
            grid = np.asarray(inst_cfg["wavelength_grid_nm"], dtype=float)
            coverage = (float(grid.min()), float(grid.max()))
            step_candidates.append(float(np.min(np.diff(grid))) / 8.0)
        else:
            coverage = (
                float(inst_cfg["wavelength_min_nm"]),
                float(inst_cfg["wavelength_max_nm"]),
            )
            step_candidates.append(float(inst_cfg["bin_nm"]) / 8.0)
        coverages.append(coverage)

        lsf = inst_cfg.get("lsf", {})
        for name in ("fwhm_nm", "fwhm_g_nm", "fwhm_l_nm"):
            if name in lsf:
                step_candidates.append(float(lsf[name]) / 8.0)

    transition_fwhms: List[float] = []
    for transition in cfg.get("transitions", []):
        fwhm = float(transition.get("profile", {}).get("fwhm_nm", 0.02))
        transition_fwhms.append(fwhm)
        step_candidates.append(fwhm / 6.0)
    for band in cfg.get("bands", []):
        if str(band.get("profile_kind", "gaussian")) == "gaussian":
            step_candidates.append(float(band.get("fwhm_nm", 5.0)) / 6.0)
    native_profiles = load_tabulated_band_profiles(cfg) if tabulated_profiles is None else tabulated_profiles
    for native in native_profiles.values():
        step_candidates.append(float(np.min(np.diff(native["wavelength_nm"]))) / 6.0)

    if not coverages or not step_candidates:
        raise ValueError("At least one valid instrument is required to build the wavelength grid.")
    refinement = float(cfg.get("numerics", {}).get("wavelength_refinement_factor", 1.0))
    dx = min(value for value in step_candidates if value > 0.0) / refinement
    padded_coverages: List[tuple[float, float]] = []
    for (start, stop), instrument_cfg in zip(coverages, instrument_cfgs, strict=True):
        padding = instrument_padding_nm(instrument_cfg, dx)
        padded_coverages.append((start - padding, stop + padding))
    coverages = padded_coverages

    # At one fifth of the padding, a Gaussian centered at the edge of an
    # instrument coverage is already below 1e-30 at the padded boundary.
    # Wider atomic profiles and bands can have non-negligible emission between
    # instrument settings, so retain a continuous source axis for those cases.
    broad_atomic_profile = any(fwhm >= 1.0 for fwhm in transition_fwhms)
    if cfg.get("bands") or broad_atomic_profile:
        start = min(coverage[0] for coverage in coverages)
        stop = max(coverage[1] for coverage in coverages)
        return np.arange(start, stop + 0.5 * dx, dx)

    merged_coverages: List[tuple[float, float]] = []
    for start, stop in sorted(coverages):
        if merged_coverages and start <= merged_coverages[-1][1]:
            previous_start, previous_stop = merged_coverages[-1]
            merged_coverages[-1] = (previous_start, max(previous_stop, stop))
        else:
            merged_coverages.append((start, stop))

    segments: List[np.ndarray] = []
    for start, stop in merged_coverages:
        segment = np.arange(start, stop + 0.5 * dx, dx)
        if segment.size:
            segments.append(segment)
    return np.unique(np.concatenate(segments))


@dataclass
class CompiledCase:
    """Validated static numerical objects for one canonical case structure."""

    cfg: Dict[str, Any]
    static_view: Dict[str, Any]
    state_registry: StateRegistry
    energy_eV: np.ndarray
    cross_sections: CrossSectionLibrary
    rate_calculator: RateCalculator
    reaction_processes: tuple[CompiledReactionProcess, ...]
    atomic_solver: AtomicCRSolver
    instrument_cfgs: List[Dict[str, Any]]
    fine_wavelength_nm: np.ndarray
    atomic_line_bases: Dict[str, np.ndarray]
    band_profiles: Dict[str, np.ndarray]
    species_pack_provenance: List[Dict[str, Any]]
    emission_kernel_inventory: Dict[str, Any]
    observation_plan: ObservationPlan

    def is_compatible(self, runtime_cfg: Dict[str, Any]) -> bool:
        return static_case_view(runtime_cfg) == self.static_view


def compile_case(cfg: Dict[str, Any]) -> CompiledCase:
    """Normalize and validate a case, then construct its static numerical plan."""

    composed, species_pack_provenance = compose_species_packs(cfg)
    validate_composed_case_structural(composed)
    canonical = normalize_composed_case_config(composed)
    validate_case_config(canonical)
    canonical = deepcopy(canonical)
    emission_kernel_inventory = compile_emission_kernel_inventory(canonical)

    registry = StateRegistry(canonical)
    energy_eV = build_energy_grid(canonical)
    cross_sections = CrossSectionLibrary()
    rate_calculator = RateCalculator(energy_eV, cross_sections)
    reaction_processes = compile_reaction_processes(canonical, validate_plugins=False)
    atomic_solver = AtomicCRSolver(
        canonical,
        registry,
        rate_calculator,
        reaction_processes,
        validate_plugins=False,
    )
    instrument_cfgs = load_instrument_configs(canonical)
    _validate_emission_calibration_basis(canonical, instrument_cfgs)
    native_band_profiles = load_tabulated_band_profiles(canonical)
    fine_wavelength_nm = build_fine_wavelength_grid(
        canonical, instrument_cfgs, tabulated_profiles=native_band_profiles
    )
    atomic_line_bases = compile_atomic_line_bases(canonical, fine_wavelength_nm)
    band_profiles = compile_band_profiles(
        canonical, fine_wavelength_nm, tabulated_profiles=native_band_profiles
    )
    observation_plan = ObservationPlan.compile(
        canonical, instrument_cfgs, fine_wavelength_nm, validated=True
    )

    return CompiledCase(
        cfg=canonical,
        static_view=static_case_view(canonical),
        state_registry=registry,
        energy_eV=energy_eV,
        cross_sections=cross_sections,
        rate_calculator=rate_calculator,
        reaction_processes=reaction_processes,
        atomic_solver=atomic_solver,
        instrument_cfgs=instrument_cfgs,
        fine_wavelength_nm=fine_wavelength_nm,
        atomic_line_bases=atomic_line_bases,
        band_profiles=band_profiles,
        species_pack_provenance=species_pack_provenance,
        emission_kernel_inventory=emission_kernel_inventory,
        observation_plan=observation_plan,
    )
