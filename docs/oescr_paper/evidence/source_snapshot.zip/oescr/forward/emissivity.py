
from __future__ import annotations

from typing import Any, Dict, List, Mapping

import numpy as np
from scipy import constants as const

from ..data.atomic_db import StateRegistry
from ..physics.trapping import effective_A


def gaussian_line_profile(wavelength_nm: np.ndarray, center_nm: float, fwhm_nm: float) -> np.ndarray:
    sigma = max(float(fwhm_nm) / 2.35482004503, 1.0e-6)
    y = np.exp(-0.5 * ((wavelength_nm - center_nm) / sigma) ** 2)
    # The emitter's integrated power belongs to the full line, even when the
    # observing instrument covers only part of its contour.
    return y / (sigma * np.sqrt(2.0 * np.pi))


def compile_atomic_line_bases(
    cfg: Mapping[str, Any],
    wavelength_nm: np.ndarray,
) -> Dict[str, np.ndarray]:
    """Compile static line-shape and photon-energy factors by transition id."""

    bases: Dict[str, np.ndarray] = {}
    for transition in cfg.get("transitions", []):
        wavelength = float(transition["wavelength_nm"])
        profile = transition.get("profile", {})
        shape = gaussian_line_profile(
            wavelength_nm,
            wavelength,
            float(profile.get("fwhm_nm", 0.02)),
        )
        photon_energy = const.h * const.c / max(wavelength * 1.0e-9, 1.0e-30)
        scale = float(transition.get("amplitude_scale", 1.0)) * photon_energy / (4.0 * np.pi)
        bases[str(transition["id"])] = scale * shape
    return bases


def atomic_line_spectrum_zone(
    cfg: Dict[str, Any],
    registry: StateRegistry,
    populations_m3: Dict[str, float],
    wavelength_nm: np.ndarray,
    zone_context: Dict[str, float] | None = None,
    line_bases: Mapping[str, np.ndarray] | None = None,
    *,
    validate_plugins: bool = True,
    collect_details: bool = True,
) -> Dict[str, Any]:
    spec = np.zeros_like(wavelength_nm, dtype=float)
    line_info: List[Dict[str, float]] = []
    zone_densities = {**(zone_context or {}), **populations_m3}
    for tr in cfg.get("transitions", []):
        upper = tr["upper"]
        if upper not in zone_densities:
            raise ValueError(f"Transition '{tr['id']}' requires a solved or externally supplied density for '{upper}'.")
        n_upper = zone_densities[upper]
        Aeff = effective_A(tr, zone_context=zone_context, validate=validate_plugins)
        lam_nm = float(tr["wavelength_nm"])
        transition_id = str(tr["id"])
        basis = None if line_bases is None else line_bases.get(transition_id)
        photon_energy = const.h * const.c / max(lam_nm * 1.0e-9, 1.0e-30)
        static_scale = float(tr.get("amplitude_scale", 1.0)) * photon_energy / (4.0 * np.pi)
        if basis is None:
            intrinsic = tr.get("profile", {})
            profile = gaussian_line_profile(
                wavelength_nm,
                lam_nm,
                float(intrinsic.get("fwhm_nm", 0.02)),
            )
            basis = static_scale * profile
        amp = n_upper * Aeff * static_scale
        spec += n_upper * Aeff * basis
        if collect_details:
            line_info.append(
                {
                    "wavelength_nm": lam_nm,
                    "upper_population_m3": n_upper,
                    "Aeff_s-1": Aeff,
                    "integrated_emissivity_W_m3_sr": amp,
                }
            )
    return {"spectrum": spec, "lines": line_info}
