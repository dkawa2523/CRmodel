from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

import numpy as np

from ..geometry.plugin import GeometryPlugin, get_geometry_plugin
from ..instrument.spec import InstrumentSpec


@dataclass
class _SpectrumSampling:
    wavelength_nm: np.ndarray
    left_indices: np.ndarray
    right_weights: np.ndarray
    supported: np.ndarray

    @classmethod
    def compile(cls, source: np.ndarray, instrument: InstrumentSpec) -> "_SpectrumSampling":
        # Retain intrinsic resolution until after LSF convolution. Detector-bin
        # spacing alone can completely miss an unresolved line.
        source_step = float(np.min(np.diff(source)))
        target = instrument.fine_grid_nm(max_step_nm=source_step)
        left = np.clip(np.searchsorted(source, target, side="right") - 1, 0, source.size - 2)
        intervals = source[left + 1] - source[left]
        weights = (target - source[left]) / intervals
        # A segmented source grid has no interpolation support across its gaps.
        supported = (target >= source[0]) & (target <= source[-1]) & (
            (intervals <= 1.5 * source_step)
            | np.isclose(weights, 0.0, rtol=0.0, atol=1.0e-8)
            | np.isclose(weights, 1.0, rtol=0.0, atol=1.0e-8)
        )
        return cls(target, left, weights, supported)

    def apply(self, spectra: np.ndarray) -> np.ndarray:
        sampled = (
            spectra[:, self.left_indices] * (1.0 - self.right_weights)
            + spectra[:, self.left_indices + 1] * self.right_weights
        )
        sampled[:, ~self.supported] = 0.0
        return sampled


@dataclass
class ObservationPlan:
    geometry_plugin: GeometryPlugin
    geometry_matrix: np.ndarray
    instruments: List[InstrumentSpec]
    sampling: List[_SpectrumSampling]

    @classmethod
    def compile(
        cls,
        cfg: Dict[str, Any],
        instrument_cfgs: List[Dict[str, Any]],
        source_wavelength_nm: np.ndarray,
        *,
        validated: bool = False,
    ) -> "ObservationPlan":
        plugin = get_geometry_plugin(cfg, validate=not validated)
        instruments = [InstrumentSpec(item, validated=validated) for item in instrument_cfgs]
        return cls(
            geometry_plugin=plugin,
            geometry_matrix=plugin.build_matrix(cfg),
            instruments=instruments,
            sampling=[_SpectrumSampling.compile(source_wavelength_nm, inst) for inst in instruments],
        )

    def observe(
        self,
        cfg: Dict[str, Any],
        zone_spectra: np.ndarray,
    ) -> Dict[str, Dict[str, Dict[str, Any]]]:
        out: Dict[str, Dict[str, Dict[str, Any]]] = {}
        for inst, sampling in zip(self.instruments, self.sampling, strict=True):
            fine_wl = sampling.wavelength_nm
            zone_interp = sampling.apply(zone_spectra)
            chord_spectra = self.geometry_matrix @ zone_interp
            chord_spectra = self.geometry_plugin.postprocess_chord_spectra(cfg, chord_spectra)

            measurements: Dict[str, Dict[str, Any]] = {}
            observed = inst.observe(fine_wl, chord_spectra)
            for chord_idx in range(chord_spectra.shape[0]):
                measurements[f"chord_{chord_idx}"] = {
                    **observed,
                    "wavelength_nm": observed["wavelength_nm"].copy(),
                    "intensity": observed["intensity"][chord_idx],
                }
            out[inst.instrument_id] = measurements
        return out
