"""Export auditable diagnostics for a single-temperature recovery benchmark.

This module owns presentation and result-file concerns that are shared by
Maxwellian recovery scenarios.  Scenario scripts remain responsible for
defining the physical case, generating measurements, running the inverse
solver, and deciding what scientific claim is permitted.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.axes import Axes

from ..forward.model import ForwardResult
from ..inverse.gain_model import apply_gain_offset_tilt
from ..inverse.measurements import Measurement, combined_residual_mask
from ..inverse.objectives import residual_vector, select_windows_for_instrument
from ..inverse.optimize import FitResult, InverseSolver
from ..inverse.window_policy import fit_pixel_mask
from ..physics.eedf import build_eedf_for_zone, build_energy_grid

ScoreMetric = dict[str, float | int]
SpectrumSeries = dict[str, np.ndarray]


@dataclass(frozen=True)
class TemperatureRecoveryFigureSpec:
    """Labels and reference values for the fixed 2x2 recovery overview."""

    truth_te_eV: float
    initial_te_eV: float
    channel_order: tuple[str, str]
    channel_titles: tuple[str, str]
    title: str


@dataclass(frozen=True)
class RecoveryBundleResult:
    """Metrics calculated while exporting a recovery result bundle."""

    score_metrics: dict[str, ScoreMetric]


def _role_mask(
    wavelength_nm: np.ndarray,
    windows: list[dict[str, Any]],
    role: str,
    *,
    kernel_ids: set[str] | None = None,
) -> np.ndarray:
    mask = np.zeros(wavelength_nm.shape, dtype=bool)
    for window in windows:
        if str(window.get("analysis_role", "fit")) != role:
            continue
        if kernel_ids is not None and str(window.get("kernel_id", "")) not in kernel_ids:
            continue
        center = float(window["center_nm"])
        half_width = float(window.get("half_width_nm", 1.0))
        mask |= (wavelength_nm >= center - half_width) & (wavelength_nm <= center + half_width)
    return mask


def _standardized_rmse(residuals: list[np.ndarray]) -> ScoreMetric:
    if not residuals:
        return {"standardized_rmse": float("nan"), "pixel_count": 0}
    stacked = np.concatenate(residuals)
    return {
        "standardized_rmse": float(np.sqrt(np.mean(stacked**2))),
        "pixel_count": int(len(stacked)),
    }


def _kernel_holdout_sets(
    windows: list[dict[str, Any]],
) -> tuple[set[str], set[str]]:
    fit_kernel_ids = {
        str(window["kernel_id"])
        for window in windows
        if str(window.get("analysis_role", "fit")) == "fit" and window.get("kernel_id")
    }
    score_kernel_ids = {
        str(window["kernel_id"])
        for window in windows
        if str(window.get("analysis_role", "fit")) == "score" and window.get("kernel_id")
    }
    return score_kernel_ids - fit_kernel_ids, score_kernel_ids & fit_kernel_ids


def _corrected_predictions(
    solver: InverseSolver,
    fit: FitResult,
    measurement: Measurement,
    instrument_id: str,
    optimized: ForwardResult,
    initial: ForwardResult,
    initial_aux: dict[str, Any],
) -> tuple[np.ndarray, np.ndarray]:
    raw_prediction = optimized.spectra[instrument_id][measurement.prediction_key]
    prediction = np.interp(
        measurement.wavelength_nm,
        raw_prediction["wavelength_nm"],
        raw_prediction["intensity"],
        left=0.0,
        right=0.0,
    )
    raw_initial = initial.spectra[instrument_id][measurement.prediction_key]
    initial_prediction = np.interp(
        measurement.wavelength_nm,
        raw_initial["wavelength_nm"],
        raw_initial["intensity"],
        left=0.0,
        right=0.0,
    )
    correction = fit.aux["gain_offset"][(instrument_id, measurement.id)]
    prediction = apply_gain_offset_tilt(
        measurement.wavelength_nm,
        prediction,
        **correction,
    )
    initial_correction = initial_aux["gain_offset"][(instrument_id, measurement.id)]
    initial_prediction = apply_gain_offset_tilt(
        measurement.wavelength_nm,
        initial_prediction,
        **initial_correction,
    )
    return prediction, initial_prediction


def _score_masks(
    measurement: Measurement,
    instrument_windows: list[dict[str, Any]],
    distinct_holdout_ids: set[str],
    branch_holdout_ids: set[str],
) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    fit_mask = fit_pixel_mask(measurement.wavelength_nm, instrument_windows)
    if fit_mask is None:
        fit_mask = np.ones(measurement.wavelength_nm.shape, dtype=bool)
    score_mask = _role_mask(measurement.wavelength_nm, instrument_windows, "score")
    return fit_mask, {
        "all": score_mask,
        "distinct_kernel_holdout": _role_mask(
            measurement.wavelength_nm,
            instrument_windows,
            "score",
            kernel_ids=distinct_holdout_ids,
        ),
        "branch_holdout": _role_mask(
            measurement.wavelength_nm,
            instrument_windows,
            "score",
            kernel_ids=branch_holdout_ids,
        ),
    }


def _append_score_residuals(
    score_residuals: dict[str, list[np.ndarray]],
    measurement: Measurement,
    prediction: np.ndarray,
    sigma: np.ndarray,
    score_masks: dict[str, np.ndarray],
) -> None:
    for label, requested_mask in score_masks.items():
        valid_mask = combined_residual_mask(measurement, requested_mask)
        if np.any(valid_mask):
            score_residuals[label].append(
                (measurement.intensity[valid_mask] - prediction[valid_mask]) / sigma[valid_mask]
            )


def _write_spectrum_csv(
    path: Path,
    measurement: Measurement,
    initial_prediction: np.ndarray,
    prediction: np.ndarray,
    sigma: np.ndarray,
    pixel_status: np.ndarray,
    fit_mask: np.ndarray,
    score_mask: np.ndarray,
) -> None:
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "wavelength_nm",
                "measured",
                "initial_prediction",
                "predicted",
                "sigma",
                "pixel_status",
                "fit_mask",
                "score_mask",
            ]
        )
        writer.writerows(
            zip(
                measurement.wavelength_nm,
                measurement.intensity,
                initial_prediction,
                prediction,
                sigma,
                pixel_status,
                fit_mask.astype(int),
                score_mask.astype(int),
                strict=True,
            )
        )


def _write_spectrum_bundle(
    output_dir: Path,
    solver: InverseSolver,
    fit: FitResult,
    *,
    spectrum_directory: str,
) -> tuple[dict[str, ScoreMetric], dict[str, SpectrumSeries]]:
    optimized = solver.model.predict(fit.case_opt)
    initial = solver.model.predict(solver.case_cfg)
    _, initial_aux = residual_vector(
        solver.model,
        solver.case_cfg,
        solver.inv_cfg,
        solver.measurements,
        solver.windows,
        include_constraints=False,
    )
    instruments = {str(item["id"]): item for item in solver.model.instrument_configs_for(fit.case_opt)}
    distinct_holdout_ids, branch_holdout_ids = _kernel_holdout_sets(solver.windows)
    score_residuals: dict[str, list[np.ndarray]] = {
        "all": [],
        "distinct_kernel_holdout": [],
        "branch_holdout": [],
    }
    representative_spectra: dict[str, SpectrumSeries] = {}
    spectra_dir = output_dir / spectrum_directory
    spectra_dir.mkdir(parents=True, exist_ok=True)

    for instrument_id, measurements in solver.measurements.items():
        instrument_windows = select_windows_for_instrument(
            instruments[instrument_id],
            solver.windows,
        )
        for measurement in measurements:
            sigma = measurement.sigma
            if sigma is None:
                raise ValueError(f"Benchmark measurement '{measurement.id}' requires pointwise sigma.")
            pixel_status = measurement.pixel_status
            if pixel_status is None:
                pixel_status = np.full(len(measurement.wavelength_nm), "valid", dtype=object)
            prediction, initial_prediction = _corrected_predictions(
                solver,
                fit,
                measurement,
                instrument_id,
                optimized,
                initial,
                initial_aux,
            )
            fit_mask, score_masks = _score_masks(
                measurement,
                instrument_windows,
                distinct_holdout_ids,
                branch_holdout_ids,
            )
            _append_score_residuals(
                score_residuals,
                measurement,
                prediction,
                sigma,
                score_masks,
            )
            if measurement.replicate_id == "rep_0":
                representative_spectra[instrument_id] = {
                    "wavelength_nm": measurement.wavelength_nm.copy(),
                    "measured": measurement.intensity.copy(),
                    "sigma": np.asarray(sigma, dtype=float).copy(),
                    "initial": initial_prediction.copy(),
                    "optimized": prediction.copy(),
                }
            _write_spectrum_csv(
                spectra_dir / f"{measurement.id}.csv",
                measurement,
                initial_prediction,
                prediction,
                sigma,
                pixel_status,
                fit_mask,
                score_masks["all"],
            )

    return (
        {label: _standardized_rmse(values) for label, values in score_residuals.items()},
        representative_spectra,
    )


def _write_derived_eedf(output_dir: Path, case_opt: dict[str, Any]) -> None:
    energy_eV = build_energy_grid(case_opt)
    distribution = build_eedf_for_zone(case_opt, 0, energy_eV)
    with (output_dir / "derived_maxwellian_eedf.csv").open("w", newline="", encoding="utf-8") as stream:
        stream.write("# status: derived_from_fitted_te_not_independently_reconstructed\n")
        writer = csv.writer(stream)
        writer.writerow(["energy_eV", "fE_eV-1"])
        writer.writerows(zip(energy_eV, distribution, strict=True))


def _write_optimization_trace(output_dir: Path, fit: FitResult) -> None:
    trace = list(fit.optimization_trace or [])
    with (output_dir / "optimization_trace.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["evaluation", "stage", "loss", "electron_temperature_eV"])
        for point in trace:
            writer.writerow(
                [
                    int(point["evaluation"]),
                    str(point["stage"]),
                    float(point["loss"]),
                    float(point["x"][0]),
                ]
            )


def _profile_points(fit: FitResult) -> list[dict[str, Any]]:
    profiles = (fit.parameter_profiles or {}).get("profiles", {})
    return list(profiles.get("electron_temperature_eV", {}).get("points", []))


def _write_profile_table(output_dir: Path, fit: FitResult) -> None:
    with (output_dir / "temperature_profile.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "electron_temperature_eV",
                "measurement_sum_squares",
                "delta_measurement_sum_squares",
                "point_source",
                "is_reference",
            ]
        )
        for point in _profile_points(fit):
            writer.writerow(
                [
                    float(point["value"]),
                    float(point["measurement_sum_squares"]),
                    float(point["delta_measurement_sum_squares"]),
                    str(point["point_source"]),
                    bool(point["is_reference"]),
                ]
            )


def _shade_windows(axis: Axes, windows: list[dict[str, Any]]) -> None:
    labels_used: set[str] = set()
    for window in windows:
        role = str(window.get("analysis_role", "fit"))
        if role not in {"fit", "score"}:
            continue
        center = float(window["center_nm"])
        half_width = float(window.get("half_width_nm", 1.0))
        label = "fit windows" if role == "fit" else "held-out windows"
        axis.axvspan(
            center - half_width,
            center + half_width,
            color="#4c78a8" if role == "fit" else "#f2a900",
            alpha=0.09 if role == "fit" else 0.14,
            linewidth=0.0,
            label=label if label not in labels_used else None,
        )
        labels_used.add(label)


def _plot_spectrum_panel(
    axis: Axes,
    spectrum: SpectrumSeries,
    title: str,
    initial_te_eV: float,
    fitted_te_eV: float,
    windows: list[dict[str, Any]],
) -> None:
    scale = max(float(np.max(np.abs(spectrum["measured"]))), 1.0e-30)
    wavelength = spectrum["wavelength_nm"]
    axis.fill_between(
        wavelength,
        (spectrum["measured"] - spectrum["sigma"]) / scale,
        (spectrum["measured"] + spectrum["sigma"]) / scale,
        color="0.75",
        alpha=0.35,
        linewidth=0.0,
        label=r"measurement $\pm1\sigma$",
    )
    axis.scatter(
        wavelength,
        spectrum["measured"] / scale,
        s=11.0,
        color="black",
        alpha=0.68,
        linewidths=0.0,
        label="synthetic measurement",
        zorder=4,
    )
    axis.plot(
        wavelength,
        spectrum["initial"] / scale,
        color="#777777",
        linewidth=1.7,
        linestyle="--",
        label=f"initial ({initial_te_eV:.1f} eV)",
    )
    axis.plot(
        wavelength,
        spectrum["optimized"] / scale,
        color="#d62728",
        linewidth=2.0,
        label=f"optimized ({fitted_te_eV:.3f} eV)",
    )
    _shade_windows(axis, windows)
    axis.set_title(title, loc="left", fontweight="bold")
    axis.set_xlabel("Wavelength (nm)")
    axis.set_ylabel("Normalized signal")
    axis.set_ylim(bottom=-0.035)
    axis.grid(alpha=0.18)
    axis.legend(fontsize=7.5, ncol=2, loc="upper right")


def _plot_profile_panel(axis: Axes, fit: FitResult, truth_te_eV: float) -> None:
    points = _profile_points(fit)
    profile_te = np.asarray([float(point["value"]) for point in points], dtype=float)
    profile_delta = np.asarray(
        [float(point["delta_measurement_sum_squares"]) for point in points],
        dtype=float,
    )
    order = np.argsort(profile_te)
    axis.semilogy(
        profile_te[order],
        np.maximum(profile_delta[order], 1.0e-3),
        marker="o",
        markersize=5.5,
        linewidth=1.8,
        color="#4c78a8",
    )
    axis.axvline(truth_te_eV, color="black", linewidth=1.5, label="truth")
    axis.axvline(
        float(fit.x_opt[0]),
        color="#d62728",
        linewidth=1.7,
        linestyle="--",
        label="estimate",
    )
    axis.set_title("(c) Conditional temperature profile", loc="left", fontweight="bold")
    axis.set_xlabel("Maxwellian effective $T_e$ (eV)")
    axis.set_ylabel(r"$\Delta\chi^2_{measurement}$")
    axis.grid(alpha=0.2, which="both")
    axis.legend()


def _plot_trace_panel(axis: Axes, fit: FitResult, truth_te_eV: float) -> None:
    trace = list(fit.optimization_trace or [])
    evaluations = np.asarray([int(point["evaluation"]) for point in trace], dtype=int)
    losses = np.asarray([float(point["loss"]) for point in trace], dtype=float)
    temperatures = np.asarray([float(point["x"][0]) for point in trace], dtype=float)
    axis.semilogy(
        evaluations,
        np.maximum(losses, 1.0e-12),
        color="#2ca02c",
        marker="o",
        markersize=4.8,
        linewidth=1.6,
        label="objective loss",
    )
    axis.set_title("(d) Local optimization history", loc="left", fontweight="bold")
    axis.set_xlabel("Residual evaluation")
    axis.set_ylabel("Loss")
    axis.grid(alpha=0.2, which="both")
    temperature_axis = axis.twinx()
    temperature_axis.plot(
        evaluations,
        temperatures,
        color="#9467bd",
        linewidth=1.4,
        alpha=0.75,
        label="$T_e$",
    )
    temperature_axis.axhline(truth_te_eV, color="black", linewidth=1.0, linestyle=":")
    temperature_axis.set_ylabel("$T_e$ (eV)", color="#9467bd")
    handles, labels = axis.get_legend_handles_labels()
    handles_2, labels_2 = temperature_axis.get_legend_handles_labels()
    axis.legend(handles + handles_2, labels + labels_2, loc="upper right")


def _write_overview_figure(
    output_dir: Path,
    solver: InverseSolver,
    fit: FitResult,
    representative_spectra: dict[str, SpectrumSeries],
    spec: TemperatureRecoveryFigureSpec,
) -> None:
    figure, axes = plt.subplots(2, 2, figsize=(12.0, 7.8), constrained_layout=True)
    instruments = {str(item["id"]): item for item in solver.model.instrument_configs_for(fit.case_opt)}
    for axis, instrument_id, title in zip(axes[0], spec.channel_order, spec.channel_titles, strict=True):
        windows = select_windows_for_instrument(
            instruments[instrument_id],
            solver.windows,
        )
        _plot_spectrum_panel(
            axis,
            representative_spectra[instrument_id],
            title,
            spec.initial_te_eV,
            float(fit.x_opt[0]),
            windows,
        )
    _plot_profile_panel(axes[1, 0], fit, spec.truth_te_eV)
    _plot_trace_panel(axes[1, 1], fit, spec.truth_te_eV)
    figure.suptitle(spec.title, fontweight="bold")
    figure_dir = output_dir / "figures"
    figure_dir.mkdir(parents=True, exist_ok=True)
    figure.savefig(figure_dir / "benchmark_overview.png", dpi=220)
    figure.savefig(figure_dir / "benchmark_overview.svg")
    plt.close(figure)


def write_single_temperature_recovery_bundle(
    output_dir: Path,
    solver: InverseSolver,
    fit: FitResult,
    figure_spec: TemperatureRecoveryFigureSpec,
    *,
    spectrum_directory: str = "spectra",
) -> RecoveryBundleResult:
    """Write spectra, fit diagnostics, derived EEDF, and the 2x2 overview.

    The returned held-out metrics let a scenario decide its own pass threshold;
    this reporting layer deliberately does not grant a scientific claim.
    """

    score_metrics, representative_spectra = _write_spectrum_bundle(
        output_dir,
        solver,
        fit,
        spectrum_directory=spectrum_directory,
    )
    _write_derived_eedf(output_dir, fit.case_opt)
    _write_optimization_trace(output_dir, fit)
    _write_profile_table(output_dir, fit)
    _write_overview_figure(
        output_dir,
        solver,
        fit,
        representative_spectra,
        figure_spec,
    )
    return RecoveryBundleResult(score_metrics=score_metrics)
