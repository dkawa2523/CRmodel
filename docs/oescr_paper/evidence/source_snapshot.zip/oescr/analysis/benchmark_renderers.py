"""CSV and compact Markdown exports for the explicit benchmark analyzer."""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Any


def write_flat_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    columns = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def write_spectral_comparisons(path: Path, scenarios: dict[str, dict[str, Any]]) -> None:
    """Export standard SpectralFit records without reconstructing predictions."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "scenario",
                "instrument_id",
                "observation_id",
                "prediction_key",
                "wavelength_nm",
                "measured",
                "predicted",
                "residual",
                "used_for_fit",
            ]
        )
        for scenario, data in scenarios.items():
            for fit in data["spectral_fits"]:
                residual = fit.residual
                for index, wavelength in enumerate(fit.wavelength_nm):
                    writer.writerow(
                        [
                            scenario,
                            fit.instrument_id,
                            fit.observation_id,
                            fit.prediction_key,
                            wavelength,
                            fit.measured[index],
                            fit.predicted[index],
                            residual[index],
                            bool(fit.used_for_fit[index]),
                        ]
                    )


def _table(rows: list[dict[str, Any]], columns: list[str]) -> list[str]:
    def cell(value: Any) -> str:
        if value is None:
            return "unavailable"
        text = f"{value:.6g}" if isinstance(value, float) else str(value)
        return text.replace("|", "\\|").replace("\n", " ")

    return [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join("---" for _ in columns) + " |",
        *["| " + " | ".join(cell(row.get(key)) for key in columns) + " |" for row in rows],
    ]


def write_markdown_report(path: Path, summary: dict[str, Any]) -> None:
    saved = summary["saved_fit"]
    lines = [
        f"# {summary['title']}",
        "",
        "Generated-data self-consistency analysis. These values do not establish experimental accuracy.",
        "",
        f"Saved optimizer success: {saved['success']}; recorded cost: {saved['cost']:.6g}. "
        "The comparisons below reevaluate saved parameters with current inputs and code; optimization was not rerun.",
        "",
        "## Spectral comparison",
        "",
        *_table(summary["scenario_summary"], ["scenario", "cost", "mean_correlation", "mean_nrmse_std"]),
        "",
        "## Named parameter recovery",
        "",
        *_table(
            summary["parameter_recovery"], ["name", "role", "initial", "optimized", "truth", "optimized_relative_error"]
        ),
        "",
        "Numerical details: [summary](analysis_summary.yaml), [observations](chord_metrics.csv), "
        "[windows](window_metrics.csv), [ratios](mixed_pattern_metrics.csv), "
        "[spectral comparisons](spectral_comparisons.csv).",
        "",
        "Inspect the standard result bundle for fitted spectra, warnings and any explicitly requested audits.",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
