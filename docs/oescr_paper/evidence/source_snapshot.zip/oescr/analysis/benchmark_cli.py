"""Command-line orchestration for benchmark report generation."""

from __future__ import annotations

import argparse

from .benchmark_results import analyze_one, resolve_benchmark_dir


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Compare a generated benchmark's canonical fit bundle with its initial and truth cases."
    )
    parser.add_argument(
        "benchmarks",
        nargs="+",
        help="Benchmark directory names under examples/benchmarks or absolute paths",
    )
    parser.add_argument(
        "--result-dir-name",
        default="default",
        help="Directory under runs/, or absolute result directory containing result.yaml and case_opt.yaml",
    )
    parser.add_argument(
        "--out-name",
        default="analysis",
        help="Subdirectory to write analysis outputs into",
    )
    args = parser.parse_args()

    for benchmark in args.benchmarks:
        output_directory = analyze_one(
            resolve_benchmark_dir(benchmark),
            args.result_dir_name,
            args.out_name,
        )
        print(f"Analysis written to: {output_directory}")


if __name__ == "__main__":
    main()
