"""Numerical analysis of canonical fit bundles against generated benchmark truth."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np

from oescr import __version__
from oescr.analysis.benchmark_contract import build_analysis_contract, build_run_fingerprint
from oescr.analysis.benchmark_metrics import aggregate_window_rows, safe_corr, safe_mean
from oescr.analysis.benchmark_renderers import write_flat_csv, write_markdown_report, write_spectral_comparisons
from oescr.analysis.classification import (
    PAIR_CLASS_LOG_TOL,
    WINDOW_CLASS_THRESHOLDS,
    classify_pair_log_error,
    classify_window,
    scenario_accuracy_vs_truth,
    window_pass_rate_by_kind,
)
from oescr.data.provenance import file_sha256
from oescr.inverse.measurements import combined_residual_mask
from oescr.inverse.objectives import residual_vector
from oescr.inverse.optimize import InverseSolver
from oescr.inverse.reporting import load_fit_result
from oescr.inverse.window_metrics import window_features
from oescr.io.normalize import normalize_case_config
from oescr.io.pathmap import get_path
from oescr.io.yaml_loader import load_yaml, save_yaml

BENCH_ROOT = Path(__file__).resolve().parents[2] / "examples" / "benchmarks"


def resolve_benchmark_dir(value: str) -> Path:
    path = Path(value)
    if path.is_absolute():
        return path
    candidate = (BENCH_ROOT / value).resolve()
    if candidate.exists():
        return candidate
    return path.resolve()


def _load_truth_case(path: Path) -> Dict[str, Any]:
    return normalize_case_config(load_yaml(path))


def _validate_result_case_consistency(
    solver: InverseSolver,
    result: Dict[str, Any],
    optimized_case: Dict[str, Any],
) -> None:
    """Reject mixed result/case files before producing benchmark evidence."""

    reported = result.get("parameters")
    expected_names = solver.params.names()
    if not isinstance(reported, dict) or set(reported) != set(expected_names):
        raise ValueError(
            "result.yaml parameters do not match the inverse parameter definition; "
            "regenerate result.yaml and case_opt.yaml together."
        )
    for parameter in solver.params.params:
        case_value = float(get_path(optimized_case, parameter.path))
        result_value = float(reported[parameter.name])
        if not np.isclose(case_value, result_value, rtol=1.0e-10, atol=0.0):
            raise ValueError(
                f"result.yaml parameter '{parameter.name}' disagrees with case_opt.yaml; "
                "regenerate the inverse output together."
            )


def _scenario_analysis(
    scenario_name: str,
    case_cfg: Dict[str, Any],
    solver: InverseSolver,
    measurements: Dict[str, List[Any]],
    windows: List[Dict[str, Any]],
) -> Dict[str, Any]:
    residuals, aux = residual_vector(
        solver.model,
        case_cfg,
        solver.inv_cfg,
        measurements,
        windows,
        collect_spectral_fits=True,
    )
    spectral_fits = aux.pop("spectral_fits")
    objective = solver.inv_cfg.get("fit", {}).get("objective", {})
    min_relative_signal = float(objective.get("window_min_relative_signal", 0.02))
    instrument_windows = {}
    for instrument_id, names in aux["declared_windows"].items():
        declared_names = set(names)
        instrument_windows[instrument_id] = [
            window for window in windows if str(window.get("name", "")) in declared_names
        ]
    measurement_map = {(inst, item.id): item for inst, items in measurements.items() for item in items}
    chord_metrics: List[Dict[str, Any]] = []
    window_entries: List[Dict[str, Any]] = []
    for fit in spectral_fits:
        inst_id, observation_id = fit.instrument_id, fit.observation_id
        measurement = measurement_map[(inst_id, observation_id)]
        valid = combined_residual_mask(measurement)
        wavelength = fit.wavelength_nm[valid]
        measured = fit.measured[valid]
        predicted = fit.predicted[valid]
        correction = aux.get("gain_offset", {}).get((inst_id, observation_id), {})
        binding = {
            "scenario": scenario_name,
            "instrument_id": inst_id,
            "chord_key": observation_id,
            "measurement_id": observation_id,
            "prediction_key": fit.prediction_key,
        }
        if len(measured):
            rmse = float(np.sqrt(np.mean((predicted - measured) ** 2)))
            area = float(np.trapezoid(measured, wavelength))
            metrics = {
                "correlation": safe_corr(measured, predicted),
                "rmse": rmse,
                "nrmse_std": rmse / max(float(np.std(measured)), 1.0e-30),
                "nrmse_range": rmse / max(float(np.ptp(measured)), 1.0e-30),
                "integrated_area_ratio": float(np.trapezoid(predicted, wavelength)) / max(abs(area), 1.0e-30),
            }
        else:
            metrics = {
                key: None for key in ("correlation", "rmse", "nrmse_std", "nrmse_range", "integrated_area_ratio")
            }
        chord_metrics.append(
            {
                **binding,
                **metrics,
                "gain": float(correction.get("gain", 1.0)),
                "offset": float(correction.get("offset", 0.0)),
                "valid_pixel_count": int(np.sum(valid)),
                "excluded_pixel_count": int(len(valid) - np.sum(valid)),
            }
        )
        if not len(measured):
            continue
        skipped = set(aux.get("skipped_windows_low_signal", {}).get((inst_id, observation_id), []))
        local_rows: List[Dict[str, Any]] = []
        for window in instrument_windows[inst_id]:
            center = float(window["center_nm"])
            half_width = float(window.get("half_width_nm", 1.0))
            baseline = str(window.get("baseline_mode", objective.get("window_baseline_mode", "local_linear")))
            observed = window_features(wavelength, measured, center, half_width, baseline_mode=baseline)
            modeled = window_features(wavelength, predicted, center, half_width, baseline_mode=baseline)
            row = {
                **binding,
                "window_name": str(window.get("name", "")),
                "family": str(window.get("family", "")),
                "kind": str(window.get("kind", "")),
                "species": str(window.get("species", "")),
                "center_nm": center,
                "half_width_nm": half_width,
                "use_area": bool(window.get("use_area", True)),
                "use_peak": bool(window.get("use_peak", True)),
                "peak_shift_nm": float(modeled["peak_wavelength_nm"]) - float(observed["peak_wavelength_nm"]),
                "low_signal_skipped": str(window.get("name", "")) in skipped,
            }
            for metric in ("area", "peak"):
                row[f"measurement_{metric}"] = float(observed[metric])
                row[f"prediction_{metric}"] = float(modeled[metric])
                row[f"{metric}_ratio"] = float(modeled[metric]) / max(abs(float(observed[metric])), 1.0e-30)
            local_rows.append(row)
        maxima = {
            metric: max((abs(float(row[f"measurement_{metric}"])) for row in local_rows), default=0.0)
            for metric in ("area", "peak")
        }
        for row in local_rows:
            for metric in ("area", "peak"):
                row[f"relative_signal_{metric}"] = abs(float(row[f"measurement_{metric}"])) / max(
                    maxima[metric], 1.0e-30
                )
            row["relative_signal"] = max(row["relative_signal_area"], row["relative_signal_peak"])
            row["relative_signal_threshold"] = min_relative_signal
            window_entries.append(row)
    return {
        "cost": 0.5 * float(np.dot(residuals, residuals)),
        "aux": aux,
        "chord_metrics": chord_metrics,
        "window_metrics": window_entries,
        "spectral_fits": spectral_fits,
    }


def _parameter_rows(solver: InverseSolver, truth: Dict[str, Any], optimized: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Use normalized parameters for both explicit and compact-array inputs."""
    rows = []
    for parameter in solver.params.params:
        initial = float(get_path(solver.case_cfg, parameter.path))
        reference = float(get_path(truth, parameter.path))
        value = float(get_path(optimized, parameter.path))
        denominator = abs(reference)
        rows.append(
            {
                "name": parameter.name,
                "path": parameter.path,
                "role": parameter.role,
                "initial": initial,
                "optimized": value,
                "truth": reference,
                "initial_absolute_error": abs(initial - reference),
                "optimized_absolute_error": abs(value - reference),
                "initial_relative_error": abs(initial - reference) / denominator if denominator else None,
                "optimized_relative_error": abs(value - reference) / denominator if denominator else None,
            }
        )
    return rows


def _scenario_overview_rows(scenarios: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows = []
    for name, data in scenarios.items():
        supported = [row for row in data["chord_metrics"] if row["valid_pixel_count"] > 0]
        rows.append(
            {
                "scenario": name,
                "cost": data["cost"],
                "observation_count": len(supported),
                **{
                    f"mean_{key}": safe_mean(float(row[key]) for row in supported)
                    for key in ("correlation", "nrmse_std", "nrmse_range", "gain")
                },
            }
        )
    return rows


def _metric_values_from_window_row(row: Dict[str, Any], metric: str) -> Tuple[float, float]:
    if metric == "area":
        return abs(float(row["prediction_area"])), abs(float(row["measurement_area"]))
    if metric == "peak":
        return abs(float(row["prediction_peak"])), abs(float(row["measurement_peak"]))
    raise ValueError(f"Unsupported pair metric: {metric}")


def _build_window_classification_rows(
    scenarios: Dict[str, Dict[str, Any]],
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for scenario_name, data in scenarios.items():
        for item in data["window_metrics"]:
            row = dict(item)
            row["scenario"] = scenario_name
            row["window_class"] = classify_window(
                kind=str(row.get("kind", "")),
                use_area=bool(row.get("use_area", True)),
                use_peak=bool(row.get("use_peak", True)),
                area_ratio=float(row.get("area_ratio", 0.0)),
                peak_ratio=float(row.get("peak_ratio", 0.0)),
                abs_peak_shift_nm=abs(float(row.get("peak_shift_nm", 0.0))),
                skipped_low_signal=bool(row.get("low_signal_skipped", False)),
            )
            row["quality_pass"] = row["window_class"] == "good"
            rows.append(row)
    return rows


def _build_pair_classification_rows(
    window_class_rows: List[Dict[str, Any]],
    ratio_pairs: List[Dict[str, Any]],
    ratio_metric_default: str,
    ratio_min_signal_default: float,
) -> List[Dict[str, Any]]:
    grouped: Dict[Tuple[str, str, str], List[Dict[str, Any]]] = {}
    for row in window_class_rows:
        key = (str(row["scenario"]), str(row["instrument_id"]), str(row["chord_key"]))
        grouped.setdefault(key, []).append(row)

    out_rows: List[Dict[str, Any]] = []
    for (scenario, inst_id, chord_key), rows in grouped.items():
        by_window = {str(item["window_name"]): item for item in rows}
        max_signal_by_metric = {
            "area": max((abs(float(item["measurement_area"])) for item in rows), default=0.0),
            "peak": max((abs(float(item["measurement_peak"])) for item in rows), default=0.0),
        }
        for pair_idx, pair in enumerate(ratio_pairs):
            pair_name = str(pair.get("name", f"pair_{pair_idx}"))
            numerator = str(pair["numerator"])
            denominator = str(pair["denominator"])
            metric = str(pair.get("metric", ratio_metric_default))
            min_relative_signal = float(pair.get("min_relative_signal", ratio_min_signal_default))
            if numerator not in by_window or denominator not in by_window:
                continue

            num_row = by_window[numerator]
            den_row = by_window[denominator]
            pred_num, meas_num = _metric_values_from_window_row(num_row, metric)
            pred_den, meas_den = _metric_values_from_window_row(den_row, metric)
            cutoff = max_signal_by_metric.get(metric, 0.0) * max(min_relative_signal, 0.0)
            supported = min(meas_num, meas_den) > cutoff

            log_ratio_error: float | None = None
            pair_class = "ignored_low_signal"
            measured_ratio = ""
            predicted_ratio = ""
            if supported:
                measured_ratio = meas_num / max(meas_den, 1.0e-30)
                if min(pred_num, pred_den) > 0.0:
                    predicted_ratio = pred_num / pred_den
                    log_ratio_error = float(np.log(predicted_ratio) - np.log(measured_ratio))
                    pair_class = classify_pair_log_error(log_ratio_error)
                else:
                    pair_class = "invalid_prediction"

            out_rows.append(
                {
                    "scenario": scenario,
                    "instrument_id": inst_id,
                    "chord_key": chord_key,
                    "measurement_id": str(rows[0].get("measurement_id", "")),
                    "prediction_key": str(rows[0].get("prediction_key", "")),
                    "pair_name": pair_name,
                    "numerator": numerator,
                    "denominator": denominator,
                    "metric": metric,
                    "min_relative_signal": min_relative_signal,
                    "log_ratio_error": log_ratio_error if log_ratio_error is not None else "",
                    "measured_ratio": measured_ratio,
                    "predicted_ratio": predicted_ratio,
                    "pair_class": pair_class,
                    "supported": supported,
                }
            )
    return out_rows


def _build_classification_summary(
    scenarios: Dict[str, Dict[str, Any]],
    ratio_pairs: List[Dict[str, Any]],
    ratio_metric_default: str,
    ratio_min_signal_default: float,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Dict[str, Any]]:
    window_rows = _build_window_classification_rows(scenarios)
    window_accuracy = scenario_accuracy_vs_truth(
        window_rows,
        scenario_field="scenario",
        key_fields=("instrument_id", "chord_key", "window_name"),
        label_field="window_class",
    )
    for row in window_rows:
        row["truth_window_class"] = str(row.get("truth_label", ""))
        row["class_match_truth"] = bool(row.get("class_match_truth", False))
        if "truth_label" in row:
            del row["truth_label"]

    pair_rows = _build_pair_classification_rows(
        window_rows, ratio_pairs, ratio_metric_default, ratio_min_signal_default
    )
    pair_accuracy = scenario_accuracy_vs_truth(
        pair_rows,
        scenario_field="scenario",
        key_fields=("instrument_id", "chord_key", "pair_name"),
        label_field="pair_class",
    )
    for row in pair_rows:
        row["truth_pair_class"] = str(row.get("truth_label", ""))
        row["class_match_truth"] = bool(row.get("class_match_truth", False))
        if "truth_label" in row:
            del row["truth_label"]

    summary = {
        "window_class_accuracy_vs_truth": window_accuracy,
        "window_pass_rate_by_kind": window_pass_rate_by_kind(window_rows),
        "pair_pattern_accuracy_vs_truth": pair_accuracy,
        "pair_support_count": {scenario: int(values["support"]) for scenario, values in pair_accuracy.items()},
        "pair_log_error_tolerance": PAIR_CLASS_LOG_TOL,
        "window_thresholds": WINDOW_CLASS_THRESHOLDS,
    }
    return window_rows, pair_rows, summary


def analyze_one(bench_dir: Path, result_dir_name: str, out_name: str) -> Path:
    """Compare initial/fitted/truth spectra and export one numerical report."""
    bench_dir = bench_dir.resolve()
    result_dir = (bench_dir / "runs" / result_dir_name).resolve()
    out_dir = (result_dir / out_name).resolve()
    result_path, case_opt_path = result_dir / "result.yaml", result_dir / "case_opt.yaml"
    missing = [path.name for path in (result_path, case_opt_path) if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"Missing canonical inverse output in '{result_dir}': {', '.join(missing)}.")
    solver = InverseSolver.from_yaml(bench_dir / "case_init.yaml", bench_dir / "inverse.yaml")
    result_summary = load_fit_result(result_path)
    benchmark_meta = load_yaml(bench_dir / "benchmark_meta.yaml")
    truth_cfg = _load_truth_case(bench_dir / "case_truth.yaml")
    opt_cfg = load_yaml(case_opt_path)
    _validate_result_case_consistency(solver, result_summary, opt_cfg)
    scenarios = {
        name: _scenario_analysis(name, cfg, solver, solver.measurements, solver.windows)
        for name, cfg in (("init", solver.case_cfg), ("opt", opt_cfg), ("truth", truth_cfg))
    }
    objective = solver.inv_cfg.get("fit", {}).get("objective", {})
    window_rows, pair_rows, classification = _build_classification_summary(
        scenarios,
        list(objective.get("window_ratio_pairs", [])),
        str(objective.get("window_ratio_metric", "peak")),
        float(objective.get("window_ratio_min_relative_signal", 0.02)),
    )
    summary = {
        "benchmark_id": str(benchmark_meta.get("benchmark_id", bench_dir.name)),
        "title": str(benchmark_meta.get("title", bench_dir.name)),
        "interpretation": "generated_self_consistency",
        "source_citation": str(benchmark_meta.get("source", {}).get("citation", "")),
        "saved_fit": {"success": bool(result_summary["success"]), "cost": float(result_summary["cost"])},
        "analysis_contract": build_analysis_contract(
            benchmark_id=str(benchmark_meta.get("benchmark_id", bench_dir.name)),
            benchmark_meta=benchmark_meta,
            truth_config=truth_cfg,
            measurements=solver.measurements,
            windows=solver.windows,
            objective=objective,
            metric_definition={
                "window_class_thresholds": WINDOW_CLASS_THRESHOLDS,
                "pair_class_log_tolerance": PAIR_CLASS_LOG_TOL,
            },
        ),
        "run_fingerprint": build_run_fingerprint(
            package_version=__version__,
            case_config=solver.case_cfg,
            inverse_config=solver.inv_cfg,
            result_sha256=file_sha256(result_path),
            parameter_names=solver.params.names(),
        ),
        "scenario_summary": _scenario_overview_rows(scenarios),
        "parameter_recovery": _parameter_rows(solver, truth_cfg, opt_cfg),
        "window_fidelity": aggregate_window_rows(scenarios["opt"]["window_metrics"], ("window_name",)),
        "classification_summary": classification,
    }
    save_yaml(summary, out_dir / "analysis_summary.yaml")
    write_markdown_report(out_dir / "analysis_report.md", summary)
    write_flat_csv(out_dir / "scenario_metrics.csv", summary["scenario_summary"])
    write_flat_csv(out_dir / "parameter_recovery.csv", summary["parameter_recovery"])
    write_flat_csv(out_dir / "chord_metrics.csv", [row for data in scenarios.values() for row in data["chord_metrics"]])
    write_flat_csv(out_dir / "window_metrics.csv", window_rows)
    write_flat_csv(out_dir / "mixed_pattern_metrics.csv", pair_rows)
    write_spectral_comparisons(out_dir / "spectral_comparisons.csv", scenarios)
    for retired in (
        "analysis_dashboard.html",
        "forward_dashboard.html",
        "classification_window_metrics.csv",
        "plots/fit_quality.svg",
        "plots/parameter_recovery.svg",
        "plots/window_fidelity.svg",
        "plots/spectra_overview.svg",
        "plots/forward_quality.svg",
        "plots/forward_window_fidelity.svg",
        "plots/forward_spectra_overview.svg",
    ):
        (out_dir / retired).unlink(missing_ok=True)
    plots = out_dir / "plots"
    if plots.is_dir() and not any(plots.iterdir()):
        plots.rmdir()
    return out_dir
