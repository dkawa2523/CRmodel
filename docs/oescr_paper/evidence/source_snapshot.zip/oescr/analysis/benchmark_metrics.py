"""Pure benchmark metrics with no report-rendering dependencies."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, Dict, Iterable, List, Tuple

import numpy as np


def safe_mean(values: Iterable[float]) -> float:
    seq = [float(value) for value in values]
    return float(sum(seq) / len(seq)) if seq else 0.0


def safe_corr(first: np.ndarray, second: np.ndarray) -> float:
    if len(first) < 2 or len(second) < 2 or np.ptp(first) == 0.0 or np.ptp(second) == 0.0:
        return float(np.array_equal(first, second))
    return float(np.corrcoef(first, second)[0, 1])


def aggregate_window_rows(
    window_entries: List[Dict[str, Any]],
    group_keys: Tuple[str, ...],
) -> List[Dict[str, Any]]:
    grouped: Dict[Tuple[str, ...], List[Dict[str, Any]]] = {}
    for item in window_entries:
        key = tuple(str(item.get(name, "")) for name in group_keys)
        grouped.setdefault(key, []).append(item)

    rows: List[Dict[str, Any]] = []
    for key, items in grouped.items():
        sample = items[0]
        row: Dict[str, Any] = {group_keys[index]: key[index] for index in range(len(group_keys))}
        row.update(
            {
                "kind": str(sample.get("kind", "")),
                "family": str(sample.get("family", "")),
                "mean_area_ratio": safe_mean(float(item["area_ratio"]) for item in items),
                "mean_peak_ratio": safe_mean(float(item["peak_ratio"]) for item in items),
                "mean_abs_peak_shift_nm": safe_mean(abs(float(item["peak_shift_nm"])) for item in items),
                "mean_abs_measurement_area": safe_mean(abs(float(item["measurement_area"])) for item in items),
            }
        )
        rows.append(row)
    return rows


def spectral_relative_l2(
    prediction: Mapping[str, np.ndarray],
    reference: Mapping[str, np.ndarray],
) -> float:
    """Return wavelength-aligned relative L2 error for one spectrum.

    The prediction is interpolated onto the reference grid.  This keeps the
    benchmark metric independent of the forward model's internal grid while
    retaining the absolute spectral scale needed to assess ``ne`` recovery.
    """

    reference_wavelength = np.asarray(reference["wavelength_nm"], dtype=float)
    reference_intensity = np.asarray(reference["intensity"], dtype=float)
    predicted = np.interp(
        reference_wavelength,
        np.asarray(prediction["wavelength_nm"], dtype=float),
        np.asarray(prediction["intensity"], dtype=float),
    )
    numerator = float(np.sum((predicted - reference_intensity) ** 2))
    denominator = float(np.sum(reference_intensity**2))
    return float(np.sqrt(numerator / max(denominator, 1.0e-300)))


def aggregate_spectral_relative_l2(
    predictions: Mapping[str, Mapping[str, np.ndarray]],
    references: Mapping[str, Mapping[str, np.ndarray]],
    spectrum_ids: Sequence[str],
) -> float:
    """Return a sample-weighted relative L2 error over declared spectra."""

    if not spectrum_ids:
        raise ValueError("At least one spectrum is required for spectral evaluation.")
    squared_error = 0.0
    squared_reference = 0.0
    for spectrum_id in spectrum_ids:
        reference = references[spectrum_id]
        reference_wavelength = np.asarray(reference["wavelength_nm"], dtype=float)
        reference_intensity = np.asarray(reference["intensity"], dtype=float)
        prediction = predictions[spectrum_id]
        predicted = np.interp(
            reference_wavelength,
            np.asarray(prediction["wavelength_nm"], dtype=float),
            np.asarray(prediction["intensity"], dtype=float),
        )
        squared_error += float(np.sum((predicted - reference_intensity) ** 2))
        squared_reference += float(np.sum(reference_intensity**2))
    return float(np.sqrt(squared_error / max(squared_reference, 1.0e-300)))
