# Benchmark Analysis: NF3/Ar CCP chamber-clean benchmark (literature-anchored, measurement-like)

- Benchmark ID: nf3_ar_ccp_clean_2023
- Source: An, S.; Hong, S.J., Spectroscopic Analysis of NF3 Plasmas with Oxygen Additive for PECVD Chamber Cleaning, Coatings 13(1), 91 (2023).

## Scenario Summary

| Scenario | Cost | Mean Corr. | Mean NRMSE/std | Mean NRMSE/range | Mean Gain |
| --- | --- | --- | --- | --- | --- |
| init | 225.4610 | 0.9906 | 0.1679 | 0.0117 | 4.0939 |
| opt | 213.9439 | 0.9909 | 0.1554 | 0.0108 | 2.7510 |
| truth | 215.9117 | 0.9911 | 0.1564 | 0.0109 | 1.0405 |

## Instrument View

| Instrument | Min nm | Max nm | Bin nm | Windows | Gain Mean | Gain Min | Gain Max |
| --- | --- | --- | --- | --- | --- | --- | --- |
| nf3_benchmark_uvvis | 300.0000 | 820.0000 | 0.5000 | 7 | 2.7510 | 2.7510 | 2.7510 |

## Parameter Recovery

| Group | Radial Trend | Init Mean Abs Rel Err | Opt Mean Abs Rel Err | Improvement | Mean Rel. Uncertainty |
| --- | --- | --- | --- | --- | --- |
| ne | monotonic decrease from core to edge | 0.1831 | 0.1645 | 0.1015 | 0.4337 |
| te | monotonic decrease from core to edge | 0.1160 | 0.0862 | 0.2570 | 0.1011 |
| F | monotonic decrease from core to edge | 0.1498 | 0.1301 | 0.1313 | 0.4928 |
| N2e | monotonic decrease from core to edge | 0.1628 | 0.1852 | -0.1372 | 0.5682 |

## Window Fidelity

| Window | Kind | Mean Area Ratio | Mean Peak Ratio | Mean Abs Peak Shift nm |
| --- | --- | --- | --- | --- |
| N2_FP_550_700 | broadband_window | -0.9927 | 1.0336 | 0.0000 |
| FI_685_603 | atomic_line | 1.0696 | 1.0752 | 0.0000 |
| FI_703_747 | atomic_line | 1.0776 | 1.0373 | 0.3000 |
| FI_712_789 | atomic_line | 1.0834 | 1.0827 | 0.3000 |
| N2_SPS_300_400 | broadband_window | 1.4247 | 0.5668 | 17.9000 |
| ArI_811_531 | atomic_line | 2.7989 | 1.5590 | 0.4000 |
| ArI_750_387 | atomic_line | 1.256e-13 | 2.002e-14 | 0.6000 |

## Classification Metrics

| Scenario | Window Acc. vs Truth | Window Support | Pair Acc. vs Truth | Pair Support |
| --- | --- | --- | --- | --- |
| init | 0.9545 | 22 | 0.9000 | 10 |
| opt | 1.0000 | 22 | 1.0000 | 10 |
| truth | 1.0000 | 22 | 1.0000 | 10 |

## Plasma OES Interpretation

- Dominant measured features are N2_FP_550_700 (broadband_window, area ratio -0.99), FI_685_603 (atomic_line, area ratio 1.07), FI_703_747 (atomic_line, area ratio 1.08).
- The inverse solution reduces the objective cost by 5.1% relative to the initial state.
- The truth case remains within the same cost basin as the fitted case, so the fit is consistent with the benchmark physics under noise.
- Parameter recovery against the benchmark truth is weak for N2e; spectral agreement is being achieved mainly through shape matching rather than absolute emissivity recovery.
- Recovered radial trends are ne: monotonic decrease from core to edge, te: monotonic decrease from core to edge, F: monotonic decrease from core to edge, N2e: monotonic decrease from core to edge.

## Measurement Engineering Interpretation

- nf3_benchmark_uvvis covers 300.0-820.0 nm with 0.500 nm sampling and uses 7 analysis windows.
- Fitted gain spans 2.751-2.751 with negligible offsets (max abs offset 1.368e-16).
- Mean absolute peak shift across narrow features is 0.320 nm, which is the practical wavelength-alignment indicator for the current inverse workflow.
- Signed window-area ratios can become negative for broad bands when local baseline subtraction dominates the integrated residual; treat those entries as a baseline-sensitivity flag rather than a literal negative emissivity.
- The least constrained fitted quantities are N2e0 (57.6% rel.), N2e2 (57.2% rel.), N2e1 (55.7% rel.), F2 (50.2% rel.).
