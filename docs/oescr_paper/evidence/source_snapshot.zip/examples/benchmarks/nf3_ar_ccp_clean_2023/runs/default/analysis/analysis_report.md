# NF3/Ar CCP chamber-clean benchmark (literature-anchored, measurement-like)

Generated-data self-consistency analysis. These values do not establish experimental accuracy.

Saved optimizer success: True; recorded cost: 158.475. The comparisons below reevaluate saved parameters with current inputs and code; optimization was not rerun.

## Spectral comparison

| scenario | cost | mean_correlation | mean_nrmse_std |
| --- | --- | --- | --- |
| init | 167.108 | 0.990592 | 0.155868 |
| opt | 162.8 | 0.99086 | 0.143794 |
| truth | 163.43 | 0.991029 | 0.142057 |

## Named parameter recovery

| name | role | initial | optimized | truth | optimized_relative_error |
| --- | --- | --- | --- | --- | --- |
| te0 | target | 2.35 | 2.50993 | 2.75 | 0.0872982 |
| te1 | target | 2.05 | 2.15478 | 2.35 | 0.0830725 |
| te2 | target | 1.85 | 1.86386 | 2 | 0.0680703 |
| F0 | target | 6.5e+18 | 6.87734e+18 | 8e+18 | 0.140332 |
| F1 | target | 5e+18 | 5.13612e+18 | 6e+18 | 0.143981 |
| F2 | target | 3.8e+18 | 3.81075e+18 | 4.2e+18 | 0.092678 |
| N2e0 | target | 1.3e+18 | 1.31825e+18 | 1.7e+18 | 0.224559 |
| N2e1 | target | 9e+17 | 8.55093e+17 | 1.1e+18 | 0.222642 |
| N2e2 | target | 6.5e+17 | 6.27298e+17 | 7e+17 | 0.10386 |

Numerical details: [summary](analysis_summary.yaml), [observations](chord_metrics.csv), [windows](window_metrics.csv), [ratios](mixed_pattern_metrics.csv), [spectral comparisons](spectral_comparisons.csv).

Inspect the standard result bundle for fitted spectra, warnings and any explicitly requested audits.
