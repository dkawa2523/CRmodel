# Benchmark Analysis: NF3/Ar CCP chamber-clean benchmark (literature-anchored, measurement-like)

- Benchmark ID: nf3_ar_ccp_clean_2023
- Source: An, S.; Hong, S.J., Spectroscopic Analysis of NF3 Plasmas with Oxygen Additive for PECVD Chamber Cleaning, Coatings 13(1), 91 (2023).

## Scenario Summary

| Scenario | Cost | Mean Corr. | Mean NRMSE/std | Mean NRMSE/range | Mean Gain |
| --- | --- | --- | --- | --- | --- |
| init | 210.7444 | 0.9925 | 0.1561 | 0.0109 | 3.5965 |
| opt | 199.2417 | 0.9928 | 0.1425 | 0.0099 | 2.4952 |
| truth | 200.8951 | 0.9930 | 0.1436 | 0.0100 | 0.9141 |

## Instrument View

| Instrument | Min nm | Max nm | Bin nm | Windows | Gain Mean | Gain Min | Gain Max |
| --- | --- | --- | --- | --- | --- | --- | --- |
| nf3_benchmark_uvvis | 300.0000 | 820.0000 | 0.5000 | 7 | 2.4952 | 2.4952 | 2.4952 |

## Parameter Recovery

| Group | Radial Trend | Init Mean Abs Rel Err | Opt Mean Abs Rel Err | Improvement | Mean Rel. Uncertainty |
| --- | --- | --- | --- | --- | --- |
| te | monotonic decrease from core to edge | 0.1160 | 0.0867 | 0.2530 | 0.0920 |
| F | monotonic decrease from core to edge | 0.1498 | 0.1301 | 0.1316 | 0.4914 |
| N2e | monotonic decrease from core to edge | 0.1628 | 0.1878 | -0.1530 | 0.5672 |

## Window Fidelity

| Window | Kind | Mean Area Ratio | Mean Peak Ratio | Mean Abs Peak Shift nm |
| --- | --- | --- | --- | --- |
| N2_FP_550_700 | broadband_window | -0.9956 | 1.0401 | 0.0000 |
| FI_685_603 | atomic_line | 1.0792 | 1.0851 | 0.0000 |
| FI_703_747 | atomic_line | 1.0722 | 1.0141 | 0.2000 |
| FI_712_789 | atomic_line | 1.0840 | 1.0585 | 0.3000 |
| N2_SPS_300_400 | broadband_window | 1.4942 | 0.5864 | 17.9000 |
| ArI_811_531 | atomic_line | 2.8876 | 1.6078 | 0.4000 |
| ArI_750_387 | atomic_line | 1.459e-13 | 1.809e-14 | 0.6000 |

## Classification Metrics

| Scenario | Window Acc. vs Truth | Window Support | Pair Acc. vs Truth | Pair Support |
| --- | --- | --- | --- | --- |
| init | 0.9545 | 22 | 0.9000 | 10 |
| opt | 0.9545 | 22 | 1.0000 | 10 |
| truth | 1.0000 | 22 | 1.0000 | 10 |

## Plasma OES Interpretation

- Dominant measured features are N2_FP_550_700 (broadband_window, area ratio -1.00), FI_685_603 (atomic_line, area ratio 1.08), FI_703_747 (atomic_line, area ratio 1.07).
- The inverse solution reduces the objective cost by 5.5% relative to the initial state.
- The truth case remains within the same cost basin as the fitted case, so the fit is consistent with the benchmark physics under noise.
- Parameter recovery against the benchmark truth is weak for N2e; spectral agreement is being achieved mainly through shape matching rather than absolute emissivity recovery.
- Recovered radial trends are te: monotonic decrease from core to edge, F: monotonic decrease from core to edge, N2e: monotonic decrease from core to edge.

## Measurement Engineering Interpretation

- nf3_benchmark_uvvis covers 300.0-820.0 nm with 0.500 nm sampling and uses 7 analysis windows.
- Fitted gain spans 2.495-2.495 with negligible offsets (max abs offset 1.127e-16).
- Mean absolute peak shift across narrow features is 0.300 nm, which is the practical wavelength-alignment indicator for the current inverse workflow.
- Signed window-area ratios can become negative for broad bands when local baseline subtraction dominates the integrated residual; treat those entries as a baseline-sensitivity flag rather than a literal negative emissivity.
- The least constrained fitted quantities are N2e0 (57.5% rel.), N2e2 (57.1% rel.), N2e1 (55.5% rel.), F2 (50.2% rel.).
