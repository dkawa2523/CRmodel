# Ar six-kernel candidate vertical slice

## Status and claim boundary

This benchmark is an implemented **synthetic recovery slice** for the real
forward/inverse path. It is not external validation of an Ar collisional-
radiative model and it does not qualify an experimental electron temperature.
All six excitation kernels carry `validation_candidate` evidence, and the
measurement files are deterministic same-model fixtures.

The permitted result is recovery of one shared **Maxwellian effective electron
temperature** (`Te`). Electron density (`ne`) is fixed at the case input and is
not estimated. The exported Maxwellian EEDF is derived from fitted `Te`; it is
not an independently reconstructed EEDF.

## Benchmark contract

| Dimension | Contract |
|---|---|
| Plasma case | One pure-Ar condition, one shell, `plasma_mode: te` |
| Candidate kernels | Six distinct direct-ground upper-state kernels: `Ar_2p10`, `Ar_2p9`, `Ar_2p8`, `Ar_2p7`, `Ar_2p6`, and `Ar_2p1` |
| Atomic branches | 17 pinned NIST ASD branches in the species pack; 16 fall inside the two instrument ranges, while `Ar_2p10_1148` is outside |
| Spectral channels | `vis_650_850` and `nir_840_1050`, with an overlapping 840--850 nm region |
| Repeats | Three deterministic perturbations per channel, for six spectrum observations |
| Shared target | One Maxwellian effective `Te` shared by both channels and all repeats |
| Fixed quantity | `ne = 2.0e16 m^-3`; it is not an inverse parameter |
| EEDF | Maxwellian distribution derived from fitted `Te` |
| Objective | Relative spectral shape with instrument-scoped gain; only `analysis_role: fit` windows enter the fit |
| Kernel roles | Five distinct kernels enter fit windows; `Ar_2p10` is held out as the sixth distinct kernel |
| Checks | Same-kernel branch score windows and the `Ar_2p10` distinct-upper-state holdout remain outside the objective |

The truth fixture uses `Te = 4.0 eV`; the deliberately displaced initial case
uses `Te = 2.5 eV`. The six direct-excitation cross sections are pinned by the
external-bundle manifest, while wavelengths and A values are pinned by the
atomic-branch artifact. Those provenance controls make the fixture auditable;
they do not promote the kernels from candidate to qualified evidence.

Each cross-section table also declares its physical excitation threshold and
`lower_extrapolation: zero_below_threshold`. The loader verifies that the
threshold is the first tabulated energy and that its cross section is zero.
Consequently, the large Maxwellian probability below an excitation threshold
is treated as a known-zero rate contribution rather than falsely reported as
missing data; support above the last tabulated energy remains uncovered.

## Run

From the repository root:

```powershell
python -m pip install -e ".[dev]"
python scripts/run_argon_six_kernel_candidate.py
```

The default output directory is
`.local_outputs/ar_six_kernel_candidate`. To keep a separate run:

```powershell
python scripts/run_argon_six_kernel_candidate.py --out .local_outputs/ar_six_kernel_candidate_review
```

The focused contract checks can be run with:

```powershell
python -m pytest -q tests/test_argon_six_kernel_candidate.py
```

## Outputs

The runner writes:

- `observation_packages/<observation-id>/`: six one-observation package
  manifests, calibrated-source fixtures, canonical spectra, and transformation
  provenance. The same adapter boundary used for an external calibrated CSV is
  exercised here; the sources remain generated contract fixtures;
- `measurement_set.yaml`: the six rebased canonical observation entries used
  by the shared-state inverse run;
- `inverse_config.yaml`: the generated six-observation inverse configuration,
  including canonical observation identities and the synthetic response
  artifact hash;
- `result.yaml`, `case_opt.yaml`, and `spectra/*.csv`: the compact canonical
  inverse result, optimized case, and one measured/predicted residual table per
  observation;
- `fit_summary.yaml`: fitted `Te`, recovery error, held-out score metrics,
  optimizer status, measurement-only identifiability, and the focused `Te`
  profile;
- `claim.yaml`: the permitted estimand, fixed-`ne` and derived-EEDF labels, and
  the blockers that force external-validation abstention;
- `kernel_inventory.yaml`: compiled kernel identities and evidence counts;
- `kernel_sensitivity.yaml`: truth-point rate coefficients and
  `d log(k) / d log(Te)` for each candidate kernel, so distinct state identity
  is not confused with numerical sensitivity independence;
- `audit_spectra/*.csv`: measured, initial, and optimized spectra with fit/score
  masks for every repeat;
- `derived_maxwellian_eedf.csv`: the Maxwellian EEDF calculated from fitted
  `Te`, explicitly labeled as derived rather than reconstructed;
- `optimization_trace.csv`: local objective evaluations and their trial `Te`;
- `temperature_profile.csv`: the exported measurement-only conditional `Te`
  profile, including configured-grid and inserted-reference point sources;
- `figures/benchmark_overview.png` and `.svg`: representative channel overlays,
  the conditional `Te` profile, and the optimization history.

Generated files are local evidence and are not source measurement data.

## Interpretation

`software_recovery_pass: true` means that the inverse path recovered the
same-model Maxwellian `Te` and met the runner's held-out residual gate. It
checks compilation, multi-observation binding, shared-state fitting, window
separation, nuisance handling, identifiability/profile export, and result
semantics.

Read the current recovery error and score RMSE from the generated
`fit_summary.yaml`; they describe same-model software recovery.
The runner exits with status 1 when the software recovery checks fail.
`result.yaml` is the stable inverse result;
`fit_summary.yaml` adds benchmark-specific truth-recovery and held-out metrics.

The score breakdown must be read by kernel role. A held-out branch from an
upper state already used in the fit is a consistency check, not a new
excitation-kernel validation. The `Ar_2p10` windows are the distinct-upper-state
holdout. Numerical rank and a closed synthetic profile describe this fixture;
they do not establish experimental accuracy. The exported profile's
measurement-objective difference is descriptive and is not a calibrated
confidence interval.

At the 4.0 eV fixture truth, the six log-rate sensitivities span roughly
2.85--4.01. This confirms that the imported curves are not merely six copies
of one rate shape, but it does not prove experimental independence; the
measurement Jacobian, instrument response, nuisance treatment, and external
model discrepancy still determine usable information.

External validation would require agreement with calibrated measured spectra
and an independent, time- and space-matched `Te` reference under a physically
closed or explicitly sensitivity-bounded Ar model. The benchmark therefore
keeps `scientific_status: abstain_external_validation` even when software
recovery passes.

## Limitations

- The forward model generates the spectra later used by the inverse model, so
  there is no model-form independence.
- `synthetic_response_artifact.yaml` is deterministic and not a traceable
  instrument calibration.
- Only direct ground-state excitation is represented. Metastable-assisted
  stepwise excitation, cascade, neutral-gas quenching, and radiation trapping
  are not closed.
- The cross sections are candidate inputs, not an independently qualified Ar
  kernel set.
- One condition and one shell do not establish an operating range or spatial
  validity.
- Fixed `ne` prevents any electron-density recovery claim, and a
  one-parameter Maxwellian fit cannot reconstruct an arbitrary EEDF.

## Next step

Replace the deterministic observations with one real, calibrated broad-
spectrum package covering the same shared condition and attach an independent,
co-located `Te` reference. Re-run the focused profile and held-out checks on
that artifact, then evaluate metastable-assisted excitation, cascade,
quenching, and trapping as explicit model/scenario uncertainties. Scientific
qualification remains open until those checks support it; synthetic recovery
alone is not sufficient.
