# Benchmark Analysis: Cl2/Ar ICP actinometry benchmark (literature-anchored, measurement-like)

- Benchmark ID: cl2_ar_icp_fuller2001
- Source: Fuller, N.C.M.; Herman, I.P.; Donnelly, V.M., Optical actinometry of Cl2, Cl, Cl+, and Ar+ densities in inductively coupled Cl2-Ar plasmas, J. Appl. Phys. 90, 3182-3191 (2001).

## Scenario Summary

| Scenario | Cost | Mean Corr. | Mean NRMSE/std | Mean NRMSE/range | Mean Gain |
| --- | --- | --- | --- | --- | --- |
| init | 349.3539 | 0.9875 | 0.2030 | 0.0066 | 1.0018 |
| opt | 348.0884 | 0.9875 | 0.2025 | 0.0066 | 1.0009 |
| truth | 352.2390 | 0.9875 | 0.2038 | 0.0066 | 0.8269 |

## Instrument View

| Instrument | Min nm | Max nm | Bin nm | Windows | Gain Mean | Gain Min | Gain Max |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cl2_benchmark_scan | 270.0000 | 885.0000 | 0.2000 | 6 | 1.0009 | 1.0009 | 1.0009 |

## Parameter Recovery

| Group | Radial Trend | Init Mean Abs Rel Err | Opt Mean Abs Rel Err | Improvement | Mean Rel. Uncertainty |
| --- | --- | --- | --- | --- | --- |
| Cl | monotonic decrease from core to edge | 0.1899 | 0.0587 | 0.6909 | 0.3944 |
| Cl2e | monotonic decrease from core to edge | 0.1349 | 0.1121 | 0.1691 | 0.4793 |

## Window Fidelity

| Window | Kind | Mean Area Ratio | Mean Peak Ratio | Mean Abs Peak Shift nm |
| --- | --- | --- | --- | --- |
| ClII_481_986 | ionic_line | 1.0443 | 1.0517 | 0.0000 |
| ArII_480_602 | ionic_line | 0.9822 | 1.0292 | 0.0000 |
| ClI_822_200_interference | atomic_line_with_interference | 1.1043 | 1.1430 | 0.0000 |
| XeI_828_012 | actinometer_line | 1.1941 | 1.2144 | 0.0000 |
| Cl2_band_306 | molecular_band | 1.2060 | 0.4144 | 2.5200 |
| ArI_750_387 | atomic_line | 4.665e-13 | 5.222e-13 | 0.4400 |

## Classification Metrics

| Scenario | Window Acc. vs Truth | Window Support | Pair Acc. vs Truth | Pair Support |
| --- | --- | --- | --- | --- |
| init | 0.9545 | 22 | 0.6667 | 15 |
| opt | 0.9545 | 22 | 0.8667 | 15 |
| truth | 1.0000 | 22 | 1.0000 | 15 |

## Plasma OES Interpretation

- Dominant measured features are ClII_481_986 (ionic_line, area ratio 1.04), ArII_480_602 (ionic_line, area ratio 0.98), ClI_822_200_interference (atomic_line_with_interference, area ratio 1.10).
- The inverse solution reduces the objective cost by 0.4% relative to the initial state.
- The truth case remains within the same cost basin as the fitted case, so the fit is consistent with the benchmark physics under noise.
- Recovered radial trends are Cl: monotonic decrease from core to edge, Cl2e: monotonic decrease from core to edge.

## Measurement Engineering Interpretation

- cl2_benchmark_scan covers 270.0-885.0 nm with 0.200 nm sampling and uses 6 analysis windows.
- Fitted gain spans 1.001-1.001 with negligible offsets (max abs offset 3.680e-16).
- Mean absolute peak shift across narrow features is 0.088 nm, which is the practical wavelength-alignment indicator for the current inverse workflow.
- The least constrained fitted quantities are Cl2e0 (49.2% rel.), Cl2e2 (49.1% rel.), Cl2e1 (45.5% rel.), Cl2 (37.2% rel.).
