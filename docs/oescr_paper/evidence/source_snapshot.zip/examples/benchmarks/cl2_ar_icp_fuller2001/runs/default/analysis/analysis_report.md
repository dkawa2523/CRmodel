# Cl2/Ar ICP actinometry benchmark (literature-anchored, measurement-like)

Generated-data self-consistency analysis. These values do not establish experimental accuracy.

Saved optimizer success: True; recorded cost: 34.5747. The comparisons below reevaluate saved parameters with current inputs and code; optimization was not rerun.

## Spectral comparison

| scenario | cost | mean_correlation | mean_nrmse_std |
| --- | --- | --- | --- |
| init | 52.6741 | 0.984214 | 0.18332 |
| opt | 52.6599 | 0.984232 | 0.183887 |
| truth | 53.379 | 0.98423 | 0.181464 |

## Named parameter recovery

| name | role | initial | optimized | truth | optimized_relative_error |
| --- | --- | --- | --- | --- | --- |
| Cl0 | target | 1.4e+19 | 1.44111e+19 | 1.8e+19 | 0.199383 |
| Cl1 | target | 1.1e+19 | 1.14916e+19 | 1.4e+19 | 0.179173 |
| Cl2 | target | 7.8e+18 | 8.06935e+18 | 9e+18 | 0.103406 |
| Cl2e0 | target | 7.5e+18 | 7.57551e+18 | 9e+18 | 0.158276 |
| Cl2e1 | target | 5.8e+18 | 5.99814e+18 | 7e+18 | 0.143122 |
| Cl2e2 | target | 4.2e+18 | 4.27772e+18 | 4.5e+18 | 0.0493958 |

Numerical details: [summary](analysis_summary.yaml), [observations](chord_metrics.csv), [windows](window_metrics.csv), [ratios](mixed_pattern_metrics.csv), [spectral comparisons](spectral_comparisons.csv).

Inspect the standard result bundle for fitted spectra, warnings and any explicitly requested audits.
