# Benchmark Analysis: Cl2/Ar ICP actinometry benchmark (literature-anchored, measurement-like)

- Benchmark ID: cl2_ar_icp_fuller2001
- Source: Fuller, N.C.M.; Herman, I.P.; Donnelly, V.M., Optical actinometry of Cl2, Cl, Cl+, and Ar+ densities in inductively coupled Cl2-Ar plasmas, J. Appl. Phys. 90, 3182-3191 (2001).

## Scenario Summary

| Scenario | Cost | Mean Corr. | Mean NRMSE/std | Mean NRMSE/range | Mean Gain |
| --- | --- | --- | --- | --- | --- |
| init | 403.4587 | 0.9840 | 0.2195 | 0.0071 | 1.1358 |
| opt | 402.1976 | 0.9841 | 0.2191 | 0.0071 | 1.1351 |
| truth | 407.5772 | 0.9840 | 0.2202 | 0.0071 | 0.9375 |

## Instrument View

| Instrument | Min nm | Max nm | Bin nm | Windows | Gain Mean | Gain Min | Gain Max |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cl2_benchmark_scan | 270.0000 | 885.0000 | 0.2000 | 6 | 1.1351 | 1.1351 | 1.1351 |

## Parameter Recovery

| Group | Radial Trend | Init Mean Abs Rel Err | Opt Mean Abs Rel Err | Improvement | Mean Rel. Uncertainty |
| --- | --- | --- | --- | --- | --- |
| ne | monotonic decrease from core to edge | 0.1670 | 0.1670 | 3.175e-05 | 0.3983 |
| te | monotonic decrease from core to edge | 0.0891 | 0.0891 | -4.948e-05 | 0.1401 |
| Cl | monotonic decrease from core to edge | 0.1899 | 0.0810 | 0.5735 | 0.4021 |
| Cl2e | monotonic decrease from core to edge | 0.1349 | 0.1086 | 0.1953 | 0.4800 |

## Window Fidelity

| Window | Kind | Mean Area Ratio | Mean Peak Ratio | Mean Abs Peak Shift nm |
| --- | --- | --- | --- | --- |
| ClII_481_986 | ionic_line | 1.0552 | 1.0548 | 0.0000 |
| ArII_480_602 | ionic_line | 0.9621 | 1.0244 | 0.0000 |
| ClI_822_200_interference | atomic_line_with_interference | 1.0742 | 1.1148 | 0.0000 |
| XeI_828_012 | actinometer_line | 1.1811 | 1.2126 | 0.0000 |
| Cl2_band_306 | molecular_band | 1.2027 | 0.4131 | 2.5200 |
| ArI_750_387 | atomic_line | 4.700e-13 | 5.360e-13 | 0.4400 |

## Classification Metrics

| Scenario | Window Acc. vs Truth | Window Support | Pair Acc. vs Truth | Pair Support |
| --- | --- | --- | --- | --- |
| init | 0.9545 | 22 | 0.6667 | 15 |
| opt | 0.9545 | 22 | 0.8667 | 15 |
| truth | 1.0000 | 22 | 1.0000 | 15 |

## Plasma OES Interpretation

- Dominant measured features are ClII_481_986 (ionic_line, area ratio 1.06), ArII_480_602 (ionic_line, area ratio 0.96), ClI_822_200_interference (atomic_line_with_interference, area ratio 1.07).
- The inverse solution reduces the objective cost by 0.3% relative to the initial state.
- The truth case remains within the same cost basin as the fitted case, so the fit is consistent with the benchmark physics under noise.
- Parameter recovery against the benchmark truth is weak for ne, te; spectral agreement is being achieved mainly through shape matching rather than absolute emissivity recovery.
- Recovered radial trends are ne: monotonic decrease from core to edge, te: monotonic decrease from core to edge, Cl: monotonic decrease from core to edge, Cl2e: monotonic decrease from core to edge.

## Measurement Engineering Interpretation

- cl2_benchmark_scan covers 270.0-885.0 nm with 0.200 nm sampling and uses 6 analysis windows.
- Fitted gain spans 1.135-1.135 with negligible offsets (max abs offset 4.725e-16).
- Mean absolute peak shift across narrow features is 0.088 nm, which is the practical wavelength-alignment indicator for the current inverse workflow.
- The least constrained fitted quantities are Cl2e0 (49.2% rel.), Cl2e2 (49.2% rel.), Cl2e1 (45.6% rel.), ne2 (43.5% rel.).
