# Benchmark Analysis: Cl2/Ar ICP actinometry benchmark (literature-anchored, measurement-like)

- Benchmark ID: cl2_ar_icp_fuller2001
- Source: Fuller, N.C.M.; Herman, I.P.; Donnelly, V.M., Optical actinometry of Cl2, Cl, Cl+, and Ar+ densities in inductively coupled Cl2-Ar plasmas, J. Appl. Phys. 90, 3182-3191 (2001).

## Scenario Summary

| Scenario | Cost | Mean Corr. | Mean NRMSE/std | Mean NRMSE/range | Mean Gain |
| --- | --- | --- | --- | --- | --- |
| init | 402.7300 | 0.9840 | 0.2215 | 0.0072 | 1.1694 |
| opt | 402.1611 | 0.9841 | 0.2192 | 0.0071 | 1.1449 |
| truth | 404.9594 | 0.9840 | 0.2256 | 0.0073 | 0.9883 |

## Instrument View

| Instrument | Min nm | Max nm | Bin nm | Windows | Gain Mean | Gain Min | Gain Max |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cl2_benchmark_scan | 270.0000 | 885.0000 | 0.2000 | 6 | 1.1449 | 1.1449 | 1.1449 |

## Parameter Recovery

| Group | Radial Trend | Init Mean Abs Rel Err | Opt Mean Abs Rel Err | Improvement | Mean Rel. Uncertainty |
| --- | --- | --- | --- | --- | --- |
| ne | monotonic decrease from core to edge | 0.1670 | 0.1670 | 3.172e-05 | 0.3983 |
| te | monotonic decrease from core to edge | 0.0891 | 0.0891 | -4.948e-05 | 0.1401 |
| Cl | monotonic decrease from core to edge | 0.1899 | 0.0583 | 0.6932 | 0.3959 |
| Cl2e | monotonic decrease from core to edge | 0.1349 | 0.1057 | 0.2165 | 0.4814 |

## Window Fidelity

| Window | Kind | Mean Area Ratio | Mean Peak Ratio | Mean Abs Peak Shift nm |
| --- | --- | --- | --- | --- |
| ClII_481_986 | ionic_line | 1.0643 | 1.0639 | 0.0000 |
| ArII_480_602 | ionic_line | 0.9704 | 1.0332 | 0.0000 |
| ClI_822_200_interference | atomic_line_with_interference | 1.1081 | 1.1508 | 0.0000 |
| XeI_828_012 | actinometer_line | 1.1913 | 1.2231 | 0.0000 |
| Cl2_band_306 | molecular_band | 1.2170 | 0.4181 | 2.5200 |
| ArI_750_387 | atomic_line | 4.718e-13 | 5.392e-13 | 0.4400 |

## Classification Metrics

| Scenario | Window Acc. vs Truth | Window Support | Pair Acc. vs Truth | Pair Support |
| --- | --- | --- | --- | --- |
| init | 0.8636 | 22 | 0.6000 | 20 |
| opt | 0.9091 | 22 | 0.7500 | 20 |
| truth | 1.0000 | 22 | 1.0000 | 20 |

## Plasma OES Interpretation

- Dominant measured features are ClII_481_986 (ionic_line, area ratio 1.06), ArII_480_602 (ionic_line, area ratio 0.97), ClI_822_200_interference (atomic_line_with_interference, area ratio 1.11).
- The inverse solution reduces the objective cost by 0.1% relative to the initial state.
- The truth case remains within the same cost basin as the fitted case, so the fit is consistent with the benchmark physics under noise.
- Parameter recovery against the benchmark truth is weak for ne, te; spectral agreement is being achieved mainly through shape matching rather than absolute emissivity recovery.
- Recovered radial trends are ne: monotonic decrease from core to edge, te: monotonic decrease from core to edge, Cl: monotonic decrease from core to edge, Cl2e: monotonic decrease from core to edge.

## Measurement Engineering Interpretation

- cl2_benchmark_scan covers 270.0-885.0 nm with 0.200 nm sampling and uses 6 analysis windows.
- Fitted gain spans 1.145-1.145 with negligible offsets (max abs offset 4.685e-17).
- Mean absolute peak shift across narrow features is 0.088 nm, which is the practical wavelength-alignment indicator for the current inverse workflow.
- The least constrained fitted quantities are Cl2e0 (49.4% rel.), Cl2e2 (49.3% rel.), Cl2e1 (45.8% rel.), ne2 (43.5% rel.).
