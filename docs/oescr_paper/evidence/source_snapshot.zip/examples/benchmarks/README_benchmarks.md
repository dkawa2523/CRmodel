# 生成ベンチマーク

これらは数値計算と利用経路を確認する生成データです。文献を運転条件や線の
位置の参考にしていても、独立した実験精度の証拠ではありません。

| 例 | 確認する内容 |
|---|---|
| physical_band_analytic | 解析的な放射量・CRの保存則 |
| common_state_ar_o2、common_state_ar_cl2 | 狭帯域の複数観測に共通するTe/ne |
| ar_six_kernel_candidate | 二広帯域channel、六kernel、共有Te、packageから標準結果まで |
| nf3_ar_ccp_clean_2023、cl2_ar_icp_fuller2001 | 五視線と既存のrelative-shape workflow |

```bash
python scripts/run_common_state_benchmarks.py --out .local_outputs/common_state
python scripts/run_argon_six_kernel_candidate.py --out .local_outputs/ar_candidate
python scripts/run_project.py examples/benchmarks/nf3_ar_ccp_clean_2023/project.yaml --out .local_outputs/nf3
```

measurements/とforward_truth/は固定fixtureです。通常実行で書き換えません。
保守時だけbuild_benchmark_measurements.py、またはcommon-state runnerの
--generate-fixturesを明示し、validation.yamlのhashも更新します。
結果はresult.yaml、case_opt.yaml、spectra/へ保存します。

NF3/Ar・Cl2/Arの追加レポートが必要な場合だけanalyze_benchmark_results.pyを使います。
analyzerの出力はCSV・YAMLと短いMarkdownです。独自SVG/HTML dashboardは廃止しました。
分析結果を比較するときは同じ入力・指標のanalysis_contract v2で比較し、古いsummaryを
新しい物理モデルの結果として再利用しません。

専用のseed sweep、旧図版generatorと修正前の報告値は整理しました。
現在の適用範囲は[科学的検証](../../docs/scientific_validation.md)、
次の作業は[開発計画](../../docs/development_plan.md)を参照してください。
