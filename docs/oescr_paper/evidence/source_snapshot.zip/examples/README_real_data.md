# Curated real-dataized Ar / NF3 / Cl2 update

This revision adds three main upgrades:

1. **Curated cross-section CSVs** under `examples/data/cross_sections_curated/`
   - `Ar/`: effective excitation seeds for the Ar 750.4 nm and 763.5 nm CR branches, including stepwise seeds from Ar(1s5).
   - `NF3/`: literature-anchored smooth fits for total ionization, dominant attachment, two dissociation surrogates, and effective F-line emitters.
   - `Cl2/`: literature-anchored or evaluated smooth fits for total ionization, attachment, and total dissociation; the effective visible Cl-line emitters are illustrative synthetic fixtures, not state-resolved cross sections.

2. **Improved inverse objective**
   - full-spectrum residual
   - per-window shape fitting (`window_fit_weight`)
   - baseline-corrected line area residuals
   - baseline-corrected peak residuals
   - optional per-window normalization (`area`, `peak`, `l2`, or `none`)

3. **Inverse-owned wavelength selection**
   - inverse configurations declare `window_selection.mode` and may filter a shared registry by `families`; forward cases remain independent of fitting policy.

## Important interpretation

These CSVs are **not verbatim LXCat redistribution bundles**. They intentionally mix evidence levels: some are literature-anchored smooth fits, while explicitly marked effective emitters are illustrative synthetic fixtures. The per-curve metadata and `cross_sections_curated/manifest.yaml` are authoritative. The collection supports forward-model wiring, sensitivity analysis, and first-pass synthetic inverse studies while keeping provenance explicit; illustrative curves are not eligible for quantitative physical fitting.

Use these curves for:
- initializing model structure,
- building synthetic studies,
- checking identifiability,
- bootstrapping inverse problems before a project-specific preferred dataset is imported.

Replace them with project-approved exports or digitized reference curves when you freeze a production workflow.

## New objective keys

```yaml
fit:
  objective:
    spectrum_weight: 1.0
    window_fit_weight: 0.2
    window_fit_normalization: area   # area | peak | l2 | none
    window_baseline_mode: local_linear
    area_weight: 0.35
    peak_weight: 0.05
```

## New curated cases

- `examples/case_skeleton_nf3_ar.yaml`
- `examples/case_skeleton_cl2_ar.yaml`

Both point at the curated CSVs. Their matching benchmark inverse files select
the relevant window families explicitly; the forward skeletons contain no fit
or score policy.

These root-level skeletons are forward-model starting points only. Use the
corresponding directories under `examples/benchmarks/` for inverse examples;
those packages own their measurement files, identifiable parameter sets, and
validation contracts. The former root-level curated inverse files were removed
to avoid maintaining a second, less explicit inverse workflow.


## Explicit benchmark additions

The curated NF3/Ar and Cl2/Ar examples are now complemented by explicit benchmark directories in `examples/benchmarks/`.
These are not raw redistributed experimental spectra. They are literature-anchored, measurement-like cases intended for repeatable forward/inverse testing.
Use them when you want a named benchmark with documented process conditions instead of only a generic curated example.
