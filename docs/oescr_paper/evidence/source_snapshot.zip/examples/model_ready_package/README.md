# Calibrated-CSV package contract fixture

This directory demonstrates the narrow boundary between an external,
already-calibrated OES export and OESCR's canonical measurement input. It is a
format and provenance fixture, not experimental validation data.

Run one observation from the repository root:

```powershell
python scripts/package_model_ready_oes.py examples/model_ready_package/package_manifest.yaml
```

The manifest pins the source and calibration-artifact hashes, maps external
column and QC names, and writes `generated/spectrum.csv`,
`generated/measurement.yaml`, and `generated/provenance.yaml`. Numeric samples
are not resampled, smoothed, normalized, or calibrated by this adapter.

For a shared-state fit, create one manifest per channel/view/repeat and compose
their outputs directly:

```powershell
python scripts/package_model_ready_oes.py `
  run/channel_a_rep_0/package_manifest.yaml `
  run/channel_b_rep_0/package_manifest.yaml `
  --measurement-set run/measurement_set.yaml
```

The resulting file uses the existing `measurements` contract. Composition only
rebases file paths, preserves each explicit observation identity, rejects
duplicate IDs, and concatenates the entries. The inverse layer remains the
owner of the one-condition/shared-state rule and all fit/score window choices.

`scripts/run_argon_six_kernel_candidate.py` is the executable end-to-end
contract example: two generated calibrated-source channels with three repeats
each pass through this same package boundary before one shared Maxwellian
effective electron temperature is fitted. Its scientific status remains
synthetic recovery only.

For the smallest ordinary project workflow, see
[`../model_ready_project`](../model_ready_project/README.md). It composes the
generated `measurement_set.yaml`, includes that fragment from a normal inverse
file, validates the project, and writes the standard inverse result without a
second runner or configuration format.
