# Model-ready package to one normal project fit

This synthetic example exercises the complete input boundary without adding a
second workflow. The package adapter verifies and records the calibrated CSV
and calibration artifact. Its ordinary measurement fragment is included by
the inverse configuration, and the existing project commands own validation
and fitting.

From the repository root:

```powershell
python scripts/package_model_ready_oes.py examples/model_ready_project/package_manifest.yaml `
  --measurement-set examples/model_ready_project/generated/measurement_set.yaml
python scripts/validate_project.py examples/model_ready_project/project.yaml
python scripts/run_project.py examples/model_ready_project/project.yaml --task inverse
```

The normal result is written to `examples/model_ready_project/run/result.yaml`.
The fitted electron density should recover approximately `3.0e16 m-3` from an
initial value of `1.0e16 m-3`.

The files have deliberately separate owners:

- `package_manifest.yaml` owns external-file hashes, column/QC mapping, and
  provenance outputs.
- `generated/measurement_set.yaml` is generated numerical input and contains no
  optimizer or physics policy.
- `inverse.yaml` owns the inference mode, fitted parameters, and measurement
  inclusion. Full-spectrum fitting is the default; a window registry is only
  needed when an explicit physical-fit subset is intended.
- `project.yaml` selects the case, inverse configuration, and result location.

The spectra are generated analytic fixture data. Passing this example proves
package-to-fit wiring and numerical recovery, not experimental validation.
