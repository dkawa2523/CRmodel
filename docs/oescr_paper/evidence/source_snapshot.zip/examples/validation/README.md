# External-source inventory

These folders preserve independently sourced inputs, acquisition notes and
candidate comparators. Availability alone is not validation. See the current
[validation status](../../docs/scientific_validation.md) and the single
[development plan](../../docs/development_plan.md).

- [Schuecke N2/O2 UV](schuecke_2025_no_uv/README.md): model-input closure remains
  open because the dominant N2(A) source density is not independently known.
- [Arellano Ar-CCP ratios](arellano_2023_ar_ccp/README.md): response-corrected
  Ar 763.5/750.4 nm observations and conditional corona-limit comparisons.
  Independent EEDF, pressure-applicable cascade and metastable/trapping inputs
  remain unresolved. Model spread is not a calibrated uncertainty distribution.
- [External EEDF/rate template](external_eedf_rate_template/README.md): frozen
  independent-tool output can be compared with the public tabulated-EEDF/rate
  path. The template itself provides infrastructure, not physical validation.

`benchmark_portfolio.yaml` is a deferred source inventory. It retains source
identities, artifact hashes, acquisition snapshots and possible comparison
scopes. Proposed condition grids are candidate designs; they do not prescribe
implementation priorities or claim that data have been acquired or qualified.

A qualifying package needs immutable measurements, their calibration and
uncertainty, closed required model inputs, evaluation-only held-out data and a
versioned comparator. The evidence audit verifies eligibility and artifacts;
the comparator must separately demonstrate agreement within its stated scope.

The BOLSIG+ preparation and Daly surrogate producer scripts remain available
for explicitly requested external work. They run outside the OESCR physics
package. BOLSIG+ binaries, licensed collision downloads and the model-compatible
TensorFlow environment remain external inputs. Surrogate-generated spectra do
not substitute for measured spectra or independent Te/ne/EEDF references.
