# Argon 4p excitation candidates

This directory contains six ground-state electron-impact excitation curves
selected from Anthony Schmalzried's Zenodo dataset, *Bolsig+ format cross
section of e-N2, O2, NO, Ar, O, N*, version 1 (2023),
<https://doi.org/10.5281/zenodo.8192503>, licensed CC BY 4.0.

The upstream `Cross section.txt` artifact was retrieved on 2026-10-04 and
verified before extraction:

- Zenodo record: `8192503`
- upstream MD5: `c0c1073f5ea940568ce4925b8b242e1a`
- upstream SHA-256: `a203418d62b3ff62d34f0d1d8ad670df27058bd62bb7d88a8f1405a6bdfa1c1b`
- transformation: select the exact LXCat-style process block, preserve every
  numeric row, write canonical `energy_eV,sigma_m2` CSV, add explicit
  `threshold_eV` and `zero_below_threshold` evaluation metadata, and normalize
  line endings to LF; no interpolation or smoothing

| file | selected Ar-excitation ordinal | exact target label | curve-data SHA-256 |
|---|---:|---|---|
| `xs_ar_excitation_10_zenodo.csv` | 10 | `Ar -> Ar*((4p)[1/2]1)` | `0106c18211ebef1bbfc7bc1ecc3c44398e3c3fad3b693d21d1cb7aeb9fb8473b` |
| `xs_ar_excitation_11_zenodo.csv` | 11 | `Ar -> Ar*((4p)[5/2]3D3)` | `40a3d4ec72082ac6c70d093e487ebcb22632a545a8f532c3352ab660449c9a13` |
| `xs_ar_excitation_12_zenodo.csv` | 12 | `Ar -> Ar*((4p)[5/2]2)` | `70d419c93b88188d722460fc9244a938fb8e31ae41cb7fb61b95cb188180fec8` |
| `xs_ar_excitation_13_zenodo.csv` | 13 | `Ar -> Ar*((4p)[3/2]1)` | `48c9b1f4170770c9d95a5270ce877ae523d11cb97ea032dce967325538db066e` |
| `xs_ar_excitation_14_zenodo.csv` | 14 | `Ar -> Ar*((4p)[3/2]2)` | `60ccab65a58f3cdfa6e53a006b1320261764d711aa00005a2cd21f8c1646a16e` |
| `xs_ar_excitation_18_zenodo.csv` | 18 | `Ar -> Ar*((4p')[1/2]0)` | `1f2047ac9b5d88fbe1a77cdb6676691cc336f9cdece460881d8283366c59a0ca` |

These curves are `validation_candidate`, not `qualified`. They represent
direct excitation from ground-state Ar only. Quantitative OES use still needs
an independent comparison of the state-resolved cross sections and an
applicability assessment for metastable stepwise excitation, cascade,
quenching, and radiation trapping. Their inclusion therefore expands the
number of distinct upper-state kernels without asserting that those missing
pathways are negligible in an etch or deposition plasma.
