import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from oescr.forward.model import OESCRModel
from oescr.inverse.priors import prior_residuals
from oescr.inverse.window_metrics import (
    window_features,
    window_fit_residuals,
    window_ratio_pair_residuals,
    window_ratio_residuals,
)


def test_curated_nf3_forward_runs():
    case = Path("examples/case_skeleton_nf3_ar.yaml")
    model = OESCRModel.from_yaml(case)
    result = model.predict()
    assert "uvvis_lowres" in result.spectra
    assert len(result.zone_populations) == 3


def test_curated_cl2_forward_runs():
    case = Path("examples/case_skeleton_cl2_ar.yaml")
    model = OESCRModel.from_yaml(case)
    result = model.predict()
    assert "uvvis_lowres" in result.spectra
    assert len(result.zone_populations) == 3


def test_window_fit_zero_for_identical_signals():
    wl = np.linspace(700.0, 710.0, 41)
    y = np.exp(-0.5 * ((wl - 703.7) / 0.3) ** 2) + 0.1 + 0.01 * (wl - wl.mean())
    r = window_fit_residuals(
        wl,
        y,
        y,
        center_nm=703.7,
        half_width_nm=1.0,
        baseline_mode="local_linear",
        normalization="area",
        local_gain=False,
    )
    assert np.allclose(r, 0.0, atol=1.0e-10)


def test_window_features_baseline_corrected_area_positive():
    wl = np.linspace(700.0, 710.0, 41)
    y = 0.2 + 0.02 * (wl - wl.mean()) + 2.0 * np.exp(-0.5 * ((wl - 703.7) / 0.3) ** 2)
    feats = window_features(wl, y, center_nm=703.7, half_width_nm=1.0, baseline_mode="local_linear")
    assert feats["area"] > 0.0
    assert feats["peak"] > 0.0


def test_window_ratio_zero_for_identical_feature_ratios():
    windows = [
        {"name": "ref", "use_peak": True, "use_area": True},
        {"name": "line_a", "use_peak": True, "use_area": True},
        {"name": "line_b", "use_peak": True, "use_area": True},
    ]
    pred = {
        "ref": {"area": 4.0, "peak": 2.0},
        "line_a": {"area": 2.0, "peak": 1.0},
        "line_b": {"area": 1.0, "peak": 0.5},
    }
    meas = {
        "ref": {"area": 8.0, "peak": 4.0},
        "line_a": {"area": 4.0, "peak": 2.0},
        "line_b": {"area": 2.0, "peak": 1.0},
    }
    r = window_ratio_residuals(
        windows,
        pred,
        meas,
        metric="peak",
        reference_window="ref",
        min_relative_signal=0.0,
    )
    assert np.allclose(r, 0.0, atol=1.0e-12)

    meas["ref"] = {"area": 0.001, "peak": 0.001}
    pred["ref"] = {"area": 100.0, "peak": 100.0}
    unavailable_reference = window_ratio_residuals(
        windows, pred, meas, metric="peak", reference_window="ref", min_relative_signal=0.02
    )
    assert unavailable_reference.size == 0


def test_window_ratio_pair_zero_for_identical_pair_ratio():
    pred = {
        "line_a": {"area": 4.0, "peak": 2.0},
        "line_b": {"area": 2.0, "peak": 1.0},
    }
    meas = {
        "line_a": {"area": 8.0, "peak": 4.0},
        "line_b": {"area": 4.0, "peak": 2.0},
    }
    residuals = window_ratio_pair_residuals(
        pred,
        meas,
        [{"name": "a_over_b", "numerator": "line_a", "denominator": "line_b", "metric": "peak"}],
        default_metric="peak",
        default_min_relative_signal=0.0,
    )
    assert np.allclose(residuals[0], 0.0, atol=1.0e-12)


def test_log_gaussian_array_prior_zero_when_values_match():
    case_cfg = {"plasma_state": {"ne_shells_m3": [1.0e16, 8.0e15, 6.0e15]}}
    inv_cfg = {
        "priors": [
            {
                "type": "log_gaussian",
                "path": "plasma_state.ne_shells_m3",
                "mean_log10": [16.0, np.log10(8.0e15), np.log10(6.0e15)],
                "sigma_log10": 0.2,
            }
        ]
    }
    r = prior_residuals(case_cfg, inv_cfg)
    assert np.allclose(r, 0.0, atol=1.0e-12)
