from __future__ import annotations

import numpy as np
import pytest

from oescr.analysis.benchmark_metrics import (
    aggregate_spectral_relative_l2,
    aggregate_window_rows,
    safe_corr,
    spectral_relative_l2,
)


def test_benchmark_metrics_are_usable_without_report_rendering() -> None:
    entries = [
        {
            "scenario": "opt",
            "window_name": "Ar_750",
            "kind": "atomic_line",
            "family": "Ar",
            "area_ratio": 0.9,
            "peak_ratio": 1.1,
            "peak_shift_nm": -0.2,
            "measurement_area": 4.0,
        },
        {
            "scenario": "opt",
            "window_name": "Ar_750",
            "kind": "atomic_line",
            "family": "Ar",
            "area_ratio": 1.1,
            "peak_ratio": 0.9,
            "peak_shift_nm": 0.4,
            "measurement_area": 6.0,
        },
    ]

    rows = aggregate_window_rows(entries, ("window_name",))

    assert rows[0]["window_name"] == "Ar_750"
    assert rows[0]["kind"] == "atomic_line"
    assert rows[0]["family"] == "Ar"
    assert rows[0]["mean_area_ratio"] == pytest.approx(1.0)
    assert rows[0]["mean_peak_ratio"] == pytest.approx(1.0)
    assert rows[0]["mean_abs_peak_shift_nm"] == pytest.approx(0.3)
    assert rows[0]["mean_abs_measurement_area"] == pytest.approx(5.0)
    assert safe_corr(np.array([1.0, 2.0]), np.array([2.0, 4.0])) == pytest.approx(1.0)
    assert safe_corr(np.array([1.0e-12, 2.0e-12]), np.array([2.0e-12, 1.0e-12])) == pytest.approx(-1.0)
    assert safe_corr(np.ones(3), np.array([1.0, 2.0, 3.0])) == 0.0


def test_spectral_relative_l2_aligns_prediction_to_reference_grid() -> None:
    prediction = {
        "wavelength_nm": np.array([700.0, 701.0, 702.0]),
        "intensity": np.array([0.0, 2.0, 0.0]),
    }
    reference = {
        "wavelength_nm": np.array([700.0, 700.5, 701.0, 701.5, 702.0]),
        "intensity": np.array([0.0, 1.0, 2.0, 1.0, 0.0]),
    }

    assert spectral_relative_l2(prediction, reference) == pytest.approx(0.0)
    assert aggregate_spectral_relative_l2(
        {"held_out": prediction},
        {"held_out": reference},
        ["held_out"],
    ) == pytest.approx(0.0)


def test_aggregate_spectral_relative_l2_requires_declared_spectrum() -> None:
    with pytest.raises(ValueError, match="At least one spectrum"):
        aggregate_spectral_relative_l2({}, {}, [])
