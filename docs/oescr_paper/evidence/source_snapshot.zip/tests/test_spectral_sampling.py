import numpy as np
import pytest
from scipy.special import erf

from oescr.data.band_db import load_profile_csv
from oescr.forward.compiled import build_fine_wavelength_grid
from oescr.forward.emissivity import gaussian_line_profile
from oescr.forward.observe import ObservationPlan
from oescr.instrument.lsf import apply_lsf
from oescr.instrument.spec import InstrumentSpec


@pytest.mark.parametrize("rows, message", [
    ("500,1\n499,1\n", "strictly increasing"),
    ("499,1\n500,-1\n", "non-negative"),
    ("499,0\n500,0\n", "positive finite"),
    ("499,1\n500,nan\n", "finite"),
])
def test_tabulated_contour_rejects_invalid_native_data(tmp_path, rows: str, message: str) -> None:
    profile = tmp_path / "profile.csv"
    profile.write_text("wavelength_nm,relative_intensity\n" + rows, encoding="utf-8")
    with pytest.raises(ValueError, match=message):
        load_profile_csv(profile)


def test_nonuniform_detector_bins_integrate_a_linear_spectrum_analytically() -> None:
    instrument = InstrumentSpec(
        {
            "id": "nonuniform-explicit-grid",
            "wavelength_grid_nm": [497.0, 499.0, 502.0, 504.0],
            "throughput": 1.0,
            "lsf": {"kind": "gaussian", "fwhm_nm": 1.0e-8},
        }
    )
    fine_wavelength_nm = np.linspace(495.0, 506.0, 111)
    fine_intensity = 2.0 + 0.1 * (fine_wavelength_nm - 500.0)

    observed = instrument.observe(fine_wavelength_nm, fine_intensity)
    edges = np.array([496.0, 498.0, 500.5, 503.0, 505.0])
    expected = 2.0 + 0.1 * (0.5 * (edges[:-1] + edges[1:]) - 500.0)

    np.testing.assert_allclose(observed["intensity"], expected, rtol=2.0e-13, atol=2.0e-13)
    batch = instrument.observe(fine_wavelength_nm, np.stack([fine_intensity, 2.0 * fine_intensity + 0.3]))
    np.testing.assert_allclose(batch["intensity"], [expected, 2.0 * expected + 0.3], rtol=2.0e-13, atol=2.0e-13)
    with pytest.raises(ValueError, match="uniform wavelength grid"):
        apply_lsf(instrument.cfg, np.array([495.0, 496.0, 498.0]), np.ones(3))


@pytest.mark.parametrize("offset", [0.0, 0.015625, 0.03125])
def test_unresolved_line_matches_analytic_convolution_at_each_pixel_phase(offset: float) -> None:
    cfg = {"geometry": {"mode": "chordavg", "n_shells": 1}}
    instrument = {
        "id": "coarse",
        "wavelength_min_nm": 498.0,
        "wavelength_max_nm": 502.0,
        "bin_nm": 0.5,
        "throughput": 1.0,
        "lsf": {"kind": "gaussian", "fwhm_nm": 0.7},
    }
    source = np.arange(493.0, 507.0, 0.02 / 6.0)
    signal = gaussian_line_profile(source, 500.0 + offset, 0.02)
    plan = ObservationPlan.compile(cfg, [instrument], source)
    observed = plan.observe(cfg, signal[None, :])["coarse"]["chord_0"]
    centers = observed["wavelength_nm"]
    sigma = np.sqrt(0.7**2 + 0.02**2) / 2.35482004503
    edges = np.r_[centers - 0.25, centers[-1] + 0.25]
    expected = np.diff(0.5 * erf((edges - 500.0 - offset) / (sigma * np.sqrt(2.0)))) / 0.5
    np.testing.assert_allclose(observed["intensity"], expected, rtol=1.0e-3, atol=1.0e-6)
    assert np.sum(observed["intensity"]) * 0.5 == pytest.approx(1.0, rel=1.0e-5)


def test_throughput_precedes_lsf_and_padding_covers_a_wide_shifted_kernel() -> None:
    cfg = {"geometry": {"mode": "chordavg", "n_shells": 1}}
    instrument = {
        "id": "response-edge",
        "wavelength_min_nm": 490.0,
        "wavelength_max_nm": 510.0,
        "bin_nm": 0.5,
        "throughput": {
            "kind": "tabulated",
            "wavelength_nm": [499.9, 500.0, 500.01, 501.0],
            "values": [0.0, 0.0, 1.0, 1.0],
        },
        "lsf": {"kind": "gaussian", "fwhm_nm": 0.7},
    }
    source = np.arange(485.0, 515.0, 0.002)
    signal = gaussian_line_profile(source, 500.2, 0.02)
    observed = ObservationPlan.compile(cfg, [instrument], source).observe(cfg, signal[None, :])
    assert np.sum(observed["response-edge"]["chord_0"]["intensity"]) * 0.5 == pytest.approx(1.0, rel=1.0e-5)

    instrument["lsf"] = {"kind": "gaussian", "fwhm_nm": 10.0}
    instrument["nuisance"] = {"wavelength_shift_nm": 7.0}
    grid = build_fine_wavelength_grid({}, [instrument])
    sigma = 10.0 / 2.35482004503
    assert grid[0] < 490.0 - (5.0 * sigma + 7.0)
    assert grid[-1] > 510.0 + (5.0 * sigma + 7.0)


def test_segmented_grid_merges_overlapping_padded_coverages() -> None:
    cfg = {
        "numerics": {"wavelength_refinement_factor": 2.0},
        "transitions": [{"profile": {"fwhm_nm": 0.12}}],
    }
    instruments = [
        {
            "wavelength_min_nm": 400.0,
            "wavelength_max_nm": 410.0,
            "bin_nm": 1.0,
            "lsf": {"fwhm_nm": 0.8},
        },
        {
            "wavelength_grid_nm": [408.0, 409.0, 412.0],
            "lsf": {"fwhm_nm": 0.8},
        },
    ]

    grid = build_fine_wavelength_grid(cfg, instruments)
    expected_dx = (0.12 / 6.0) / 2.0
    expected = np.arange(395.0, 417.0 + 0.5 * expected_dx, expected_dx)

    np.testing.assert_allclose(grid, expected, rtol=0.0, atol=2.0e-11)
    assert np.all(np.diff(grid) > 0.0)


def test_segmented_grid_avoids_large_gap_for_wide_and_disjoint_instrument_coverages() -> None:
    cfg = {"numerics": {"wavelength_refinement_factor": 2.0}}
    instruments = [
        {
            "wavelength_min_nm": 200.0,
            "wavelength_max_nm": 900.0,
            "bin_nm": 2.0,
            "lsf": {"fwhm_nm": 1.0},
        },
        {
            "wavelength_grid_nm": [5000.0, 5000.5, 5001.5],
            "lsf": {"fwhm_nm": 0.4},
        },
    ]

    grid = build_fine_wavelength_grid(cfg, instruments)
    expected_dx = (0.4 / 8.0) / 2.0
    first = np.arange(195.0, 905.0 + 0.5 * expected_dx, expected_dx)
    second = np.arange(4995.0, 5006.5 + 0.5 * expected_dx, expected_dx)
    legacy_contiguous_size = np.arange(195.0, 5006.5 + 0.5 * expected_dx, expected_dx).size

    np.testing.assert_allclose(grid[: first.size], first, rtol=0.0, atol=2.0e-11)
    np.testing.assert_allclose(grid[first.size :], second, rtol=0.0, atol=2.0e-11)
    assert np.all(np.diff(grid) > 0.0)
    assert np.max(np.diff(grid)) > 4000.0
    assert grid.size == first.size + second.size
    assert grid.size < legacy_contiguous_size / 6


def test_band_profiles_retain_legacy_contiguous_grid_across_disjoint_instruments() -> None:
    cfg = {
        "numerics": {"wavelength_refinement_factor": 2.0},
        "bands": [
            {
                "profile_kind": "gaussian",
                "center_nm": 700.0,
                "fwhm_nm": 40.0,
            }
        ],
    }
    instruments = [
        {
            "wavelength_min_nm": 400.0,
            "wavelength_max_nm": 410.0,
            "bin_nm": 1.0,
            "lsf": {"fwhm_nm": 0.8},
        },
        {
            "wavelength_grid_nm": [990.0, 991.0, 992.0],
            "lsf": {"fwhm_nm": 0.4},
        },
    ]

    grid = build_fine_wavelength_grid(cfg, instruments)
    expected_dx = (0.4 / 8.0) / 2.0
    legacy = np.arange(395.0, 997.0 + 0.5 * expected_dx, expected_dx)

    np.testing.assert_array_equal(grid, legacy)
    np.testing.assert_allclose(np.diff(grid), expected_dx, rtol=0.0, atol=1.0e-13)


def test_broad_atomic_profile_retains_contiguous_grid_for_profile_normalization() -> None:
    cfg = {
        "transitions": [
            {
                "wavelength_nm": 405.0,
                "profile": {"fwhm_nm": 1.0},
            }
        ]
    }
    instruments = [
        {
            "wavelength_min_nm": 400.0,
            "wavelength_max_nm": 410.0,
            "bin_nm": 1.0,
        },
        {
            "wavelength_min_nm": 990.0,
            "wavelength_max_nm": 992.0,
            "bin_nm": 1.0,
        },
    ]

    grid = build_fine_wavelength_grid(cfg, instruments)
    legacy = np.arange(395.0, 997.0 + 0.5 * 0.125, 0.125)

    np.testing.assert_array_equal(grid, legacy)
