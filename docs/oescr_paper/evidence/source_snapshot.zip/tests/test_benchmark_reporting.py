from __future__ import annotations

import csv
from pathlib import Path

import numpy as np

from oescr.analysis.benchmark_contract import ANALYSIS_CONTRACT_VERSION
from oescr.analysis.benchmark_results import analyze_one
from oescr.inverse.optimize import FitResult, InverseSolver
from oescr.inverse.reporting import write_fit_result
from oescr.io.yaml_loader import load_yaml

ROOT = Path(__file__).resolve().parents[1]
NF3_BENCHMARK = ROOT / "examples" / "benchmarks" / "nf3_ar_ccp_clean_2023"


def test_benchmark_report_generation_writes_expected_artifacts(tmp_path: Path) -> None:
    result_directory = tmp_path / "inverse_result"
    result_directory.mkdir()
    previous_analysis = result_directory / "analysis"
    (previous_analysis / "plots").mkdir(parents=True)
    (previous_analysis / "analysis_dashboard.html").write_text("retired", encoding="utf-8")
    (previous_analysis / "plots" / "fit_quality.svg").write_text("retired", encoding="utf-8")
    note = previous_analysis / "plots" / "user_note.txt"
    note.write_text("retain this note", encoding="utf-8")
    solver = InverseSolver.from_yaml(
        NF3_BENCHMARK / "case_init.yaml",
        NF3_BENCHMARK / "inverse.yaml",
    )
    x_initial = solver.params.initial_vector(solver.case_cfg)
    write_fit_result(
        FitResult(
            x_opt=np.asarray(x_initial, dtype=float),
            case_opt=solver.case_cfg,
            cost=0.0,
            success=True,
            message="fixture",
            aux={},
            parameters=solver.params.physical_values(x_initial),
        ),
        result_directory,
    )

    output_directory = analyze_one(
        NF3_BENCHMARK,
        str(result_directory),
        "analysis",
    )

    for relative_path in (
        "analysis_summary.yaml",
        "analysis_report.md",
        "scenario_metrics.csv",
        "parameter_recovery.csv",
        "chord_metrics.csv",
        "window_metrics.csv",
        "spectral_comparisons.csv",
    ):
        output = output_directory / relative_path
        assert output.is_file()
        assert output.stat().st_size > 0

    summary = load_yaml(output_directory / "analysis_summary.yaml")
    assert summary["analysis_contract"]["name"] == "oescr.benchmark.analysis"
    assert summary["analysis_contract"]["version"] == ANALYSIS_CONTRACT_VERSION
    assert len(summary["analysis_contract"]["measurement_sha256"]) == 64
    assert summary["run_fingerprint"]["parameter_names"] == solver.params.names()
    assert len(summary["run_fingerprint"]["result_sha256"]) == 64
    assert summary["saved_fit"] == {"success": True, "cost": 0.0}
    assert next(row["cost"] for row in summary["scenario_summary"] if row["scenario"] == "opt") > 0.0
    assert not (output_directory / "analysis_dashboard.html").exists()
    assert not (output_directory / "plots" / "fit_quality.svg").exists()
    assert note.read_text(encoding="utf-8") == "retain this note"
    assert [row["name"] for row in summary["parameter_recovery"]] == solver.params.names()
    assert all(row["initial"] == row["optimized"] for row in summary["parameter_recovery"])
    with (output_directory / "spectral_comparisons.csv").open(encoding="utf-8", newline="") as stream:
        comparisons = list(csv.DictReader(stream))
    assert {row["scenario"] for row in comparisons} == {"init", "opt", "truth"}
    assert len(comparisons) == 3 * sum(len(item.intensity) for items in solver.measurements.values() for item in items)
    first = comparisons[0]
    assert np.isclose(float(first["residual"]), float(first["predicted"]) - float(first["measured"]))
