from __future__ import annotations

from pathlib import Path

import pytest

from oescr.inverse.optimize import InverseSolver
from oescr.inverse.window_metrics import window_ratio_pair_residuals
from oescr.io.yaml_loader import load_yaml

EXAMPLE_DIR = Path(__file__).resolve().parents[1] / "examples" / "use_cases" / "two_band"


def test_ratio_configuration_cannot_succeed_without_an_effective_measurement() -> None:
    case = load_yaml(EXAMPLE_DIR / "case_ratio_init.yaml")
    inverse = load_yaml(EXAMPLE_DIR / "inverse_ratio.yaml")
    inverse["fit"]["objective"]["window_ratio_pairs"][0]["numerator"] = "target_typo"
    with pytest.raises(ValueError, match="unknown or non-fit window"):
        InverseSolver(case, inverse).fit()

    inverse = load_yaml(EXAMPLE_DIR / "inverse_ratio.yaml")
    inverse["fit"]["objective"]["window_ratio_pairs"][0]["min_relative_signal"] = 2.0
    with pytest.raises(ValueError, match="no effective measurement objective"):
        InverseSolver(case, inverse).fit()


def test_zero_predicted_line_remains_a_ratio_discrepancy() -> None:
    residuals = window_ratio_pair_residuals(
        {"a": {"area": 0.0, "peak": 0.0}, "b": {"area": 1.0, "peak": 1.0}},
        {"a": {"area": 2.0, "peak": 2.0}, "b": {"area": 1.0, "peak": 1.0}},
        [{"numerator": "a", "denominator": "b", "metric": "area"}],
    )
    assert len(residuals[0]) == 1
    assert residuals[0][0] < -100.0


@pytest.mark.parametrize(
    ("inverse_name", "mode"),
    [
        ("inverse_ratio.yaml", "ratio_diagnostic"),
        ("inverse_actinometry.yaml", "actinometry"),
    ],
)
def test_ratio_based_vertical_slices_recover_target_density(
    inverse_name: str,
    mode: str,
) -> None:
    solver = InverseSolver.from_yaml(
        EXAMPLE_DIR / "case_ratio_init.yaml",
        EXAMPLE_DIR / inverse_name,
    )

    fit = solver.fit(record_trace=True, audit=True)

    assert fit.success
    assert fit.case_opt["plasma_state"]["radicals"]["Target"][0] == pytest.approx(2.0e18, rel=1.0e-6)
    assert fit.assessment is not None
    assert fit.assessment["mode"] == mode
    assert fit.identifiability is not None
    assert fit.identifiability["rank_estimate"] == 1
    assert fit.identifiability["n_observations"] == 1
    assert fit.identifiability["selected_windows"]["two_band_radiance"] == [
        "target_500",
        "actinometer_510",
    ]
    assert fit.optimization_trace is not None
    assert [row["evaluation"] for row in fit.optimization_trace] == list(range(len(fit.optimization_trace)))
    assert fit.optimization_trace[-1]["stage"] == "final"
    assert fit.optimization_trace[-1]["loss"] == pytest.approx(fit.cost)


def test_calibrated_absolute_vertical_slice_recovers_electron_density() -> None:
    solver = InverseSolver.from_yaml(
        EXAMPLE_DIR / "case_absolute_init.yaml",
        EXAMPLE_DIR / "inverse_absolute.yaml",
    )

    fit = solver.fit(audit=True)

    assert fit.success
    assert fit.case_opt["plasma_state"]["ne_shells_m3"][0] == pytest.approx(3.0e16, rel=1.0e-6)
    assert fit.assessment is not None
    assert fit.assessment["mode"] == "calibrated_absolute"
    assert fit.assessment["absolute_scale_prerequisites_met"]
    assert fit.assessment["absolute_scale_locally_identifiable"]
    assert fit.identifiability is not None
    assert fit.identifiability["rank_estimate"] == 1
    assert fit.calibration_uncertainty == {"two_band_radiance": 0.01}
    assert fit.optimization_trace is None
