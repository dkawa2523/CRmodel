from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import numpy as np
import pytest

from oescr.analysis.benchmark_contract import measurement_sha256
from oescr.analysis.benchmark_results import _scenario_analysis
from oescr.inverse.measurements import Measurement, load_measurement_csv, load_measurements
from oescr.inverse.objectives import residual_vector
from oescr.io.normalize import normalize_measurement_bindings
from oescr.io.validators import validate_inverse_structural


class _BoundPredictionModel:
    def __init__(self, spectra):
        self._spectra = spectra
        self._instrument = {
            "id": "uvvis",
            "wavelength_grid_nm": [500.0, 501.0, 502.0],
            "throughput": 1.0,
            "lsf": {"kind": "gaussian", "fwhm_nm": 0.1},
            "baseline": {"kind": "constant", "offset": 0.0},
            "nuisance": {"gain": 1.0},
        }

    def predict(self, _case_cfg):
        return SimpleNamespace(spectra={"uvvis": self._spectra})

    def instrument_configs_for(self, _case_cfg=None):
        return [self._instrument]


def _measurement(measurement_id: str, prediction_key: str, intensity) -> Measurement:
    wavelength = np.asarray([500.0, 501.0, 502.0])
    return Measurement(
        wavelength_nm=wavelength,
        intensity=np.asarray(intensity, dtype=float),
        sigma=np.ones(3),
        id=measurement_id,
        prediction_key=prediction_key,
    )


def test_legacy_bindings_are_normalized_once_per_instrument(tmp_path) -> None:
    config: dict[str, Any] = {
        "__base_dir__": str(tmp_path),
        "measurements": [
            {"instrument_id": "uvvis", "file": "first.csv"},
            {
                "instrument_id": "uvvis", "files": ["second.csv", "third.csv"],
                "covariance_files": ["second_cov.csv", "third_cov.csv"],
            },
            {"instrument_id": "other", "file": "only.csv"},
        ],
    }

    normalized = normalize_measurement_bindings(config)

    assert normalized[0]["prediction_key"] == "chord_0"
    assert [item["prediction_key"] for item in normalized] == ["chord_0", "chord_1", "chord_2", "chord_0"]
    assert len({item["id"] for item in normalized}) == 4
    assert all("file" in item and "files" not in item for item in normalized)
    assert [item["covariance_file"] for item in normalized[1:3]] == [
        str((tmp_path / name).resolve()) for name in ("second_cov.csv", "third_cov.csv")
    ]
    config["measurements"][1]["covariance_files"] = ["only_one.csv"]
    with pytest.raises(ValueError, match="same number and order"):
        normalize_measurement_bindings(config)
    config["measurements"] = normalized
    assert normalize_measurement_bindings(config) == normalized


def test_legacy_measurement_id_does_not_depend_on_checkout_path(tmp_path) -> None:
    first = normalize_measurement_bindings(
        {
            "__base_dir__": str(tmp_path / "checkout_a"),
            "measurements": [{"instrument_id": "uvvis", "file": "measurements/run.csv"}],
        }
    )
    second = normalize_measurement_bindings(
        {
            "__base_dir__": str(tmp_path / "checkout_b"),
            "measurements": [{"instrument_id": "uvvis", "file": "measurements/run.csv"}],
        }
    )

    assert first[0]["id"] == second[0]["id"]


def test_explicit_bindings_allow_replicates_for_one_prediction(tmp_path) -> None:
    for name, scale in (("repeat_a.csv", 1.0), ("repeat_b.csv", 1.1)):
        (tmp_path / name).write_text(
            f"wavelength_nm,intensity,sigma\n500.0,{scale},0.1\n501.0,{2.0 * scale},0.1\n502.0,{3.0 * scale},0.1\n",
            encoding="utf-8",
        )
    inverse = {
        "__base_dir__": str(tmp_path),
        "measurements": [
            {
                "instrument_id": "uvvis",
                "files": ["repeat_a.csv", "repeat_b.csv"],
                "ids": ["repeat-a", "repeat-b"],
                "prediction_keys": ["chord_0", "chord_0"],
            }
        ],
    }

    loaded = load_measurements(inverse)["uvvis"]

    assert [measurement.id for measurement in loaded] == ["repeat-a", "repeat-b"]
    assert [measurement.prediction_key for measurement in loaded] == ["chord_0", "chord_0"]


@pytest.mark.parametrize(
    "measurement_source",
    [
        {"files": ["repeat_a.csv", "repeat_b.csv"]},
        {"files_glob": "repeat_*.csv"},
    ],
)
def test_plural_bindings_broadcast_one_shared_prediction_key(
    tmp_path,
    measurement_source: dict[str, Any],
) -> None:
    for name in ("repeat_a.csv", "repeat_b.csv"):
        (tmp_path / name).write_text(
            "wavelength_nm,intensity,sigma\n500.0,1.0,0.1\n501.0,2.0,0.1\n502.0,3.0,0.1\n",
            encoding="utf-8",
        )
    inverse = {
        "__base_dir__": str(tmp_path),
        "measurements": [
            {
                "instrument_id": "uvvis",
                **measurement_source,
                "ids": ["repeat-a", "repeat-b"],
                "prediction_key": "chord_0",
            }
        ],
    }

    normalized = normalize_measurement_bindings(inverse)
    loaded = load_measurements(inverse)["uvvis"]

    assert [item["prediction_key"] for item in normalized] == ["chord_0", "chord_0"]
    assert all("prediction_keys" not in item and "files_glob" not in item for item in normalized)
    assert [measurement.prediction_key for measurement in loaded] == ["chord_0", "chord_0"]


def test_plural_bindings_reject_shared_and_ordered_prediction_keys_together(tmp_path) -> None:
    inverse = {
        "__base_dir__": str(tmp_path),
        "measurements": [
            {
                "instrument_id": "uvvis",
                "files": ["repeat_a.csv", "repeat_b.csv"],
                "prediction_key": "chord_0",
                "prediction_keys": ["chord_0", "chord_0"],
            }
        ],
    }

    with pytest.raises(ValueError, match="either one shared prediction_key.*not both"):
        normalize_measurement_bindings(inverse)


def test_legacy_and_explicit_equivalent_bindings_produce_same_residual(tmp_path) -> None:
    for name, values in (("left.csv", [1.1, 1.9, 4.2]), ("right.csv", [3.8, 2.2, 0.9])):
        rows = "\n".join(
            f"{wavelength},{intensity},1.0" for wavelength, intensity in zip([500.0, 501.0, 502.0], values, strict=True)
        )
        (tmp_path / name).write_text(
            f"wavelength_nm,intensity,sigma\n{rows}\n",
            encoding="utf-8",
        )
    legacy = {
        "__base_dir__": str(tmp_path),
        "measurements": [{"instrument_id": "uvvis", "files": ["left.csv", "right.csv"]}],
    }
    canonical_entries = normalize_measurement_bindings(legacy)
    explicit = {
        "__base_dir__": str(tmp_path),
        "measurements": [
            {
                "instrument_id": "uvvis",
                "files": ["left.csv", "right.csv"],
                "ids": [item["id"] for item in canonical_entries],
                "prediction_keys": ["chord_0", "chord_1"],
            }
        ],
    }
    wavelength = np.asarray([500.0, 501.0, 502.0])
    model = _BoundPredictionModel(
        {
            "chord_0": {"wavelength_nm": wavelength, "intensity": np.asarray([1.0, 2.0, 4.0])},
            "chord_1": {"wavelength_nm": wavelength, "intensity": np.asarray([4.0, 2.0, 1.0])},
        }
    )
    inverse = {
        "fit": {
            "objective": {
                "auto_gain_fit": False,
                "auto_offset_fit": False,
                "spectrum_weight": 1.0,
            }
        }
    }

    legacy_residual, _ = residual_vector(model, {}, inverse, load_measurements(legacy), [])
    explicit_residual, _ = residual_vector(model, {}, inverse, load_measurements(explicit), [])

    assert np.array_equal(legacy_residual, explicit_residual)


def test_inverse_schema_accepts_explicit_measurement_bindings() -> None:
    validate_inverse_structural(
        {
            "measurements": [
                {
                    "instrument_id": "uvvis",
                    "files": ["repeat-a.csv", "repeat-b.csv"],
                    "ids": ["repeat-a", "repeat-b"],
                    "prediction_keys": ["chord_0", "chord_0"],
                    "calibration_group_id": "session-a",
                }
            ],
            "parameters": [
                {
                    "name": "te",
                    "path": "plasma_state.te_shells_eV[0]",
                    "bounds": [1.0, 10.0],
                }
            ],
        }
    )


def test_inverse_schema_accepts_shared_prediction_key_for_plural_files() -> None:
    validate_inverse_structural(
        {
            "measurements": [
                {
                    "instrument_id": "uvvis",
                    "files_glob": "measurements/repeat-*.csv",
                    "prediction_key": "chord_0",
                }
            ],
            "parameters": [
                {
                    "name": "te",
                    "path": "plasma_state.te_shells_eV[0]",
                    "bounds": [1.0, 10.0],
                }
            ],
        }
    )


def test_objective_is_invariant_to_measurement_order() -> None:
    wavelength = np.asarray([500.0, 501.0, 502.0])
    spectra = {
        "view_left": {"wavelength_nm": wavelength, "intensity": np.asarray([1.0, 2.0, 4.0])},
        "view_right": {"wavelength_nm": wavelength, "intensity": np.asarray([4.0, 2.0, 1.0])},
    }
    model = _BoundPredictionModel(spectra)
    left = _measurement("measurement-b", "view_left", [1.1, 1.9, 4.2])
    right = _measurement("measurement-a", "view_right", [3.8, 2.2, 0.9])
    inverse = {
        "fit": {
            "objective": {
                "auto_gain_fit": False,
                "auto_offset_fit": False,
                "spectrum_weight": 1.0,
            }
        }
    }

    residual_a, aux_a = residual_vector(model, {}, inverse, {"uvvis": [left, right]}, [])
    residual_b, aux_b = residual_vector(model, {}, inverse, {"uvvis": [right, left]}, [])

    assert np.array_equal(residual_a, residual_b)
    assert aux_a == aux_b
    assert set(aux_a["gain_offset"]) == {("uvvis", "measurement-a"), ("uvvis", "measurement-b")}


def test_objective_accepts_multiple_observations_bound_to_same_prediction() -> None:
    wavelength = np.asarray([500.0, 501.0, 502.0])
    model = _BoundPredictionModel({"chord_0": {"wavelength_nm": wavelength, "intensity": np.asarray([1.0, 2.0, 3.0])}})
    first = _measurement("repeat-a", "chord_0", [1.0, 2.0, 3.0])
    second = _measurement("repeat-b", "chord_0", [1.1, 1.9, 3.2])
    inverse = {
        "fit": {
            "objective": {
                "auto_gain_fit": False,
                "auto_offset_fit": False,
                "spectrum_weight": 1.0,
            }
        }
    }

    residual, _ = residual_vector(model, {}, inverse, {"uvvis": [first, second]}, [])

    assert residual.shape == (6,)


def test_benchmark_analysis_uses_measurement_binding_not_list_position() -> None:
    wavelength = np.asarray([500.0, 501.0, 502.0])
    spectra = {
        "view_left": {"wavelength_nm": wavelength, "intensity": np.asarray([1.0, 2.0, 4.0])},
        "view_right": {"wavelength_nm": wavelength, "intensity": np.asarray([4.0, 2.0, 1.0])},
    }
    model = _BoundPredictionModel(spectra)
    left = _measurement("measurement-z", "view_left", [1.0, 2.0, 4.0])
    right = _measurement("measurement-a", "view_right", [4.0, 2.0, 1.0])
    inverse = {
        "fit": {
            "objective": {
                "auto_gain_fit": False,
                "auto_offset_fit": False,
                "spectrum_weight": 1.0,
                "window_baseline_mode": "none",
            }
        }
    }
    solver: Any = SimpleNamespace(model=model, inv_cfg=inverse)

    analysis = _scenario_analysis(
        "test", {}, solver, {"uvvis": [left, right]},
        [{"name": "whole", "kind": "atomic_line", "center_nm": 501.0, "half_width_nm": 1.1}],
    )

    rows = {row["measurement_id"]: row for row in analysis["chord_metrics"]}
    assert rows["measurement-z"]["prediction_key"] == "view_left"
    assert rows["measurement-a"]["prediction_key"] == "view_right"
    spectra_by_id = {fit.observation_id: fit for fit in analysis["spectral_fits"]}
    assert np.allclose(spectra_by_id["measurement-z"].predicted, [1.0, 2.0, 4.0])
    assert np.allclose(spectra_by_id["measurement-a"].predicted, [4.0, 2.0, 1.0])
    assert all(np.isclose(row["measurement_area"], 4.5) for row in analysis["window_metrics"])


def test_measurement_fingerprint_is_order_invariant_and_binding_sensitive() -> None:
    left = _measurement("measurement-b", "view_left", [1.0, 2.0, 3.0])
    right = _measurement("measurement-a", "view_right", [3.0, 2.0, 1.0])

    forward = measurement_sha256({"uvvis": [left, right]})
    reversed_order = measurement_sha256({"uvvis": [right, left]})
    rebound = _measurement("measurement-a", "view_left", [3.0, 2.0, 1.0])

    assert forward == reversed_order
    assert forward != measurement_sha256({"uvvis": [left, rebound]})


@pytest.mark.parametrize(
    ("contents", "message"),
    [
        ("", "empty or has no CSV header"),
        ("wavelength_nm,intensity\n", "contains no data rows"),
        ("wavelength_nm,intensity\n500.0,1.0\n500.0,2.0\n", "duplicate wavelength"),
        ("wavelength_nm,intensity\n501.0,1.0\n500.0,2.0\n", "strictly increasing"),
        ("wavelength_nm,intensity\n500.0,nan\n", "must be finite"),
        ("wavelength_nm,intensity\ninf,1.0\n", "must be finite"),
    ],
)
def test_measurement_csv_rejects_invalid_sample_grids(tmp_path, contents: str, message: str) -> None:
    path = tmp_path / "invalid.csv"
    path.write_text(contents, encoding="utf-8")

    with pytest.raises(ValueError, match=message):
        load_measurement_csv(path)
