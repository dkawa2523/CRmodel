from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import numpy as np
import pytest

import oescr.inverse.objectives as objectives_module
import oescr.inverse.optimize as optimize_module
from oescr.inverse.optimize import InverseSolver
from oescr.io.validators import ConfigSemanticError
from oescr.io.yaml_loader import load_yaml

ROOT = Path(__file__).resolve().parents[1]
EXAMPLE_DIR = ROOT / "examples" / "use_cases" / "two_band"


def _absolute_solver() -> InverseSolver:
    return InverseSolver.from_yaml(
        EXAMPLE_DIR / "case_absolute_init.yaml",
        EXAMPLE_DIR / "inverse_absolute.yaml",
    )


def test_global_only_reports_exhausted_search_and_requires_a_stage() -> None:
    solver = _absolute_solver()
    solver.inv_cfg["fit"]["global"].update(enabled=True, maxiter=0, popsize=1)
    solver.inv_cfg["fit"]["local"]["enabled"] = False

    result = solver.fit()

    assert result.success is False
    assert "maximum" in result.message.lower()
    solver.inv_cfg["fit"]["global"]["enabled"] = False
    with pytest.raises(ValueError, match="at least one"):
        solver.fit()


def test_global_search_is_opt_in_and_explicit_enable_is_preserved() -> None:
    case_cfg = load_yaml(EXAMPLE_DIR / "case_absolute_init.yaml")
    inverse_cfg = load_yaml(EXAMPLE_DIR / "inverse_absolute.yaml")
    inverse_cfg["fit"].pop("global")

    default_solver = InverseSolver(case_cfg, inverse_cfg)
    assert default_solver.inv_cfg["fit"]["global"]["enabled"] is False

    inverse_cfg["fit"]["global"] = {"enabled": True}
    explicit_solver = InverseSolver(case_cfg, inverse_cfg)
    assert explicit_solver.inv_cfg["fit"]["global"]["enabled"] is True


def test_default_fit_skips_post_fit_scientific_audits(monkeypatch: pytest.MonkeyPatch) -> None:
    solver = _absolute_solver()

    def unexpected_audit(*_args, **_kwargs):
        raise AssertionError("the default fit path must not run scientific audits")

    monkeypatch.setattr(optimize_module, "finite_difference_jacobian", unexpected_audit)
    monkeypatch.setattr(optimize_module, "evaluate_parameter_profiles", unexpected_audit)

    result = solver.fit()

    assert result.success
    assert result.identifiability is None
    assert result.uncertainty is None
    assert result.forward_quality is None
    assert result.parameter_profiles is None
    assert result.parameters["electron_density_m3"] == pytest.approx(3.0e16)


def test_audit_adds_configured_results_without_changing_optimum_or_cost() -> None:
    solver = _absolute_solver()
    core = solver.fit()

    audited = solver.audit_fit(core)

    assert audited is not core
    assert np.array_equal(audited.x_opt, core.x_opt)
    assert audited.case_opt == core.case_opt
    assert audited.cost == core.cost
    assert audited.success == core.success
    assert audited.message == core.message
    assert core.identifiability is None
    assert core.uncertainty is None
    assert audited.identifiability is not None
    assert audited.uncertainty is not None
    assert audited.forward_quality is not None
    assert audited.forward_quality["status"] == "pass"


def test_runtime_parameters_reuse_compiled_plan(monkeypatch: pytest.MonkeyPatch) -> None:
    solver = _absolute_solver()

    def unexpected_compile(*_args, **_kwargs):
        raise AssertionError("runtime-only inverse parameters must not rebuild the compiled plan")

    monkeypatch.setattr("oescr.forward.model.compile_case", unexpected_compile)

    result = solver.fit()

    assert result.success


def test_runtime_objective_reuses_static_preparation_without_changing_residuals(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    solver = _absolute_solver()
    assert solver._objective_plan is not None
    x = solver.params.initial_vector(solver.case_cfg)
    runtime_case = deepcopy(solver.case_cfg)
    solver.params.apply_to_case(runtime_case, x)
    expected, _ = objectives_module.residual_vector(
        solver._residual_model,
        runtime_case,
        solver.inv_cfg,
        solver.measurements,
        solver.windows,
        collect_details=False,
    )

    def unexpected_static_preparation(*_args, **_kwargs):
        raise AssertionError("static objective preparation must not repeat")

    monkeypatch.setattr(
        objectives_module,
        "_compile_objective_plan",
        unexpected_static_preparation,
    )

    first = solver._objective_residual(x)
    second = solver._objective_residual(x)

    assert np.array_equal(first, expected)
    assert np.array_equal(second, expected)


@pytest.mark.parametrize(
    ("root", "path"),
    [
        ("diagnostics", "diagnostics.convergence.warn_relative_above"),
        ("metadata", "metadata.dummy"),
    ],
)
def test_reporting_only_parameter_paths_are_rejected(root: str, path: str) -> None:
    case_cfg = load_yaml(EXAMPLE_DIR / "case_absolute_init.yaml")
    inverse_cfg = load_yaml(EXAMPLE_DIR / "inverse_absolute.yaml")
    if root == "diagnostics":
        case_cfg.setdefault("diagnostics", {})["convergence"] = {
            "enabled": False,
            "warn_relative_above": 1.0e-3,
        }
    else:
        case_cfg.setdefault(root, {})["dummy"] = 1.0
    inverse_cfg["parameters"] = [
        {
            "name": "flat_parameter",
            "path": path,
            "bounds": [0.1, 10.0],
        }
    ]

    with pytest.raises(ConfigSemanticError, match="reporting-only path"):
        InverseSolver(case_cfg, inverse_cfg)
