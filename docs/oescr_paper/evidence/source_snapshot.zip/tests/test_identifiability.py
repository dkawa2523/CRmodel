from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

import oescr.inverse.identifiability as identifiability_module
from oescr.inverse.identifiability import (
    summarize_identifiability_jacobian,
    summarize_jacobian,
)
from oescr.inverse.objectives import residual_vector
from oescr.inverse.optimize import InverseSolver
from oescr.inverse.params import ParameterSet
from oescr.io.yaml_loader import load_yaml

ROOT = Path(__file__).resolve().parents[1]


def test_audit_derivative_stays_inside_a_parameter_bound(monkeypatch) -> None:
    def bounded_residual(_model, case, *_args, **_kwargs):
        value = case["fraction"]
        if not 0.0 <= value <= 1.0:
            raise ValueError("mixture fraction must stay within its physical bounds")
        return np.asarray([value**2]), {}

    monkeypatch.setattr(identifiability_module, "residual_vector", bounded_residual)
    parameters = ParameterSet([{"name": "fraction", "path": "fraction", "bounds": [0.0, 1.0]}])

    jacobian = identifiability_module.finite_difference_jacobian(None, {"fraction": 1.0}, {}, {}, [], parameters)

    assert jacobian.item() == pytest.approx(2.0, rel=1.0e-4)


def test_tall_spectrum_jacobian_does_not_allocate_a_square_pixel_basis(monkeypatch) -> None:
    original_svd = np.linalg.svd
    allocated_left_sizes = []

    def recorded_svd(matrix, *args, **kwargs):
        result = original_svd(matrix, *args, **kwargs)
        allocated_left_sizes.append(result[0].size)
        return result

    monkeypatch.setattr(np.linalg, "svd", recorded_svd)
    summary = summarize_jacobian(np.column_stack([np.ones(1000), np.linspace(0.0, 1.0, 1000)]))

    assert summary["rank_estimate"] == 2
    assert max(allocated_left_sizes) <= 2000

    wide = summarize_jacobian(np.asarray([[1.0, 1.0, 0.0]]))
    assert wide["rank_estimate"] == 1
    assert len(wide["singular_directions"]) == 3


def test_singular_directions_name_the_unobservable_parameter_combination() -> None:
    jacobian = np.asarray([[1.0, 1.0], [2.0, 2.0]])

    summary = summarize_jacobian(jacobian, parameter_names=["te", "density"])

    assert summary["rank_estimate"] == 1
    assert summary["n_parameters"] == 2
    assert summary["condition_number"] == float("inf")
    weak = summary["singular_directions"][-1]
    assert weak["identifiable"] is False
    assert weak["singular_value"] == pytest.approx(0.0, abs=1.0e-12)
    assert {item["name"] for item in weak["dominant_parameters"]} == {"te", "density"}


def test_measurement_observability_excludes_priors_and_regularization() -> None:
    benchmark = ROOT / "examples" / "benchmarks" / "cl2_ar_icp_fuller2001"
    solver = InverseSolver.from_yaml(benchmark / "case_init.yaml", benchmark / "inverse.yaml")

    data_residual, _ = residual_vector(
        solver.model,
        solver.case_cfg,
        solver.inv_cfg,
        solver.measurements,
        solver.windows,
        include_constraints=False,
    )
    objective_residual, _ = residual_vector(
        solver.model,
        solver.case_cfg,
        solver.inv_cfg,
        solver.measurements,
        solver.windows,
        include_constraints=True,
    )

    assert len(data_residual) > 0
    assert len(objective_residual) > len(data_residual)


def test_parameter_name_count_must_match_jacobian_columns() -> None:
    with pytest.raises(ValueError, match="parameter names"):
        summarize_jacobian(np.eye(2), parameter_names=["only_one"])


def test_nuisance_projection_removes_collinear_target_direction() -> None:
    jacobian = np.asarray([[1.0, 1.0], [2.0, 2.0], [3.0, 3.0]])

    summary = summarize_identifiability_jacobian(
        jacobian,
        parameter_names=["target", "scale"],
        parameter_roles=["target", "nuisance"],
    )

    assert summary["rank_estimate"] == 1  # Backward-compatible full-J summary.
    assert summary["projected_target"]["rank_estimate"] == 0
    assert summary["projected_target"]["inactive_parameters"] == ["target"]
    assert summary["nuisance_projection"]["rank"] == 1
    assert summary["nuisance_projection"]["method"] == "svd_orthogonal_complement"


def test_nuisance_projection_preserves_orthogonal_target_direction() -> None:
    jacobian = np.asarray([[1.0, 0.0], [0.0, 1.0]])

    summary = summarize_identifiability_jacobian(
        jacobian,
        parameter_names=["target", "offset"],
        parameter_roles=["target", "nuisance"],
    )

    assert summary["projected_target"]["rank_estimate"] == 1
    assert summary["projected_target"]["singular_values"] == pytest.approx([1.0])


def test_no_nuisance_projection_matches_existing_summary() -> None:
    jacobian = np.asarray([[1.0, 0.2], [0.1, 2.0], [0.5, -0.3]])
    existing = summarize_jacobian(jacobian, parameter_names=["te", "ne"])

    summary = summarize_identifiability_jacobian(
        jacobian,
        parameter_names=["te", "ne"],
        parameter_roles=["target", "target"],
    )

    assert summary["projected_target"] == existing
    assert summary["nuisance_projection"] == {
        "method": "identity_no_explicit_nuisance",
        "rank": 0,
        "rank_threshold": 0.0,
        "n_columns": 0,
    }


def test_solver_reports_explicit_nuisance_projected_identifiability() -> None:
    example = ROOT / "examples" / "use_cases" / "two_band"
    case_cfg = load_yaml(example / "case_absolute_init.yaml")
    inv_cfg = load_yaml(example / "inverse_absolute.yaml")
    inv_cfg["parameters"][0]["role"] = "target"
    inv_cfg["parameters"].append(
        {
            "name": "target_density_scale",
            "path": "plasma_state.radicals.Target[0]",
            "scale": "log",
            "role": "nuisance",
            "bounds": [5.0e17, 4.0e18],
        }
    )

    fit = InverseSolver(case_cfg, inv_cfg).fit(audit=True)

    assert fit.success
    assert fit.identifiability is not None
    assert fit.identifiability["target_parameter_names"] == ["electron_density_m3"]
    assert fit.identifiability["nuisance_parameter_names"] == ["target_density_scale"]
    assert fit.identifiability["projected_target"]["rank_estimate"] == 1
    assert fit.identifiability["nuisance_projection"]["rank"] == 1
    handling = fit.identifiability["implicit_nuisance_handling"]
    assert handling["auto_gain_offset_tilt"]["explicit_projection_columns_added"] is False
    assert handling["shared_calibration_covariance"]["handling"] == ("prewhitened_in_measurement_residual")
