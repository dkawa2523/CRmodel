from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest
from scripts.run_common_state_benchmarks import (
    CASES,
    BenchmarkCase,
    _acceptance_assessment,
    run_case,
)

from oescr.forward.model import OESCRModel
from oescr.inverse.objectives import residual_vector
from oescr.inverse.optimize import InverseSolver
from oescr.inverse.reporting import load_fit_result
from oescr.io.yaml_loader import load_yaml

ROOT = Path(__file__).resolve().parents[1]
BENCHMARK_ROOT = ROOT / "examples" / "benchmarks"


@pytest.mark.parametrize(
    ("directory_name", "spectrum_count", "state_count"),
    [
        ("common_state_ar_o2", 5, 3),
        ("common_state_ar_cl2", 7, 5),
    ],
)
def test_common_state_cases_are_valid_and_share_two_parameters(
    directory_name: str,
    spectrum_count: int,
    state_count: int,
) -> None:
    directory = BENCHMARK_ROOT / directory_name
    for filename in ("case_truth.yaml", "case_init.yaml"):
        raw = load_yaml(directory / filename)
        normalized = OESCRModel(raw).cfg
        assert normalized["geometry"]["n_shells"] == 1
        assert len(normalized["states"]) == state_count
        assert len(normalized["instruments"]) == spectrum_count

    solver = InverseSolver.from_yaml(directory / "case_init.yaml", directory / "inverse.yaml")
    assert solver.params.names() == ["electron_temperature_eV", "electron_density_m3"]
    assert set(solver.measurements) == {item["id"] for item in solver.model.instrument_configs_for()}
    assert all(len(items) == 1 for items in solver.measurements.values())


def test_ar_o2_uses_canonical_maxwellian_eedf_as_single_temperature_owner() -> None:
    directory = BENCHMARK_ROOT / "common_state_ar_o2"
    truth = load_yaml(directory / "case_truth.yaml")
    initial = load_yaml(directory / "case_init.yaml")
    solver = InverseSolver.from_yaml(directory / "case_init.yaml", directory / "inverse.yaml")

    for case in (truth, initial, solver.case_cfg):
        assert case["eedf"]["kind"] == "te_maxwell"
        assert "plasma_mode" not in case
        assert "te_shells_eV" not in case["plasma_state"]
        assert "te_eedf_kind" not in case["plasma_state"]
    assert truth["eedf"]["zones"][0]["te_eV"] == pytest.approx(3.5)
    assert initial["eedf"]["zones"][0]["te_eV"] == pytest.approx(2.8)
    assert solver.params.params[0].path == "eedf.zones[0].te_eV"


@pytest.mark.parametrize("directory_name", ["common_state_ar_o2", "common_state_ar_cl2"])
def test_initial_spectra_are_visibly_separated_from_truth(directory_name: str) -> None:
    directory = BENCHMARK_ROOT / directory_name
    truth = OESCRModel.from_yaml(directory / "case_truth.yaml").predict()
    initial = OESCRModel.from_yaml(directory / "case_init.yaml").predict()
    error = 0.0
    reference = 0.0
    for instrument_id, chord_map in truth.spectra.items():
        truth_intensity = np.asarray(chord_map["chord_0"]["intensity"], dtype=float)
        initial_intensity = np.asarray(initial.spectra[instrument_id]["chord_0"]["intensity"], dtype=float)
        error += float(np.sum((initial_intensity - truth_intensity) ** 2))
        reference += float(np.sum(truth_intensity**2))
    nrmse = np.sqrt(error / reference)
    assert 0.25 < nrmse < 0.60


def test_cl_pack_declares_effective_emitter_limit() -> None:
    pack = load_yaml(ROOT / "examples" / "data" / "species_packs" / "cl_effective_lines.yaml")
    assert "Illustrative only" in pack["metadata"]["evidence"]
    assert "not assignments of the physical Cl I upper levels" in pack["metadata"]["limitation"]
    assert len(pack["states"]) == 3
    assert len(pack["reactions"]) == 3
    assert len(pack["transitions"]) == 3

    registry = load_yaml(BENCHMARK_ROOT / "common_state_ar_cl2" / "windows.yaml")
    cl_windows = [window for window in registry["windows"] if window["family"].startswith("Cl")]
    assert cl_windows
    assert all(window["analysis_role"] == "score" for window in cl_windows)
    assert all(window["model_coverage"] == "empirical" for window in cl_windows)
    assert all(window["evidence_status"] == "illustrative" for window in cl_windows)


def test_benchmark_distinguishes_fit_kernels_from_modeled_pathways() -> None:
    counts = {
        case.key: (len(case.fit_excitation_kernel_ids), len(case.modeled_pathway_ids))
        for case in CASES
    }

    assert counts == {"ar_o2": (3, 3), "ar_cl2": (2, 5)}


@pytest.mark.parametrize("cross_check", [False, True])
def test_acceptance_assessment_records_each_failed_gate(cross_check: bool) -> None:
    errors = {
        "oescr": {"te_relative": 0.01, "ne_relative": 0.06},
    }
    if cross_check:
        errors["cma"] = {"te_relative": 0.01, "ne_relative": 0.06}
    assessment = _acceptance_assessment(
        fit_success=True,
        target_full_rank=True,
        errors=errors,
        held_out_truth_nrmse={method: 0.02 for method in errors},
        numerical_difference=0.001,
    )

    assert not assessment["passed"]
    assert not assessment["checks"]["oescr_ne_relative"]["passed"]
    if cross_check:
        assert not assessment["checks"]["cma_ne_relative"]["passed"]
    assert assessment["checks"]["oescr_held_out_truth_nrmse"]["passed"]
    assert assessment["checks"]["projected_target_jacobian_full_rank"]["passed"]


def test_common_state_runner_writes_the_standard_fit_bundle(tmp_path: Path) -> None:
    result = run_case(CASES[0], tmp_path)
    persisted = load_fit_result(tmp_path / result["fit_result"])
    assert result["status"] == "pass"
    assert persisted["parameters"] == result["parameters"]["oescr"]
    assert (tmp_path / CASES[0].key / "case_opt.yaml").is_file()
    assert len(persisted["spectral_fits"]) == len(CASES[0].feature_labels)
    assert set(result["objective"]) == {"oescr"}


@pytest.mark.parametrize("case", CASES, ids=lambda item: item.key)
def test_common_state_score_spectra_are_excluded_from_optimization(case: BenchmarkCase) -> None:
    solver = InverseSolver.from_yaml(case.init_path, case.inverse_path)
    _residual, aux = residual_vector(
        solver.model,
        solver.case_cfg,
        solver.inv_cfg,
        solver.measurements,
        solver.windows,
        include_constraints=False,
    )
    selected_by_instrument = {
        instrument_id: selection["selected_count"]
        for (instrument_id, _measurement_id), selection in aux["fit_pixel_selection"].items()
    }
    fit_ids = set(case.feature_labels).difference(case.held_out_spectra)

    assert set(solver.measurements) == set(case.feature_labels)
    assert all(selected_by_instrument[item] == 0 for item in case.held_out_spectra)
    assert all(selected_by_instrument[item] > 0 for item in fit_ids)
    assert all(aux["fit_windows"][item] == [] for item in case.held_out_spectra)
