from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from oescr.inverse.optimize import InverseSolver
from oescr.inverse.params import ParameterSet
from oescr.inverse.profiles import evaluate_parameter_profiles
from oescr.io.validators import ConfigSemanticError
from oescr.io.yaml_loader import load_yaml

ROOT = Path(__file__).resolve().parents[1]


def test_profile_reoptimizes_remaining_parameter_on_quadratic_problem() -> None:
    params = ParameterSet(
        [
            {"name": "target", "path": "unused.target", "bounds": [0.0, 2.0]},
            {
                "name": "nuisance",
                "path": "unused.nuisance",
                "bounds": [-5.0, 5.0],
                "role": "nuisance",
            },
        ]
    )

    def residual(x: np.ndarray) -> np.ndarray:
        return np.asarray([x[0] - 1.0, x[1] - 2.0 * x[0]])

    summary = evaluate_parameter_profiles(
        residual,
        params,
        np.asarray([0.2, 0.0]),
        {
            "max_nfev": 50,
            "parameters": [{"name": "target", "range": [0.0, 2.0], "points": 5}],
        },
    )

    rows = {row["value"]: row for row in summary["profiles"]["target"]["points"]}
    assert rows[1.0]["delta_measurement_sum_squares"] == pytest.approx(0.0, abs=1.0e-12)
    assert rows[0.0]["delta_measurement_sum_squares"] == pytest.approx(1.0)
    assert rows[2.0]["delta_measurement_sum_squares"] == pytest.approx(1.0)
    assert rows[2.0]["conditional_parameters"]["nuisance"] == pytest.approx(4.0)
    assert summary["constraints_included"] is False
    assert "loss" not in summary["reference"]


def test_profile_is_flat_when_target_is_confounded_with_nuisance() -> None:
    params = ParameterSet(
        [
            {"name": "target", "path": "unused.target", "bounds": [0.0, 2.0]},
            {
                "name": "nuisance",
                "path": "unused.nuisance",
                "bounds": [-5.0, 5.0],
                "role": "nuisance",
            },
        ]
    )

    summary = evaluate_parameter_profiles(
        lambda x: np.asarray([x[0] + x[1] - 1.0]),
        params,
        np.asarray([0.5, 0.5]),
        {
            "max_nfev": 50,
            "parameters": [{"name": "target", "range": [0.0, 2.0], "points": 5}],
        },
    )

    deltas = [
        row["delta_measurement_sum_squares"]
        for row in summary["profiles"]["target"]["points"]
    ]
    assert max(deltas) == pytest.approx(0.0, abs=1.0e-18)


def test_profiles_share_reference_after_grid_finds_better_local_basin() -> None:
    params = ParameterSet(
        [
            {"name": "x", "path": "unused.x", "bounds": [-1.0, 3.0]},
            {"name": "y", "path": "unused.y", "bounds": [-2.0, 2.0]},
        ]
    )

    def residual(values: np.ndarray) -> np.ndarray:
        x, y = values
        local_basin = (x - 2.0) * (-x * x - x - 2.0)
        return np.asarray([local_basin, y])

    summary = evaluate_parameter_profiles(
        residual,
        params,
        np.asarray([0.0, 1.0]),
        {
            "max_nfev": 100,
            "parameters": [
                {"name": "x", "range": [-1.0, 3.0], "points": 5},
                {"name": "y", "range": [-1.0, 1.0], "points": 5},
            ],
        },
    )

    assert summary["reference"]["parameters"] == pytest.approx({"x": 2.0, "y": 0.0})
    assert summary["reference"]["refinement_count"] == 1
    assert summary["reference"]["source"].endswith(":x")
    assert min(
        row["delta_measurement_sum_squares"]
        for row in summary["profiles"]["x"]["points"]
    ) == pytest.approx(0.0)
    assert min(
        row["delta_measurement_sum_squares"]
        for row in summary["profiles"]["y"]["points"]
    ) == pytest.approx(0.0)
    y_reference = min(
        summary["profiles"]["y"]["points"],
        key=lambda row: abs(float(row["value"])),
    )
    assert y_reference["conditional_parameters"]["x"] == pytest.approx(2.0)
    assert y_reference["delta_measurement_sum_squares"] == pytest.approx(0.0)


def test_profile_marks_reference_inserted_outside_configured_range() -> None:
    params = ParameterSet(
        [{"name": "target", "path": "unused.target", "bounds": [0.0, 3.0]}]
    )

    summary = evaluate_parameter_profiles(
        lambda values: np.asarray([values[0]]),
        params,
        np.asarray([0.0]),
        {
            "parameters": [
                {"name": "target", "range": [1.0, 2.0], "points": 5}
            ]
        },
    )

    profile = summary["profiles"]["target"]
    assert profile["configured_range"] == [1.0, 2.0]
    assert profile["effective_range"] == pytest.approx([0.0, 2.0], abs=1.0e-8)
    assert profile["reference_value"] == pytest.approx(0.0, abs=1.0e-8)
    assert profile["reference_inside_configured_range"] is False
    reference_rows = [row for row in profile["points"] if row["is_reference"]]
    assert len(reference_rows) == 1
    assert reference_rows[0]["point_source"] == "inserted_reference"
    assert all(
        row["point_source"] == "configured_grid"
        for row in profile["points"]
        if not row["is_reference"]
    )


def test_profile_rejects_non_finite_residual() -> None:
    params = ParameterSet(
        [{"name": "target", "path": "unused.target", "bounds": [0.0, 2.0]}]
    )

    def residual(values: np.ndarray) -> np.ndarray:
        return np.asarray([np.nan if values[0] == 0.0 else values[0] - 1.0])

    with pytest.raises(ValueError, match="residual must contain only finite values"):
        evaluate_parameter_profiles(
            residual,
            params,
            np.asarray([1.0]),
            {
                "parameters": [
                    {"name": "target", "range": [0.0, 2.0], "points": 5}
                ]
            },
        )


def test_solver_emits_explicit_measurement_only_profile() -> None:
    example = ROOT / "examples" / "use_cases" / "two_band"
    case_cfg = load_yaml(example / "case_absolute_init.yaml")
    inv_cfg = load_yaml(example / "inverse_absolute.yaml")
    inv_cfg["fit"]["profile"] = {
        "enabled": True,
        "max_nfev": 40,
        "parameters": [
            {
                "name": "electron_density_m3",
                "range": [5.0e15, 6.0e16],
                "points": 5,
            }
        ],
    }

    fit = InverseSolver(case_cfg, inv_cfg).fit(audit=True)

    assert fit.success
    assert fit.parameter_profiles is not None
    assert fit.parameter_profiles["basis"] == "measurement_data_only"
    profile = fit.parameter_profiles["profiles"]["electron_density_m3"]
    assert profile["scale"] == "log"
    assert len(profile["points"]) >= 5
    assert min(row["delta_measurement_sum_squares"] for row in profile["points"]) == pytest.approx(
        0.0,
        abs=1.0e-10,
    )


def test_profile_audit_does_not_require_svd_audit() -> None:
    example = ROOT / "examples" / "use_cases" / "two_band"
    case_cfg = load_yaml(example / "case_absolute_init.yaml")
    inv_cfg = load_yaml(example / "inverse_absolute.yaml")
    inv_cfg["fit"]["identifiability"] = {"enabled": False}
    inv_cfg["fit"]["uncertainty"] = {"laplace": False}
    inv_cfg["fit"]["profile"] = {
        "enabled": True,
        "max_nfev": 40,
        "parameters": [
            {
                "name": "electron_density_m3",
                "range": [5.0e15, 6.0e16],
                "points": 5,
            }
        ],
    }

    fit = InverseSolver(case_cfg, inv_cfg).fit(audit=True)

    assert fit.identifiability is None
    assert fit.parameter_profiles is not None


def test_profile_rejects_nuisance_parameter_as_scan_axis() -> None:
    example = ROOT / "examples" / "use_cases" / "two_band"
    case_cfg = load_yaml(example / "case_absolute_init.yaml")
    inv_cfg = load_yaml(example / "inverse_absolute.yaml")
    inv_cfg["parameters"][0]["role"] = "nuisance"
    inv_cfg["fit"]["profile"] = {
        "enabled": True,
        "parameters": [
            {
                "name": "electron_density_m3",
                "range": [5.0e15, 6.0e16],
                "points": 5,
            }
        ],
    }

    with pytest.raises(ConfigSemanticError, match="role='target'"):
        InverseSolver(case_cfg, inv_cfg)


def test_profile_rejects_scan_range_outside_parameter_bounds() -> None:
    example = ROOT / "examples" / "use_cases" / "two_band"
    case_cfg = load_yaml(example / "case_absolute_init.yaml")
    inv_cfg = load_yaml(example / "inverse_absolute.yaml")
    inv_cfg["fit"]["profile"] = {
        "enabled": True,
        "parameters": [
            {
                "name": "electron_density_m3",
                "range": [1.0e15, 7.0e16],
                "points": 5,
            }
        ],
    }

    with pytest.raises(ConfigSemanticError, match="inside its fitted bounds"):
        InverseSolver(case_cfg, inv_cfg)


@pytest.mark.parametrize("non_finite", [float("nan"), float("inf"), float("-inf")])
def test_profile_rejects_non_finite_scan_range(non_finite: float) -> None:
    example = ROOT / "examples" / "use_cases" / "two_band"
    case_cfg = load_yaml(example / "case_absolute_init.yaml")
    inv_cfg = load_yaml(example / "inverse_absolute.yaml")
    inv_cfg["fit"]["profile"] = {
        "enabled": True,
        "parameters": [
            {
                "name": "electron_density_m3",
                "range": [non_finite, 6.0e16],
                "points": 5,
            }
        ],
    }

    with pytest.raises(ConfigSemanticError, match="profile range must be finite"):
        InverseSolver(case_cfg, inv_cfg)


@pytest.mark.parametrize("non_finite", [float("nan"), float("inf"), float("-inf")])
def test_profile_rejects_non_finite_parameter_bounds(non_finite: float) -> None:
    example = ROOT / "examples" / "use_cases" / "two_band"
    case_cfg = load_yaml(example / "case_absolute_init.yaml")
    inv_cfg = load_yaml(example / "inverse_absolute.yaml")
    inv_cfg["parameters"][0]["bounds"] = [5.0e15, non_finite]

    with pytest.raises(ConfigSemanticError, match="Parameter bounds must be finite"):
        InverseSolver(case_cfg, inv_cfg)


def test_inverse_rejects_non_positive_log_parameter_bounds() -> None:
    example = ROOT / "examples" / "use_cases" / "two_band"
    case_cfg = load_yaml(example / "case_absolute_init.yaml")
    inv_cfg = load_yaml(example / "inverse_absolute.yaml")
    inv_cfg["parameters"][0]["bounds"] = [0.0, 6.0e16]

    with pytest.raises(ConfigSemanticError, match="bounds must be positive"):
        InverseSolver(case_cfg, inv_cfg)


def test_profile_rejects_target_and_nuisance_with_same_case_path() -> None:
    example = ROOT / "examples" / "use_cases" / "two_band"
    case_cfg = load_yaml(example / "case_absolute_init.yaml")
    inv_cfg = load_yaml(example / "inverse_absolute.yaml")
    inv_cfg["parameters"].append(
        {
            "name": "same_state_nuisance",
            "path": "plasma_state.ne_shells_m3[0]",
            "scale": "log",
            "role": "nuisance",
            "bounds": [5.0e15, 6.0e16],
        }
    )
    inv_cfg["fit"]["profile"] = {
        "enabled": True,
        "parameters": [
            {
                "name": "electron_density_m3",
                "range": [5.0e15, 6.0e16],
                "points": 5,
            }
        ],
    }

    with pytest.raises(ConfigSemanticError, match="parameter paths must be unique"):
        InverseSolver(case_cfg, inv_cfg)
