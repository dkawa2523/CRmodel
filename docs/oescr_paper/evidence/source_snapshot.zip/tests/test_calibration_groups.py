from __future__ import annotations

from types import SimpleNamespace

import numpy as np
import pytest

import oescr.inverse.objectives as objectives_module
from oescr.analysis.benchmark_contract import measurement_sha256
from oescr.inverse.measurements import Measurement, load_measurements, spectrum_residual_blocks
from oescr.inverse.objectives import residual_vector


def _absolute_instrument() -> dict:
    return {
        "id": "uvvis",
        "wavelength_grid_nm": [500.0, 501.0],
        "throughput": 1.0,
        "lsf": {"kind": "gaussian", "fwhm_nm": 0.1},
        "baseline": {"kind": "constant", "offset": 0.0},
        "nuisance": {"gain": 1.0},
        "calibration": {
            "kind": "spectral_radiance",
            "absolute": True,
            "input_basis": "spectral_radiance",
            "output_unit": "W_m-2_sr-1_nm-1",
            "reference": "expected calibration",
            "relative_standard_uncertainty": 0.1,
        },
    }


def _write_absolute_measurement(path, first: float, second: float) -> None:
    path.write_text(
        "# output_basis: spectral_radiance_W_m-2_sr-1_nm-1\n"
        "# output_unit: W_m-2_sr-1_nm-1\n"
        "# calibration_reference: expected calibration\n"
        "wavelength_nm,intensity,sigma\n"
        f"500.0,{first},0.1\n"
        f"501.0,{second},0.1\n",
        encoding="utf-8",
    )


def test_group_whitening_matches_explicit_dense_covariance() -> None:
    first_covariance = np.asarray([[4.0, 1.0], [1.0, 3.0]])
    first = Measurement(
        wavelength_nm=np.asarray([500.0, 501.0]),
        intensity=np.asarray([10.0, 20.0]),
        covariance=first_covariance,
        calibration_relative_standard_uncertainty=0.1,
        calibration_group_id="shared",
        id="first",
    )
    second_sigma = np.asarray([0.5, 0.8, 0.6])
    second = Measurement(
        wavelength_nm=np.asarray([500.0, 501.0, 502.0]),
        intensity=np.asarray([5.0, 12.0, 8.0]),
        sigma=second_sigma,
        calibration_relative_standard_uncertainty=0.1,
        calibration_group_id="shared",
        id="second",
    )
    first_prediction = np.asarray([12.0, 19.0])
    second_prediction = np.asarray([4.0, 14.0, 8.5])

    blocks = spectrum_residual_blocks([(first, first_prediction), (second, second_prediction)])
    actual_quadratic = float(np.dot(np.concatenate(blocks), np.concatenate(blocks)))

    second_covariance = np.diag(second_sigma**2)
    base_covariance = np.block(
        [
            [first_covariance, np.zeros((2, 3))],
            [np.zeros((3, 2)), second_covariance],
        ]
    )
    measured = np.concatenate([first.intensity, second.intensity])
    delta = np.concatenate([first_prediction - first.intensity, second_prediction - second.intensity])
    calibration_direction = 0.1 * measured
    full_covariance = base_covariance + np.outer(calibration_direction, calibration_direction)
    expected_quadratic = float(delta @ np.linalg.solve(full_covariance, delta))

    assert actual_quadratic == pytest.approx(expected_quadratic)


def test_shared_calibration_group_does_not_shrink_like_independent_repeats() -> None:
    def measurement(measurement_id: str, group_id: str) -> Measurement:
        return Measurement(
            wavelength_nm=np.asarray([500.0]),
            intensity=np.asarray([10.0]),
            sigma=np.asarray([0.01]),
            calibration_relative_standard_uncertainty=0.1,
            calibration_group_id=group_id,
            id=measurement_id,
        )

    prediction = np.asarray([11.0])
    first = measurement("first", "shared")
    repeated = measurement("repeat", "shared")
    independent = measurement("independent", "separate")

    single = np.concatenate(spectrum_residual_blocks([(first, prediction)]))
    shared = np.concatenate(spectrum_residual_blocks([(first, prediction), (repeated, prediction)]))
    separate = np.concatenate(spectrum_residual_blocks([(first, prediction), (independent, prediction)]))

    assert np.dot(single, single) == pytest.approx(10_000.0 / 10_001.0)
    assert np.dot(shared, shared) == pytest.approx(20_000.0 / 20_001.0)
    assert np.dot(separate, separate) == pytest.approx(2.0 * 10_000.0 / 10_001.0)


def test_explicit_group_is_shared_across_instruments_in_objective() -> None:
    class MultiInstrumentModel:
        def __init__(self) -> None:
            self.instruments = []
            self.spectra = {}
            for instrument_id in ("left", "right"):
                instrument = _absolute_instrument()
                instrument["id"] = instrument_id
                self.instruments.append(instrument)
                self.spectra[instrument_id] = {
                    "chord_0": {
                        "wavelength_nm": np.asarray([500.0]),
                        "intensity": np.asarray([11.0]),
                    }
                }

        def predict(self, _case_cfg):
            return SimpleNamespace(spectra=self.spectra)

        def instrument_configs_for(self, _case_cfg=None):
            return self.instruments

    def measurement(measurement_id: str) -> Measurement:
        return Measurement(
            wavelength_nm=np.asarray([500.0]),
            intensity=np.asarray([10.0]),
            sigma=np.asarray([0.01]),
            calibration_relative_standard_uncertainty=0.1,
            calibration_group_id="common-standard",
            id=measurement_id,
            prediction_key="chord_0",
        )

    inverse = {
        "fit": {
            "objective": {
                "auto_gain_fit": False,
                "auto_offset_fit": False,
                "auto_gain_tilt_fit": False,
                "spectrum_weight": 1.0,
            }
        }
    }
    residual, _ = residual_vector(
        MultiInstrumentModel(),
        {},
        inverse,
        {"left": [measurement("left")], "right": [measurement("right")]},
        [],
    )

    assert np.dot(residual, residual) == pytest.approx(20_000.0 / 20_001.0)


def test_absolute_loader_uses_default_or_explicit_calibration_group(tmp_path) -> None:
    _write_absolute_measurement(tmp_path / "first.csv", 10.0, 20.0)
    _write_absolute_measurement(tmp_path / "second.csv", 11.0, 21.0)
    base_inverse = {
        "__base_dir__": str(tmp_path),
        "inference_mode": "calibrated_absolute",
        "measurements": [
            {
                "instrument_id": "uvvis",
                "files": ["first.csv", "second.csv"],
                "ids": ["first", "second"],
                "prediction_keys": ["chord_0", "chord_0"],
            }
        ],
    }

    default_loaded = load_measurements(base_inverse, [_absolute_instrument()])["uvvis"]
    assert {measurement.calibration_group_id for measurement in default_loaded} == {"uvvis:expected calibration"}

    explicit_inverse = {
        **base_inverse,
        "measurements": [{**base_inverse["measurements"][0], "calibration_group_id": "session-a"}],
    }
    explicit_loaded = load_measurements(explicit_inverse, [_absolute_instrument()])["uvvis"]
    assert {measurement.calibration_group_id for measurement in explicit_loaded} == {"session-a"}


def test_measurement_hash_includes_calibration_group() -> None:
    common = {
        "wavelength_nm": np.asarray([500.0]),
        "intensity": np.asarray([10.0]),
        "sigma": np.asarray([0.1]),
        "calibration_relative_standard_uncertainty": 0.1,
        "id": "measurement",
        "prediction_key": "chord_0",
    }
    first = Measurement(**common, calibration_group_id="session-a")
    second = Measurement(**common, calibration_group_id="session-b")

    assert measurement_sha256({"uvvis": [first]}) != measurement_sha256({"uvvis": [second]})


class _WindowlessObjectiveModel:
    def __init__(self) -> None:
        wavelength = np.asarray([500.0, 501.0])
        self.spectrum = {"chord_0": {"wavelength_nm": wavelength, "intensity": np.asarray([1.0, 2.0])}}
        self.instrument = _absolute_instrument()

    def predict(self, _case_cfg):
        return SimpleNamespace(spectra={"uvvis": self.spectrum})

    def instrument_configs_for(self, _case_cfg=None):
        return [self.instrument]


def test_disabled_window_objectives_skip_feature_computation(monkeypatch) -> None:
    def fail_if_called(*_args, **_kwargs):
        raise AssertionError("window feature maps should not be computed")

    monkeypatch.setattr(objectives_module, "compute_window_feature_maps", fail_if_called)
    measurement = Measurement(
        wavelength_nm=np.asarray([500.0, 501.0]),
        intensity=np.asarray([1.0, 2.0]),
        sigma=np.ones(2),
        id="measurement",
        prediction_key="chord_0",
    )
    inverse = {
        "fit": {
            "objective": {
                "auto_gain_fit": False,
                "auto_offset_fit": False,
                "auto_gain_tilt_fit": False,
                "spectrum_weight": 1.0,
                "window_fit_weight": 0.0,
                "area_weight": 0.0,
                "peak_weight": 0.0,
                "window_ratio_weight": 0.0,
            }
        }
    }
    windows = [{"name": "line", "center_nm": 500.5, "half_width_nm": 0.4}]

    residual, aux = residual_vector(
        _WindowlessObjectiveModel(),
        {},
        inverse,
        {"uvvis": [measurement]},
        windows,
    )

    assert residual.shape == (2,)
    aux_key = ("uvvis", "measurement")
    assert aux["skipped_windows_low_signal"][aux_key] == []
    assert aux["ratio_pairs_used"][aux_key] == []
    assert aux["feature_covariance_used"][aux_key] == []
