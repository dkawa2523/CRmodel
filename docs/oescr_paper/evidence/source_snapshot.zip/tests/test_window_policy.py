from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import Any

import numpy as np
import pytest

import oescr.inverse.objectives as objective_module
from oescr.inverse.gain_model import apply_gain_offset_tilt
from oescr.inverse.measurements import Measurement
from oescr.inverse.objectives import load_windows, residual_vector
from oescr.inverse.window_policy import (
    fit_pixel_mask,
    fit_windows,
    has_explicit_window_policy,
    resolve_window_policy,
    window_coverage_report,
    windows_for_analysis_role,
)
from oescr.io.normalize import normalize_inverse_config
from oescr.io.schema import validate_document
from oescr.io.yaml_loader import load_yaml, save_yaml


class _PolicyModel:
    def __init__(self) -> None:
        wavelength = np.asarray([499.5, 500.0, 500.5, 501.0, 501.5])
        self.spectra = {
            "uvvis": {
                "chord_0": {
                    "wavelength_nm": wavelength,
                    "intensity": np.ones_like(wavelength),
                }
            }
        }
        self.instrument = {
            "id": "uvvis",
            "wavelength_grid_nm": wavelength.tolist(),
            "throughput": 1.0,
            "lsf": {"kind": "gaussian", "fwhm_nm": 0.1},
            "baseline": {"kind": "constant", "offset": 0.0},
            "nuisance": {"gain": 1.0},
        }

    def predict(self, _case_cfg: dict[str, object]) -> SimpleNamespace:
        return SimpleNamespace(spectra=self.spectra)

    def instrument_configs_for(self, _case_cfg: dict[str, object]) -> list[dict[str, object]]:
        return [self.instrument]


def _measurement_with_score_value(score_value: float) -> Measurement:
    return Measurement(
        wavelength_nm=np.asarray([499.5, 500.0, 500.5, 501.0, 501.5]),
        intensity=np.asarray([9.0, 2.0, 9.0, score_value, 9.0]),
        sigma=np.ones(5),
        id="measurement",
        prediction_key="chord_0",
    )


def _spectrum_only_inverse(*, auto_gain: bool) -> dict[str, Any]:
    return {
        "fit": {
            "objective": {
                "auto_gain_fit": auto_gain,
                "auto_offset_fit": False,
                "auto_gain_tilt_fit": False,
                "spectrum_weight": 1.0,
                "window_fit_weight": 0.0,
                "area_weight": 0.0,
                "peak_weight": 0.0,
                "window_ratio_weight": 0.0,
            }
        }
    }


def _window(name: str, center_nm: float, **policy: str) -> dict[str, object]:
    return {
        "name": name,
        "center_nm": center_nm,
        "half_width_nm": 0.2,
        **policy,
    }


def _case_with_kernel_window(tmp_path: Path, window: dict) -> dict:
    registry = tmp_path / "windows.yaml"
    save_yaml({"windows": [window]}, registry)
    return {
        "__base_dir__": str(tmp_path),
        "diagnostics": {"window_registry": registry.name},
        "states": [{"id": "upper", "energy_eV": 1.0}],
        "reactions": [{"id": "process", "target_state": "upper"}],
        "transitions": [
            {
                "id": "line",
                "upper": "upper",
                "lower": "ground",
                "wavelength_nm": 500.0,
            },
            {
                "id": "other_line",
                "upper": "upper",
                "lower": "ground",
                "wavelength_nm": 501.0,
            },
        ],
        "emission_kernels": [
            {
                "id": "kernel",
                "upper_state": "upper",
                "process_ids": ["process"],
                "transition_ids": ["line"],
                "pathway": "direct_ground",
                "evidence": {
                    "status": "illustrative",
                    "reference": "Unit-test declaration",
                    "limitations": [],
                },
            }
        ],
    }


def test_legacy_registry_preserves_full_spectrum_selection() -> None:
    windows = [_window("Ar_750", 750.4)]

    policy = resolve_window_policy(windows[0])
    report = window_coverage_report(windows)

    assert policy.analysis_role == "fit"
    assert policy.model_coverage == "physical"
    assert policy.evidence_status == "illustrative"
    assert policy.contributes_to_fit
    assert not policy.explicit
    assert fit_pixel_mask(np.asarray([700.0, 750.4, 800.0]), windows) is None
    assert report["selection_mode"] == "legacy_full_spectrum"

    evidence_only = [_window("Ar_750", 750.4, evidence_status="qualified")]
    assert fit_pixel_mask(np.asarray([700.0, 750.4, 800.0]), evidence_only) is None


def test_explicit_policy_masks_to_physical_fit_window_union() -> None:
    windows = [
        _window(
            "Ar_fit",
            750.4,
            analysis_role="fit",
            model_coverage="physical",
            evidence_status="literature_anchored",
        ),
        _window(
            "O_score",
            777.4,
            analysis_role="score",
            model_coverage="physical",
            evidence_status="validation_candidate",
        ),
        _window(
            "continuum_monitor",
            800.0,
            analysis_role="qc",
            model_coverage="empirical",
            evidence_status="qualified",
        ),
    ]
    wavelength = np.asarray([750.1, 750.4, 750.7, 777.4, 800.0])

    mask = fit_pixel_mask(wavelength, windows)
    report = window_coverage_report(windows)

    assert mask is not None
    assert mask.tolist() == [False, True, False, False, False]
    assert [window["name"] for window in fit_windows(windows)] == ["Ar_fit"]
    assert [window["name"] for window in windows_for_analysis_role(windows, "score")] == ["O_score"]
    assert report["selection_mode"] == "window_union"
    assert report["fit_window_count"] == 1
    assert report["windows"][1]["fit_exclusion_reason"] == "analysis_role=score"
    assert report["windows"][2]["fit_exclusion_reason"] == "analysis_role=qc"


def test_explicit_registry_with_no_instrument_windows_selects_no_pixels() -> None:
    mask = fit_pixel_mask(
        np.asarray([500.0, 501.0]),
        [],
        selection_mode="window_union",
    )

    assert mask is not None
    assert not np.any(mask)
    assert window_coverage_report([], selection_mode="window_union")["selection_mode"] == ("window_union")


def test_canonical_full_spectrum_mode_is_reported_without_legacy_label() -> None:
    windows = [_window("fit", 500.0, analysis_role="fit", model_coverage="physical")]
    inverse = _spectrum_only_inverse(auto_gain=False)
    inverse["window_selection"] = {"mode": "full_spectrum"}

    residual, aux = residual_vector(
        _PolicyModel(),
        {},
        inverse,
        {"uvvis": [_measurement_with_score_value(20.0)]},
        windows,
    )

    assert residual.shape == (5,)
    assert aux["fit_pixel_selection"][("uvvis", "measurement")]["mode"] == ("full_spectrum")
    assert aux["window_coverage"]["uvvis"]["selection_mode"] == "full_spectrum"


def test_window_union_requires_a_registry() -> None:
    inverse = {
        "window_selection": {"mode": "window_union"},
        "measurements": [{"instrument_id": "uvvis"}],
        "parameters": [],
    }

    with pytest.raises(ValueError, match="'registry' is a required property"):
        validate_document(inverse, "inverse")


def test_score_pixels_do_not_affect_spectrum_residual_or_fitted_gain() -> None:
    windows = [
        _window("fit", 500.0, analysis_role="fit", model_coverage="physical"),
        _window("score", 501.0, analysis_role="score", model_coverage="physical"),
    ]
    inverse = _spectrum_only_inverse(auto_gain=True)

    first_residual, first_aux = residual_vector(
        _PolicyModel(),
        {},
        inverse,
        {"uvvis": [_measurement_with_score_value(20.0)]},
        windows,
    )
    second_residual, second_aux = residual_vector(
        _PolicyModel(),
        {},
        inverse,
        {"uvvis": [_measurement_with_score_value(2000.0)]},
        windows,
    )

    aux_key = ("uvvis", "measurement")
    assert first_residual.shape == (1,)
    assert np.array_equal(first_residual, second_residual)
    assert first_aux["gain_offset"][aux_key]["gain"] == pytest.approx(2.0)
    assert second_aux["gain_offset"][aux_key]["gain"] == pytest.approx(2.0)
    assert first_aux["fit_pixel_selection"][aux_key] == {
        "mode": "window_union",
        "selected_count": 1,
        "total_count": 5,
    }
    assert first_aux["fit_windows"]["uvvis"] == ["fit"]
    assert first_aux["selected_windows"]["uvvis"] == ["fit"]
    assert first_aux["declared_windows"]["uvvis"] == ["fit", "score"]
    assert first_aux["window_coverage"]["uvvis"]["windows"][1]["contributes_to_fit"] is False


def test_optimizer_path_can_skip_explanatory_details_without_changing_residual() -> None:
    windows = [
        _window("fit", 500.0, analysis_role="fit", model_coverage="physical"),
        _window("score", 501.0, analysis_role="score", model_coverage="physical"),
    ]
    arguments = (
        _PolicyModel(),
        {},
        _spectrum_only_inverse(auto_gain=True),
        {"uvvis": [_measurement_with_score_value(20.0)]},
        windows,
    )

    detailed_residual, detailed = residual_vector(*arguments)
    compact_residual, compact = residual_vector(*arguments, collect_details=False)

    assert np.array_equal(compact_residual, detailed_residual)
    assert detailed["fit_windows"]["uvvis"] == ["fit"]
    assert compact == {}


def test_final_objective_can_return_aligned_spectral_fit_record() -> None:
    measurement = _measurement_with_score_value(20.0)
    _residual, aux = residual_vector(
        _PolicyModel(),
        {},
        _spectrum_only_inverse(auto_gain=True),
        {"uvvis": [measurement]},
        [
            _window("fit", 500.0, analysis_role="fit", model_coverage="physical"),
            _window("score", 501.0, analysis_role="score", model_coverage="physical"),
        ],
        collect_spectral_fits=True,
    )

    records = aux["spectral_fits"]
    assert len(records) == 1
    record = records[0]
    assert record.observation_id == "measurement"
    assert np.array_equal(record.wavelength_nm, measurement.wavelength_nm)
    assert record.used_for_fit.tolist() == [False, True, False, False, False]
    assert record.predicted[1] == pytest.approx(measurement.intensity[1])


def test_measurement_pixels_bind_to_the_detector_grid_without_resampling() -> None:
    measurement = Measurement(
        np.asarray([499.500000003, 500.25, 501.5]),
        np.asarray([2.0, 999.0, 3.0]),
        sigma=np.ones(3),
        id="cropped",
        prediction_key="chord_0",
        pixel_status=np.asarray(["valid", "user_excluded", "valid"]),
    )
    inverse = _spectrum_only_inverse(auto_gain=False)
    residual, auxiliary = residual_vector(
        _PolicyModel(),
        {},
        inverse,
        {"uvvis": [measurement]},
        [],
        collect_spectral_fits=True,
    )

    assert residual == pytest.approx([-1.0, -2.0])
    predicted = auxiliary["spectral_fits"][0].predicted
    assert predicted[[0, 2]] == pytest.approx([1.0, 1.0])
    assert np.isnan(predicted[1])

    measurement.pixel_status = np.asarray(["valid", "valid", "valid"])
    with pytest.raises(ValueError, match="Instrument 'uvvis', measurement 'cropped'.*wavelength_grid_nm"):
        residual_vector(_PolicyModel(), {}, inverse, {"uvvis": [measurement]}, [])


def test_explicit_policy_rejects_globally_empty_fit_selection() -> None:
    score_only = [_window("score", 501.0, analysis_role="score", model_coverage="physical")]

    with pytest.raises(ValueError, match="selected no valid physical-fit pixels"):
        residual_vector(
            _PolicyModel(),
            {},
            _spectrum_only_inverse(auto_gain=False),
            {"uvvis": [_measurement_with_score_value(20.0)]},
            score_only,
        )

    measurement = _measurement_with_score_value(20.0)
    measurement.pixel_status = np.asarray(["invalid", "valid", "invalid", "invalid", "invalid"])
    inverse = _spectrum_only_inverse(auto_gain=False)
    inverse["fit"]["objective"].update(spectrum_weight=0.0, area_weight=1.0)
    with pytest.raises(ValueError, match="no effective measurement objective"):
        residual_vector(_PolicyModel(), {}, inverse, {"uvvis": [measurement]}, [_window("unmeasured", 501.0)])
    with pytest.raises(ValueError, match="no effective measurement objective"):
        residual_vector(_PolicyModel(), {}, inverse, {"uvvis": [measurement]}, [_window("single_sample", 500.0)])


def test_nuisance_gain_minimizes_the_whitened_spectrum_objective() -> None:
    measurement = _measurement_with_score_value(100.0)
    measurement.intensity = np.asarray([1.0, 100.0, 1.0e9, 100.0, 1.0])
    measurement.sigma = np.asarray([1.0, 100.0, 1.0, 100.0, 1.0])
    measurement.pixel_status = np.asarray(["valid", "valid", "spike", "valid", "valid"])
    inverse = _spectrum_only_inverse(auto_gain=True)

    residual, auxiliary = residual_vector(_PolicyModel(), {}, inverse, {"uvvis": [measurement]}, [])

    valid = measurement.pixel_status == "valid"
    weights = 1.0 / measurement.sigma[valid] ** 2
    expected_gain = float(np.sum(weights * measurement.intensity[valid]) / np.sum(weights))
    assert auxiliary["gain_offset"][("uvvis", "measurement")]["gain"] == pytest.approx(expected_gain)
    assert residual == pytest.approx((expected_gain - measurement.intensity[valid]) / measurement.sigma[valid])


def test_positive_gain_constraint_reoptimizes_the_offset() -> None:
    model = _PolicyModel()
    model.spectra["uvvis"]["chord_0"]["intensity"] = np.arange(1.0, 6.0)
    measurement = _measurement_with_score_value(2.0)
    measurement.intensity = np.arange(5.0, 0.0, -1.0)
    inverse = _spectrum_only_inverse(auto_gain=True)
    inverse["fit"]["objective"]["auto_offset_fit"] = True

    residual, auxiliary = residual_vector(model, {}, inverse, {"uvvis": [measurement]}, [])

    correction = auxiliary["gain_offset"][("uvvis", "measurement")]
    assert correction["gain"] < 1.0e-6
    assert correction["offset"] == pytest.approx(3.0, abs=1.0e-6)
    assert np.dot(residual, residual) == pytest.approx(10.0, abs=1.0e-6)


def test_disabled_inverse_correction_preserves_the_instrument_prediction() -> None:
    model = _PolicyModel()
    model.instrument["nuisance"]["gain"] = 2.5
    model.instrument["baseline"]["offset"] = 0.4
    model.spectra["uvvis"]["chord_0"]["intensity"] = np.arange(5.0) + 2.5
    measurement = _measurement_with_score_value(2.0)
    measurement.intensity = model.spectra["uvvis"]["chord_0"]["intensity"].copy()

    residual, auxiliary = residual_vector(
        model, {}, _spectrum_only_inverse(auto_gain=False), {"uvvis": [measurement]}, []
    )

    assert residual == pytest.approx(np.zeros(5))
    assert auxiliary["gain_offset"][("uvvis", "measurement")] == {"gain": 1.0, "tilt": 0.0, "offset": 0.0}


def test_gain_prior_participates_in_nuisance_minimization() -> None:
    from scipy.optimize import minimize_scalar

    measurement = _measurement_with_score_value(2.0)
    measurement.intensity = np.full(5, 2.0)
    inverse = _spectrum_only_inverse(auto_gain=True)
    inverse["fit"]["objective"].update(gain_prior_weight=100.0, gain_prior_target=1.0, gain_prior_sigma_log10=0.1)

    residual, auxiliary = residual_vector(_PolicyModel(), {}, inverse, {"uvvis": [measurement]}, [])
    expected = minimize_scalar(
        lambda gain: 5 * (gain - 2.0) ** 2 + 100 * (np.log10(gain) / 0.1) ** 2, bounds=(0.1, 3.0), method="bounded"
    )

    assert auxiliary["gain_offset"][("uvvis", "measurement")]["gain"] == pytest.approx(expected.x, rel=1.0e-5)
    assert np.dot(residual, residual) == pytest.approx(expected.fun)


def test_instrument_tilt_uses_one_axis_for_different_observation_ranges() -> None:
    model = _PolicyModel()
    first = Measurement(
        np.asarray([499.5, 500.0]), np.asarray([1.0, 2.0]), sigma=np.ones(2), id="first", prediction_key="chord_0"
    )
    second = Measurement(
        np.asarray([501.0, 501.5]), np.asarray([4.0, 5.0]), sigma=np.ones(2), id="second", prediction_key="chord_0"
    )
    inverse = _spectrum_only_inverse(auto_gain=True)
    inverse["fit"]["objective"].update(auto_gain_scope="instrument", auto_gain_tilt_fit=True)

    residual, auxiliary = residual_vector(
        model, {}, inverse, {"uvvis": [first, second]}, [], collect_spectral_fits=True
    )

    assert residual == pytest.approx(np.zeros(4), abs=1.0e-12)
    for record in auxiliary["spectral_fits"]:
        correction = auxiliary["gain_offset"][("uvvis", record.observation_id)]
        assert apply_gain_offset_tilt(record.wavelength_nm, np.ones(2), **correction) == pytest.approx(record.predicted)

    inverse["fit"]["objective"]["gain_tilt_prior_weight"] = 1.0
    baseline_residual, baseline = residual_vector(model, {}, inverse, {"uvvis": [first, second]}, [])
    with_excluded = Measurement(
        np.asarray([499.5, 500.0, 777.0]),
        np.asarray([1.0, 2.0, 999.0]),
        sigma=np.ones(3),
        id="first",
        prediction_key="chord_0",
        pixel_status=np.asarray(["valid", "valid", "user_excluded"]),
    )
    excluded_residual, excluded = residual_vector(model, {}, inverse, {"uvvis": [with_excluded, second]}, [])

    assert excluded_residual == pytest.approx(baseline_residual)
    assert excluded["gain_offset"] == baseline["gain_offset"]


def test_invalid_policy_is_rejected_even_when_schema_is_bypassed() -> None:
    with pytest.raises(ValueError, match="invalid analysis_role"):
        resolve_window_policy(_window("bad", 500.0, analysis_role="training"))

    with pytest.raises(ValueError, match="empirical or unmodeled windows"):
        has_explicit_window_policy(
            [
                _window("valid", 499.0, analysis_role="score"),
                _window(
                    "unsupported-fit",
                    500.0,
                    analysis_role="fit",
                    model_coverage="empirical",
                ),
            ]
        )


def test_window_policy_fields_are_schema_checked() -> None:
    validate_document(
        {
            "windows": [
                _window(
                    "Ar_750",
                    750.4,
                    analysis_role="score",
                    model_coverage="physical",
                    evidence_status="validation_candidate",
                )
            ]
        },
        "windows",
    )

    with pytest.raises(ValueError):
        validate_document(
            {"windows": [_window("bad", 500.0, model_coverage="unknown")]},
            "windows",
        )


def test_window_kernel_binding_loads_and_survives_coverage_reporting(tmp_path: Path) -> None:
    case_cfg = _case_with_kernel_window(
        tmp_path,
        _window(
            "line_window",
            500.0,
            kernel_id="kernel",
            transition_id="line",
        ),
    )

    windows = load_windows(case_cfg)
    report = window_coverage_report(windows)

    assert windows[0]["kernel_id"] == "kernel"
    assert windows[0]["transition_id"] == "line"
    assert report["windows"][0]["kernel_id"] == "kernel"
    assert report["windows"][0]["transition_id"] == "line"


def test_window_binding_reuses_compiled_kernel_inventory(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    case_cfg = _case_with_kernel_window(
        tmp_path,
        _window(
            "line_window",
            500.0,
            kernel_id="kernel",
            transition_id="line",
        ),
    )

    def unexpected_compose(_cfg: dict) -> tuple[dict, list[dict]]:
        raise AssertionError("species packs must not be recomposed for window validation")

    monkeypatch.setattr(objective_module, "compose_species_packs", unexpected_compose)
    windows = load_windows(
        case_cfg,
        emission_kernel_inventory={"records": [{"id": "kernel", "transition_ids": ["line"]}]},
    )

    assert [window["name"] for window in windows] == ["line_window"]


@pytest.mark.parametrize("field", ["kernel_id", "transition_id"])
def test_window_kernel_binding_requires_both_ids(tmp_path: Path, field: str) -> None:
    case_cfg = _case_with_kernel_window(
        tmp_path,
        _window("line_window", 500.0, **{field: "kernel"}),
    )

    with pytest.raises(ValueError, match="dependency"):
        load_windows(case_cfg)


def test_window_kernel_binding_rejects_unknown_kernel_before_filtering(tmp_path: Path) -> None:
    case_cfg = _case_with_kernel_window(
        tmp_path,
        _window(
            "line_window",
            500.0,
            kernel_id="missing",
            transition_id="line",
        ),
    )
    case_cfg["diagnostics"]["window_names"] = ["different_window"]

    with pytest.raises(ValueError, match="unknown emission kernel 'missing'"):
        load_windows(case_cfg)


def test_window_kernel_binding_rejects_transition_from_another_kernel(tmp_path: Path) -> None:
    case_cfg = _case_with_kernel_window(
        tmp_path,
        _window(
            "line_window",
            501.0,
            kernel_id="kernel",
            transition_id="other_line",
        ),
    )

    with pytest.raises(ValueError, match="does not belong to emission kernel 'kernel'"):
        load_windows(case_cfg)


def test_window_kernel_binding_requires_transition_wavelength_inside_window(tmp_path: Path) -> None:
    case_cfg = _case_with_kernel_window(
        tmp_path,
        _window(
            "line_window",
            501.0,
            kernel_id="kernel",
            transition_id="line",
        ),
    )

    with pytest.raises(ValueError, match="does not contain transition 'line' wavelength"):
        load_windows(case_cfg)


def test_explicit_fit_and_score_windows_must_not_overlap(tmp_path: Path) -> None:
    registry = tmp_path / "windows.yaml"
    save_yaml(
        {
            "windows": [
                _window(
                    "fit_window",
                    500.0,
                    analysis_role="fit",
                    model_coverage="physical",
                ),
                _window(
                    "score_window",
                    500.3,
                    analysis_role="score",
                    model_coverage="physical",
                ),
            ]
        },
        registry,
    )
    case_cfg = {
        "__base_dir__": str(tmp_path),
        "diagnostics": {"window_registry": registry.name},
    }

    with pytest.raises(ValueError, match="held-out leakage"):
        load_windows(case_cfg)


def test_legacy_overlapping_windows_preserve_compatibility(tmp_path: Path) -> None:
    registry = tmp_path / "windows.yaml"
    save_yaml(
        {
            "windows": [
                _window("first", 500.0),
                _window("second", 500.3),
            ]
        },
        registry,
    )
    case_cfg: dict[str, Any] = {
        "__base_dir__": str(tmp_path),
        "diagnostics": {"window_registry": registry.name},
    }

    assert [window["name"] for window in load_windows(case_cfg)] == ["first", "second"]

    save_yaml({"windows": [_window("first", 500.0), _window("first", 500.3)]}, registry)
    case_cfg["diagnostics"]["window_names"] = ["not_selected"]
    with pytest.raises(ValueError, match="duplicate name 'first'"):
        load_windows(case_cfg)


def test_normalized_inverse_does_not_inherit_case_diagnostic_windows(
    tmp_path: Path,
) -> None:
    registry = tmp_path / "windows.yaml"
    save_yaml({"windows": [_window("diagnostic_only", 500.0)]}, registry)
    case_cfg = {
        "__base_dir__": str(tmp_path),
        "diagnostics": {"window_registry": registry.name},
    }

    inverse_cfg = normalize_inverse_config(case_cfg, {})

    assert inverse_cfg["window_selection"] == {"mode": "full_spectrum"}
    assert load_windows(case_cfg, inverse_cfg) == []
    assert load_windows(case_cfg, {}) == []


def test_inverse_window_selection_owns_registry_and_path_base(tmp_path: Path) -> None:
    case_dir = tmp_path / "case"
    inverse_dir = tmp_path / "inverse"
    case_dir.mkdir()
    inverse_dir.mkdir()
    save_yaml({"windows": [_window("legacy_case", 500.0)]}, case_dir / "windows.yaml")
    save_yaml(
        {
            "windows": [
                _window(
                    "inverse_fit",
                    501.0,
                    analysis_role="fit",
                    model_coverage="physical",
                )
            ]
        },
        inverse_dir / "windows.yaml",
    )
    case_cfg = {
        "__base_dir__": str(case_dir),
        "diagnostics": {"window_registry": "windows.yaml"},
    }
    inverse_cfg = {
        "__base_dir__": str(inverse_dir),
        "window_selection": {"mode": "window_union", "registry": "windows.yaml"},
    }

    windows = load_windows(case_cfg, inverse_cfg)

    assert [window["name"] for window in windows] == ["inverse_fit"]


def test_included_inverse_rebases_window_selection_registry(tmp_path: Path) -> None:
    fragment_dir = tmp_path / "fragment"
    project_dir = tmp_path / "project"
    fragment_dir.mkdir()
    project_dir.mkdir()
    save_yaml(
        {"windows": [_window("inverse_fit", 501.0)]},
        fragment_dir / "windows.yaml",
    )
    save_yaml(
        {
            "window_selection": {
                "mode": "window_union",
                "registry": "windows.yaml",
            }
        },
        fragment_dir / "selection.yaml",
    )
    save_yaml({"include": "../fragment/selection.yaml"}, project_dir / "inverse.yaml")

    inverse_cfg = load_yaml(project_dir / "inverse.yaml")

    resolved_registry = (Path(inverse_cfg["__base_dir__"]) / inverse_cfg["window_selection"]["registry"]).resolve()
    assert resolved_registry == (fragment_dir / "windows.yaml").resolve()
