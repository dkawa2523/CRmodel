from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import numpy as np
import pytest
from scipy import constants as const

import oescr.forward.emissivity as emissivity_module
import oescr.physics.bands as bands_module
from oescr.data.atomic_db import StateRegistry
from oescr.data.cross_section_db import CrossSectionLibrary
from oescr.forward.model import OESCRModel
from oescr.forward.reporting import forward_diagnostics_payload, write_forward_spectra
from oescr.instrument.spec import InstrumentSpec
from oescr.inverse.measurements import (
    load_measurement_csv,
    load_measurements,
    spectrum_residual_blocks,
    whiten_feature_residuals,
)
from oescr.inverse.use_cases import assess_inference_use_case
from oescr.io.normalize import normalize_case_config, normalize_inverse_config
from oescr.io.species_packs import SpeciesPackError
from oescr.io.validators import (
    ConfigSemanticError,
    validate_case_config,
    validate_inverse_config,
    validate_inverse_structural,
)
from oescr.io.yaml_loader import load_yaml
from oescr.physics.bands import evaluate_band_components_zone
from oescr.physics.cr_processes import (
    assemble_reaction_process,
    build_state_balances,
    compile_reaction_processes,
    sum_process_contributions,
)
from oescr.physics.quality import DiagnosticPolicyError
from oescr.physics.rates import RateCalculator, resolve_reaction_rate_spec
from oescr.physics.trapping import effective_A
from oescr.physics.wall import effective_wall_loss_rate_s, thermal_speed_m_s

ROOT = Path(__file__).resolve().parents[1]


def _example_case():
    return normalize_case_config(load_yaml(ROOT / "examples" / "case_init_cf4_o2_ar.yaml"))


def test_solved_state_cannot_also_be_an_external_density() -> None:
    cfg = _example_case()
    model = OESCRModel(cfg)
    cfg["plasma_state"]["radicals"]["Ar_2p6"] = [1.0e17] * cfg["geometry"]["n_shells"]
    with pytest.raises(ConfigSemanticError, match=r"Ar_2p6.*solved state.*plasma_state.radicals"):
        OESCRModel(cfg)
    with pytest.raises(ValueError, match=r"Ar_2p6.*solved state.*plasma_state.radicals"):
        model.runtime_spectrum_model().predict_spectra(cfg)


@pytest.mark.parametrize("profile_kind", ["gaussian", "tabulated"])
def test_band_power_does_not_depend_on_another_instruments_coverage(
    tmp_path: Path, profile_kind: str,
) -> None:
    cfg = load_yaml(ROOT / "examples" / "benchmarks" / "physical_band_analytic" / "case.yaml")
    cfg["bands"][0]["fwhm_nm"] = 40.0
    if profile_kind == "tabulated":
        path = tmp_path / "contour.csv"
        path.write_text(
            "wavelength_nm,relative_intensity\n460,0\n480,1\n500,2\n520,1\n540,0\n",
            encoding="utf-8",
        )
        cfg["bands"][0]["profile_kind"] = "tabulated"
        cfg["bands"][0]["profile_file"] = str(path)
    original = OESCRModel(cfg).predict_spectra()["analytic_radiance"]["chord_0"]["intensity"]
    wide = deepcopy(cfg["instruments"][0])
    wide.update(id="wide", wavelength_min_nm=400.0, wavelength_max_nm=600.0)
    cfg["instruments"].append(wide)
    extended = OESCRModel(cfg).predict_spectra()["analytic_radiance"]["chord_0"]["intensity"]
    np.testing.assert_allclose(extended, original, rtol=1.0e-8, atol=1.0e-9)


def test_nested_band_rate_file_uses_the_same_case_relative_path(tmp_path: Path) -> None:
    cfg = load_yaml(ROOT / "examples" / "benchmarks" / "physical_band_analytic" / "case.yaml")
    curve = tmp_path / "curve.csv"
    curve.write_text("energy_eV,sigma_m2\n0,0\n1,1e-20\n20,1e-20\n", encoding="utf-8")
    cfg["__base_dir__"] = str(tmp_path)
    band = cfg["bands"][0]
    band.pop("coefficient_m3_s")
    band["cross_section_file"] = "curve.csv"
    expected = OESCRModel(cfg).predict().spectra["analytic_radiance"]["chord_0"]["intensity"]
    band["rate_model"] = {"kind": "cross_section_file", "cross_section_file": band.pop("cross_section_file")}
    actual = OESCRModel(cfg).predict().spectra["analytic_radiance"]["chord_0"]["intensity"]
    np.testing.assert_array_equal(actual, expected)


def test_atomic_line_profiles_are_compiled_once(monkeypatch: pytest.MonkeyPatch) -> None:
    model = OESCRModel(_example_case())

    def unexpected_profile_rebuild(*_args, **_kwargs):
        raise AssertionError("runtime prediction must reuse compiled atomic line bases")

    monkeypatch.setattr(emissivity_module, "gaussian_line_profile", unexpected_profile_rebuild)

    spectra = model.predict_spectra()

    assert spectra


def test_molecular_band_profiles_are_compiled_once(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    case_path = ROOT / "examples" / "use_cases" / "two_band" / "case_absolute_init.yaml"
    case_cfg = load_yaml(case_path)
    profile_path = tmp_path / "profile.csv"
    profile_path.write_text(
        "wavelength_nm,relative_intensity\n499.99,0.0\n500.0,1.0\n500.01,0.0\n",
        encoding="utf-8",
    )
    case_cfg["bands"][0]["profile_kind"] = "tabulated"
    case_cfg["bands"][0]["profile_file"] = str(profile_path)
    profile_loads = 0
    original_loader = bands_module.load_profile_csv

    def counting_profile_loader(path):
        nonlocal profile_loads
        profile_loads += 1
        return original_loader(path)

    monkeypatch.setattr(bands_module, "load_profile_csv", counting_profile_loader)
    model = OESCRModel(case_cfg)
    assert profile_loads == 1
    assert np.max(np.diff(model.compiled.fine_wavelength_nm)) <= (0.01 / 6.0) * 1.000001

    def unexpected_profile_rebuild(*_args, **_kwargs):
        raise AssertionError("runtime prediction must reuse compiled molecular-band profiles")

    monkeypatch.setattr(bands_module, "band_profile", unexpected_profile_rebuild)

    spectra = model.predict_spectra()
    model.predict_spectra()

    assert spectra
    assert profile_loads == 1
    assert set(model.compiled.band_profiles) == {"target_band", "actinometer_band"}


def test_cross_section_load_records_provenance(tmp_path: Path) -> None:
    path = tmp_path / "valid.csv"
    path.write_text(
        "# source: unit-test\nenergy_eV,sigma_m2\n0.0,0.0\n1.0,1.0e-20\n",
        encoding="utf-8",
    )

    cross_section = CrossSectionLibrary().load(path)

    assert cross_section.metadata["source"] == "unit-test"
    assert len(cross_section.sha256) == 64
    assert cross_section.energy_range_eV == (0.0, 1.0)


@pytest.mark.parametrize(
    "rows, message",
    [
        ("0.0,0.0\n0.0,1.0e-20\n", "strictly increasing"),
        ("0.0,0.0\n1.0,-1.0e-20\n", "negative sigma"),
        ("0.0,0.0\n", "at least two"),
    ],
)
def test_cross_section_load_rejects_invalid_tables(tmp_path: Path, rows: str, message: str) -> None:
    path = tmp_path / "invalid.csv"
    path.write_text(f"energy_eV,sigma_m2\n{rows}", encoding="utf-8")

    with pytest.raises(ValueError, match=message):
        CrossSectionLibrary().load(path)


def test_reaction_requires_exactly_one_rate_source() -> None:
    reaction = {
        "id": "bad",
        "cross_section_file": "one.csv",
        "coefficient_m3_s": 1.0e-15,
    }

    with pytest.raises(ValueError, match="exactly one rate source"):
        resolve_reaction_rate_spec(reaction)


@pytest.mark.parametrize(
    "reaction, external, expected_frequency, expected_unit",
    [
        (
            {
                "id": "electron",
                "kind": "electron_excitation",
                "source_state": "X",
                "target_state": "U",
                "coefficient_m3_s": 2.0,
            },
            {"X": 5.0, "e": 3.0},
            6.0,
            "m^3 s^-1",
        ),
        (
            {
                "id": "first",
                "kind": "first_order",
                "source_state": "X",
                "target_state": "U",
                "coefficient_s-1": 2.0,
            },
            {"X": 5.0},
            2.0,
            "s^-1",
        ),
        (
            {
                "id": "second",
                "kind": "two_body",
                "source_state": "X",
                "target_state": "U",
                "colliders": ["M"],
                "coefficient_m3_s": 2.0,
            },
            {"X": 5.0, "M": 3.0},
            6.0,
            "m^3 s^-1",
        ),
        (
            {
                "id": "third",
                "kind": "three_body",
                "source_state": "X",
                "target_state": "U",
                "colliders": ["M", "M"],
                "coefficient_m6_s": 2.0,
            },
            {"X": 5.0, "M": 3.0},
            18.0,
            "m^6 s^-1",
        ),
    ],
)
def test_compiled_reaction_families_have_explicit_units_and_analytic_rhs(
    reaction: dict,
    external: dict,
    expected_frequency: float,
    expected_unit: str,
) -> None:
    registry = StateRegistry({"states": [{"id": "U", "energy_eV": 1.0, "solve": True}]})
    rate_calculator = RateCalculator(np.asarray([0.0, 1.0]), CrossSectionLibrary())
    process = compile_reaction_processes({"reactions": [reaction]})[0]
    contribution = assemble_reaction_process(
        process,
        registry,
        rate_calculator,
        external,
        np.asarray([1.0, 1.0]),
    )

    assert contribution.coefficient_unit == expected_unit
    assert contribution.effective_frequency_s_1 == expected_frequency
    assert np.allclose(contribution.matrix, 0.0)
    assert np.allclose(contribution.rhs, [expected_frequency * external["X"]])


def test_reaction_contributions_reproduce_matrix_rhs_and_state_budgets() -> None:
    registry = StateRegistry(
        {
            "states": [
                {"id": "A", "energy_eV": 1.0, "solve": True},
                {"id": "B", "energy_eV": 2.0, "solve": True},
            ]
        }
    )
    reaction = {
        "id": "transfer",
        "kind": "two_body",
        "source_state": "A",
        "target_state": "B",
        "colliders": ["M"],
        "coefficient_m3_s": 2.0,
    }
    process = compile_reaction_processes({"reactions": [reaction]})[0]
    contribution = assemble_reaction_process(
        process,
        registry,
        RateCalculator(np.asarray([0.0, 1.0]), CrossSectionLibrary()),
        {"M": 3.0},
        np.asarray([1.0, 1.0]),
    )

    matrix, rhs = sum_process_contributions([contribution], 2)
    balances = build_state_balances([contribution], np.asarray([4.0, 1.0]), registry)

    assert np.allclose(matrix, [[6.0, 0.0], [-6.0, 0.0]])
    assert np.allclose(rhs, [0.0, 0.0])
    assert balances["A"].total_loss_m3_s == 24.0
    assert balances["B"].total_source_m3_s == 24.0


def test_reaction_family_rejects_wrong_coefficient_dimension() -> None:
    reaction = {
        "id": "bad_second_order",
        "kind": "two_body",
        "source_state": "A",
        "colliders": ["M"],
        "coefficient_m6_s": 1.0,
    }

    with pytest.raises(ValueError, match="requires only 'coefficient_m3_s'"):
        compile_reaction_processes({"reactions": [reaction]})


def test_case_rejects_duplicate_state_ids() -> None:
    cfg = _example_case()
    cfg["states"].append(deepcopy(cfg["states"][0]))

    with pytest.raises(ConfigSemanticError, match="Duplicate states id"):
        validate_case_config(cfg)


def test_case_rejects_gas_fractions_that_do_not_sum_to_one() -> None:
    cfg = _example_case()
    cfg["gas_mixture"]["fractions"]["Ar"] = 0.2

    with pytest.raises(ConfigSemanticError, match="must sum to 1.0"):
        validate_case_config(cfg)


def test_case_rejects_duplicate_external_density_origins_with_both_names() -> None:
    cfg = _example_case()
    cfg["plasma_state"]["radicals"]["Ar"] = [1.0e15] * int(cfg["geometry"]["n_shells"])

    with pytest.raises(
        ConfigSemanticError,
        match=r"Ar.*gas_mixture\.fractions.*plasma_state\.radicals",
    ):
        validate_case_config(cfg)


def test_case_rejects_residual_density_when_mode_is_off() -> None:
    cfg = _example_case()
    cfg["residuals"] = {"mode": "off", "species_density_m3": {"N2": 1.0e12}}

    with pytest.raises(ConfigSemanticError, match="must be empty when residuals.mode='off'"):
        validate_case_config(cfg)


def test_case_rejects_unimplemented_residual_preset() -> None:
    cfg = _example_case()
    cfg["residuals"] = {"mode": "typical_high_vacuum", "species_density_m3": {}}

    with pytest.raises(ConfigSemanticError, match="Unsupported residuals.mode 'typical_high_vacuum'"):
        validate_case_config(cfg)


def test_case_rejects_wall_priors_as_forward_values() -> None:
    cfg = _example_case()
    cfg["wall"]["priors"] = {
        "gamma_Ar": {"type": "loguniform", "min": 1.0e-5, "max": 1.0e-1}
    }

    with pytest.raises(ConfigSemanticError, match=r"wall\.priors is not a statistical prior"):
        validate_case_config(cfg)


def test_case_rejects_nonlinear_solved_state_collider() -> None:
    cfg = _example_case()
    cfg["reactions"].append(
        {
            "id": "nonlinear_quenching",
            "kind": "two_body",
            "source_state": "Ar_2p6",
            "colliders": ["Ar_2p1"],
            "coefficient_m3_s": 1.0e-16,
        }
    )

    with pytest.raises(ConfigSemanticError, match="would make the current CR system nonlinear"):
        validate_case_config(cfg)


def test_effective_bands_require_explicit_empirical_mode() -> None:
    cfg = _example_case()
    cfg["emission_mode"] = "physical"

    with pytest.raises(ConfigSemanticError, match="emission_mode='empirical'"):
        validate_case_config(cfg)

    cfg["emission_mode"] = "empirical"
    relative = OESCRModel(cfg).predict_spectra()
    assert relative["uvvis_lowres"]["chord_0"]["output_basis"] == "relative_instrument_signal"
    assert relative["uvvis_lowres"]["chord_0"]["output_unit"] == "arb"

    physical_case = load_yaml(ROOT / "examples" / "benchmarks" / "physical_band_analytic" / "case.yaml")
    cfg["instruments"] = physical_case["instruments"]
    with pytest.raises(ValueError, match="calibration.input_basis='spectral_radiance'.*incompatible"):
        OESCRModel(cfg)
    cfg["instruments"][0]["calibration"]["absolute"] = False
    with pytest.raises(ValueError, match="calibration.input_basis='spectral_radiance'.*incompatible"):
        OESCRModel(cfg)


def test_relative_shape_reports_electron_density_gain_confounding() -> None:
    assessment = assess_inference_use_case(
        _example_case(),
        {
            "inference_mode": "relative_shape",
            "fit": {"objective": {"auto_gain_fit": True}},
        },
        ["plasma_state.ne_shells_m3[0]"],
    )

    assert not assessment.absolute_scale_prerequisites_met
    assert assessment.absolute_scale_locally_identifiable is None
    assert any("absolute scale is confounded" in warning for warning in assessment.warnings)


@pytest.mark.parametrize("mode", ["ratio_diagnostic", "actinometry"])
def test_ratio_interpretation_modes_require_an_active_ratio_objective(mode: str) -> None:
    case_cfg = _example_case()
    instrument_id = str(case_cfg["instruments"][0]["id"])
    inverse_cfg = normalize_inverse_config(
        case_cfg,
        {
            "inference_mode": mode,
            "measurements": [{"instrument_id": instrument_id, "file": "unused.csv"}],
            "parameters": [
                {
                    "name": "te_0",
                    "path": "plasma_state.te_shells_eV[0]",
                    "bounds": [1.0, 5.0],
                }
            ],
            "fit": {"objective": {"spectrum_weight": 0.0}},
        },
    )

    with pytest.raises(ConfigSemanticError, match="requires an active ratio objective"):
        validate_inverse_config(case_cfg, inverse_cfg)

    inverse_cfg["fit"]["objective"]["window_ratio_weight"] = 1.0
    validate_inverse_config(case_cfg, inverse_cfg)

    inverse_cfg["fit"]["objective"]["window_ratio_weight"] = 0.0
    inverse_cfg["fit"]["objective"]["window_ratio_pairs"] = [
        {"name": "diagnostic", "numerator": "line_a", "denominator": "line_b"}
    ]
    inverse_cfg["measurements"][0]["feature_covariance"] = {
        "names": ["ratio:diagnostic"],
        "matrix": [[1.0]],
    }
    validate_inverse_config(case_cfg, inverse_cfg)


@pytest.mark.parametrize(
    "enabled_flag",
    ["auto_gain_fit", "auto_offset_fit", "auto_gain_tilt_fit"],
)
def test_calibrated_absolute_rejects_fitted_inverse_correction(enabled_flag: str) -> None:
    objective = {
        "auto_gain_fit": False,
        "auto_offset_fit": False,
        "auto_gain_tilt_fit": False,
    }
    objective[enabled_flag] = True
    with pytest.raises(ValueError, match=f"{enabled_flag}=false"):
        assess_inference_use_case(
            _example_case(),
            {
                "inference_mode": "calibrated_absolute",
                "fit": {"objective": objective},
            },
            ["plasma_state.ne_shells_m3[0]"],
        )


def test_calibrated_absolute_uses_identity_inverse_correction_by_default() -> None:
    example = ROOT / "examples" / "use_cases" / "two_band"
    case_cfg = normalize_case_config(load_yaml(example / "case_absolute_init.yaml"))
    inverse_cfg = {
        "inference_mode": "calibrated_absolute",
        "measurements": [
            {"instrument_id": "two_band_radiance", "file": str(example / "measurement.csv")}
        ],
        "parameters": [
            {
                "name": "electron_density_m3",
                "path": "plasma_state.ne_shells_m3[0]",
                "scale": "log",
                "bounds": [5.0e15, 6.0e16],
            }
        ],
    }

    validate_inverse_structural(inverse_cfg)
    normalized = normalize_inverse_config(case_cfg, inverse_cfg)
    validate_inverse_config(case_cfg, normalized)

    objective = normalized["fit"]["objective"]
    assert objective["auto_gain_fit"] is False
    assert objective["auto_offset_fit"] is False
    assert objective["auto_gain_tilt_fit"] is False
    assessment = assess_inference_use_case(
        case_cfg,
        normalized,
        ["plasma_state.ne_shells_m3[0]"],
        case_cfg["instruments"],
    )
    assert assessment.absolute_scale_prerequisites_met


def test_relative_shape_keeps_existing_inverse_correction_defaults() -> None:
    case_cfg = _example_case()
    inverse_cfg = normalize_inverse_config(
        case_cfg,
        {
            "measurements": [{"instrument_id": "uvvis", "file": "unused.csv"}],
            "parameters": [
                {
                    "name": "te_0",
                    "path": "plasma_state.te_shells_eV[0]",
                    "bounds": [1.0, 5.0],
                }
            ],
        },
    )

    objective = inverse_cfg["fit"]["objective"]
    assert objective["auto_gain_fit"] is True
    assert objective["auto_offset_fit"] is True
    assert objective["auto_gain_tilt_fit"] is False


@pytest.mark.parametrize(
    "enabled_flag",
    ["auto_gain_fit", "auto_offset_fit", "auto_gain_tilt_fit"],
)
def test_calibrated_absolute_rejects_explicitly_enabled_inverse_correction(
    enabled_flag: str,
) -> None:
    example = ROOT / "examples" / "use_cases" / "two_band"
    case_cfg = normalize_case_config(load_yaml(example / "case_absolute_init.yaml"))
    inverse_cfg = {
        "inference_mode": "calibrated_absolute",
        "measurements": [
            {"instrument_id": "two_band_radiance", "file": str(example / "measurement.csv")}
        ],
        "parameters": [
            {
                "name": "electron_density_m3",
                "path": "plasma_state.ne_shells_m3[0]",
                "scale": "log",
                "bounds": [5.0e15, 6.0e16],
            }
        ],
        "fit": {"objective": {enabled_flag: True}},
    }

    validate_inverse_structural(inverse_cfg)
    normalized = normalize_inverse_config(case_cfg, inverse_cfg)

    with pytest.raises(ConfigSemanticError, match=f"enabled: {enabled_flag}"):
        validate_inverse_config(case_cfg, normalized)


@pytest.mark.parametrize(
    "path",
    [
        "instruments[0].nuisance.gain",
        "instruments[0].baseline.offset",
        "instruments[0].throughput",
        "instruments[0].calibration.viewing_factor",
    ],
)
def test_calibrated_absolute_rejects_fitted_instrument_scale_paths(path: str) -> None:
    with pytest.raises(ValueError, match="cannot fit instrument scale or baseline"):
        assess_inference_use_case(
            _example_case(),
            {
                "inference_mode": "calibrated_absolute",
                "fit": {
                    "objective": {
                        "auto_gain_fit": False,
                        "auto_offset_fit": False,
                        "auto_gain_tilt_fit": False,
                    }
                },
            },
            ["plasma_state.ne_shells_m3[0]", path],
        )


def test_absolute_inverse_semantics_reject_explicit_gain_parameter() -> None:
    example = ROOT / "examples" / "use_cases" / "two_band"
    case_cfg = normalize_case_config(load_yaml(example / "case_absolute_init.yaml"))
    inverse_cfg = load_yaml(example / "inverse_absolute.yaml")
    inverse_cfg["parameters"].append(
        {
            "name": "instrument_gain",
            "path": "instruments[0].nuisance.gain",
            "bounds": [0.5, 2.0],
        }
    )
    normalized = normalize_inverse_config(case_cfg, inverse_cfg)

    with pytest.raises(ConfigSemanticError, match="cannot fit an instrument scale"):
        validate_inverse_config(case_cfg, normalized)


def test_calibrated_absolute_requires_calibration_and_physical_emitters() -> None:
    case_cfg = _example_case()
    inverse_cfg = {
        "inference_mode": "calibrated_absolute",
        "fit": {
            "objective": {
                "auto_gain_fit": False,
                "auto_offset_fit": False,
                "auto_gain_tilt_fit": False,
            }
        },
    }
    with pytest.raises(ValueError, match="calibration.absolute=true"):
        assess_inference_use_case(case_cfg, inverse_cfg, [], [{"id": "uvvis"}])

    calibrated = [
        {
            "id": "uvvis",
            "calibration": {
                "kind": "spectral_radiance",
                "absolute": True,
                "input_basis": "spectral_radiance",
                "output_unit": "W_m-2_sr-1_nm-1",
                "reference": "unit-test calibration",
            },
        }
    ]
    with pytest.raises(ValueError, match="empirical effective bands"):
        assess_inference_use_case(case_cfg, inverse_cfg, [], calibrated)


def test_calibrated_absolute_separates_prerequisites_from_local_rank() -> None:
    case_cfg = _example_case()
    case_cfg["bands"] = []
    instrument = {
        "id": "uvvis",
        "calibration": {
            "kind": "spectral_radiance",
            "absolute": True,
            "input_basis": "spectral_radiance",
            "output_unit": "W_m-2_sr-1_nm-1",
            "reference": "unit-test calibration",
        },
    }

    assessment = assess_inference_use_case(
        case_cfg,
        {
            "inference_mode": "calibrated_absolute",
            "fit": {
                "objective": {
                    "auto_gain_fit": False,
                    "auto_offset_fit": False,
                    "auto_gain_tilt_fit": False,
                }
            },
        },
        ["plasma_state.ne_shells_m3[0]"],
        [instrument],
    )

    assert assessment.absolute_scale_prerequisites_met
    assert assessment.absolute_scale_locally_identifiable is None


def test_measurement_csv_reads_positive_pointwise_sigma(tmp_path: Path) -> None:
    path = tmp_path / "measurement.csv"
    path.write_text(
        "wavelength_nm,intensity,sigma\n500.0,2.0,0.1\n501.0,3.0,0.2\n",
        encoding="utf-8",
    )

    measurement = load_measurement_csv(path)

    assert measurement.sigma is not None
    assert np.allclose(measurement.sigma, [0.1, 0.2])


def test_measurement_covariance_whitens_correlated_residuals(tmp_path: Path) -> None:
    measurement_path = tmp_path / "measurement.csv"
    measurement_path.write_text(
        "wavelength_nm,intensity\n500.0,2.0\n501.0,3.0\n",
        encoding="utf-8",
    )
    covariance_path = tmp_path / "covariance.csv"
    covariance_path.write_text("4.0,1.0\n1.0,9.0\n", encoding="utf-8")

    measurement = load_measurement_csv(measurement_path, covariance_path)
    residual = spectrum_residual_blocks([(measurement, np.asarray([4.0, 6.0]))])[0]
    expected = np.linalg.solve(np.linalg.cholesky(np.asarray([[4.0, 1.0], [1.0, 9.0]])), [2.0, 3.0])

    assert measurement.covariance is not None
    assert np.allclose(residual, expected)


def test_feature_covariance_whitens_named_window_and_ratio_residuals(tmp_path: Path) -> None:
    measurement_path = tmp_path / "measurement.csv"
    measurement_path.write_text(
        "wavelength_nm,intensity\n500.0,2.0\n501.0,3.0\n",
        encoding="utf-8",
    )
    covariance = np.asarray([[0.04, 0.01], [0.01, 0.09]])
    inverse = {
        "__base_dir__": str(tmp_path),
        "measurements": [
            {
                "instrument_id": "uvvis",
                "file": "measurement.csv",
                "feature_covariance": {
                    "names": ["window:X:area", "ratio:X_to_Y"],
                    "matrix": covariance.tolist(),
                },
            }
        ],
    }

    measurement = load_measurements(inverse)["uvvis"][0]
    residual = whiten_feature_residuals(
        measurement,
        {"window:X:area": 0.2, "ratio:X_to_Y": -0.3},
    )
    expected = np.linalg.solve(np.linalg.cholesky(covariance), [0.2, -0.3])

    assert np.allclose(residual, expected)


def test_absolute_calibration_uncertainty_adds_correlated_measurement_error(tmp_path: Path) -> None:
    measurement_path = tmp_path / "measurement.csv"
    measurement_path.write_text(
        "# output_basis: spectral_radiance_W_m-2_sr-1_nm-1\n"
        "# output_unit: W_m-2_sr-1_nm-1\n"
        "# calibration_reference: expected calibration\n"
        "wavelength_nm,intensity,sigma\n500.0,10.0,1.0\n501.0,20.0,1.0\n",
        encoding="utf-8",
    )
    instrument = {
        "id": "uvvis",
        "calibration": {
            "kind": "spectral_radiance",
            "absolute": True,
            "input_basis": "spectral_radiance",
            "output_unit": "W_m-2_sr-1_nm-1",
            "reference": "expected calibration",
            "relative_standard_uncertainty": 0.1,
        },
    }
    inverse = {
        "__base_dir__": str(tmp_path),
        "inference_mode": "calibrated_absolute",
        "measurements": [{"instrument_id": "uvvis", "file": "measurement.csv"}],
    }

    measurement = load_measurements(inverse, [instrument])["uvvis"][0]
    residual = spectrum_residual_blocks([(measurement, np.asarray([12.0, 23.0]))])[0]
    covariance = np.eye(2) + np.outer([1.0, 2.0], [1.0, 2.0])
    expected = np.linalg.solve(np.linalg.cholesky(covariance), [2.0, 3.0])

    assert measurement.calibration_relative_standard_uncertainty == 0.1
    assert np.dot(residual, residual) == pytest.approx(np.dot(expected, expected))


def test_absolute_calibration_uncertainty_requires_measurement_noise(tmp_path: Path) -> None:
    measurement_path = tmp_path / "measurement.csv"
    measurement_path.write_text(
        "# output_basis: spectral_radiance_W_m-2_sr-1_nm-1\n"
        "# output_unit: W_m-2_sr-1_nm-1\n"
        "# calibration_reference: expected calibration\n"
        "wavelength_nm,intensity\n500.0,10.0\n501.0,20.0\n",
        encoding="utf-8",
    )
    instrument = {
        "id": "uvvis",
        "calibration": {
            "kind": "spectral_radiance",
            "absolute": True,
            "input_basis": "spectral_radiance",
            "output_unit": "W_m-2_sr-1_nm-1",
            "reference": "expected calibration",
            "relative_standard_uncertainty": 0.1,
        },
    }
    inverse = {
        "__base_dir__": str(tmp_path),
        "inference_mode": "calibrated_absolute",
        "measurements": [{"instrument_id": "uvvis", "file": "measurement.csv"}],
    }

    with pytest.raises(ValueError, match="calibration uncertainty but no pointwise sigma"):
        load_measurements(inverse, [instrument])


def test_absolute_measurement_metadata_must_match_instrument(tmp_path: Path) -> None:
    measurement_path = tmp_path / "measurement.csv"
    measurement_path.write_text(
        "# output_basis: spectral_power_W_nm-1\n"
        "# output_unit: W_nm-1\n"
        "# calibration_reference: wrong calibration\n"
        "wavelength_nm,intensity\n500.0,2.0\n501.0,3.0\n",
        encoding="utf-8",
    )
    instrument = {
        "id": "uvvis",
        "calibration": {
            "kind": "spectral_radiance",
            "absolute": True,
            "input_basis": "spectral_radiance",
            "output_unit": "W_m-2_sr-1_nm-1",
            "reference": "expected calibration",
        },
    }
    inverse = {
        "__base_dir__": str(tmp_path),
        "inference_mode": "calibrated_absolute",
        "measurements": [{"instrument_id": "uvvis", "file": "measurement.csv"}],
    }

    with pytest.raises(ValueError, match="metadata does not match"):
        load_measurements(inverse, [instrument])


def test_instrument_calibration_applies_etendue_and_photon_conversion() -> None:
    common = {
        "id": "calibrated",
        "wavelength_grid_nm": [500.0, 501.0],
        "throughput": 1.0,
        "lsf": {"kind": "gaussian", "fwhm_nm": 0.001},
        "baseline": {"kind": "constant", "offset": 0.0},
        "calibration": {
            "kind": "photoelectron_spectrum",
            "absolute": True,
            "input_basis": "spectral_radiance",
            "output_unit": "photoelectron_nm-1",
            "reference": "unit-test calibration",
            "collection_area_m2": 2.0e-6,
            "collection_solid_angle_sr": 3.0e-4,
            "viewing_factor": 0.5,
            "integration_time_s": 0.02,
            "quantum_efficiency": 0.25,
        },
    }
    instrument = InstrumentSpec(common)
    fine_wavelength = np.linspace(499.0, 502.0, 3001)
    observed = instrument.observe(fine_wavelength, np.ones_like(fine_wavelength))

    photon_energy = const.h * const.c / (500.5e-9)
    expected = 2.0e-6 * 3.0e-4 * 0.5 * 0.02 * 0.25 / photon_energy
    assert np.allclose(observed["intensity"], expected, rtol=2.0e-3)
    assert observed["output_unit"] == "photoelectron_nm-1"

    # Readout wavelength error and LSF broadening must preserve photon count;
    # photon energy is set by the incident line at 500 nm, not its shifted peak.
    common["wavelength_grid_nm"] = np.arange(480.0, 520.25, 0.25).tolist()
    common["nuisance"] = {"wavelength_shift_nm": 7.0}
    common["lsf"] = {"kind": "gaussian", "fwhm_nm": 3.0}
    shifted_instrument = InstrumentSpec(common)
    incident_wavelength = np.linspace(470.0, 530.0, 12001)
    unit_power_line = emissivity_module.gaussian_line_profile(incident_wavelength, 500.0, 0.05)
    shifted = shifted_instrument.observe(incident_wavelength, unit_power_line)
    expected_photons = 2.0e-6 * 3.0e-4 * 0.5 * 0.02 * 0.25 / (const.h * const.c / 500.0e-9)
    assert np.sum(shifted["intensity"]) * 0.25 == pytest.approx(expected_photons, rel=2.0e-6)


def test_physical_electron_impact_band_has_radiant_power_basis() -> None:
    energy = np.linspace(0.0, 20.0, 101)
    eedf = np.ones_like(energy)
    eedf /= np.trapezoid(eedf, energy)
    wavelength = np.linspace(495.0, 505.0, 1001)
    band = {
        "id": "physical_band",
        "kind": "electron_impact_photon_band",
        "source_density_key": "X",
        "coefficient_m3_s": 2.0e-14,
        "photon_yield": 0.6,
        "branching_ratio": 0.5,
        "profile_kind": "gaussian",
        "center_nm": 500.0,
        "fwhm_nm": 1.0,
    }
    rate_calculator = RateCalculator(energy, CrossSectionLibrary())

    result = evaluate_band_components_zone(
        {"bands": [band]},
        0,
        wavelength,
        {"e": 3.0e16, "X": 4.0e19},
        eedf,
        rate_calculator,
    )["physical_band"]

    photon_rate = 3.0e16 * 4.0e19 * 2.0e-14 * 0.6 * 0.5
    representative_energy = const.h * const.c / (500.0e-9)
    expected = photon_rate * representative_energy / (4.0 * np.pi)
    assert np.isclose(np.trapezoid(result.spectrum, wavelength), expected, rtol=1.0e-5)
    assert result.output_basis == "spectral_radiant_power_W_m-3_sr-1_nm-1"


def test_physical_band_analytic_benchmark() -> None:
    benchmark_dir = ROOT / "examples" / "benchmarks" / "physical_band_analytic"
    benchmark = load_yaml(benchmark_dir / "benchmark.yaml")
    result = OESCRModel.from_yaml(benchmark_dir / benchmark["case"]).predict()
    expected = benchmark["expected"]
    tolerance = float(expected["relative_tolerance"])

    integrated_emissivity = np.trapezoid(result.zone_band_emissivity[0], result.fine_wavelength_nm)
    observed = result.spectra["analytic_radiance"]["chord_0"]
    integrated_radiance = np.trapezoid(observed["intensity"], observed["wavelength_nm"])

    assert result.emission_basis == "spectral_radiant_power_W_m-3_sr-1_nm-1"
    assert result.zone_diagnostics[0].cr.solve_method == "empty"
    assert observed["output_unit"] == "W_m-2_sr-1_nm-1"
    assert np.isclose(
        integrated_emissivity,
        float(expected["integrated_emissivity_W_m3_sr"]),
        rtol=tolerance,
    )
    assert np.isclose(
        integrated_radiance,
        float(expected["central_chord_integrated_radiance_W_m2_sr"]),
        rtol=tolerance,
    )


def test_atomic_line_and_physical_band_conserve_combined_radiant_power() -> None:
    benchmark_dir = ROOT / "examples" / "benchmarks" / "physical_band_analytic"
    benchmark = load_yaml(benchmark_dir / "combined_benchmark.yaml")
    result = OESCRModel.from_yaml(benchmark_dir / benchmark["case"]).predict()
    expected = benchmark["expected"]
    tolerance = float(expected["relative_tolerance"])

    atomic = np.trapezoid(result.zone_atomic_emissivity[0], result.fine_wavelength_nm)
    band = np.trapezoid(result.zone_band_emissivity[0], result.fine_wavelength_nm)
    total = np.trapezoid(result.zone_emissivity[0], result.fine_wavelength_nm)
    observed = result.spectra["combined_radiance"]["chord_0"]
    radiance = np.trapezoid(observed["intensity"], observed["wavelength_nm"])

    assert np.isclose(atomic, float(expected["atomic_line_emissivity_W_m3_sr"]), rtol=tolerance)
    assert np.isclose(band, float(expected["band_emissivity_W_m3_sr"]), rtol=tolerance)
    assert np.isclose(total, atomic + band, rtol=1.0e-12)
    assert np.isclose(total, float(expected["combined_emissivity_W_m3_sr"]), rtol=tolerance)
    assert np.isclose(
        radiance,
        float(expected["central_chord_combined_radiance_W_m2_sr"]),
        rtol=tolerance,
    )
    state_balance = result.zone_diagnostics[0].state_balances["X_excited"]
    assert any(key.startswith("reaction:") for key in state_balance.sources_m3_s)
    assert any(key.startswith("radiative:") for key in state_balance.losses_m3_s)
    assert np.isclose(state_balance.net_m3_s, 0.0, atol=1.0e-6 * state_balance.total_source_m3_s)


@pytest.mark.parametrize("audit", [False, True])
def test_singular_cr_system_fails_in_both_prediction_paths(audit: bool) -> None:
    benchmark_dir = ROOT / "examples" / "benchmarks" / "physical_band_analytic"
    cfg = load_yaml(benchmark_dir / "case.yaml")
    cfg["states"] = [{"id": "unbalanced", "energy_eV": 1.0, "solve": True}]
    cfg["reactions"] = [{
        "id": "unbalanced_pump", "kind": "electron_excitation",
        "source_state": "X", "target_state": "unbalanced", "coefficient_m3_s": 1.0e-15,
    }]
    cfg.setdefault("diagnostics", {})["quality"] = {"on_error": "report"}

    model = OESCRModel(cfg)
    with pytest.raises(ValueError, match="no unique steady-state solution"):
        model.predict() if audit else model.predict_spectra()


def test_quality_report_mode_preserves_failed_result_for_inspection() -> None:
    benchmark_dir = ROOT / "examples" / "benchmarks" / "physical_band_analytic"
    cfg = load_yaml(benchmark_dir / "case.yaml")
    cfg["energy_grid"]["max_eV"] = 2.0
    cfg.setdefault("diagnostics", {})["quality"] = {"on_error": "report"}

    result = OESCRModel(cfg).predict()

    assert result.quality_report.status == "error"
    assert any(event.category == "eedf.upper_decile_mass" for event in result.quality_report.events)


def test_under_resolved_energy_range_fails_with_eedf_category() -> None:
    benchmark_dir = ROOT / "examples" / "benchmarks" / "physical_band_analytic"
    cfg = load_yaml(benchmark_dir / "case.yaml")
    cfg["energy_grid"]["max_eV"] = 2.0

    with pytest.raises(DiagnosticPolicyError) as caught:
        OESCRModel(cfg).predict()

    categories = {event.category for event in caught.value.report.events}
    assert "eedf.upper_decile_mass" in categories
    assert "eedf.upper_edge_pdf" in categories


def test_explicit_grid_convergence_records_energy_and_wavelength_checks() -> None:
    benchmark_dir = ROOT / "examples" / "benchmarks" / "physical_band_analytic"
    cfg = load_yaml(benchmark_dir / "combined_case.yaml")
    # Resolve the narrow atomic line for this test's declared 0.1% tolerance.
    cfg["numerics"] = {"wavelength_refinement_factor": 2.0}
    cfg.setdefault("diagnostics", {})["convergence"] = {
        "enabled": True,
        "energy_grid_factor": 2,
        "wavelength_grid_factor": 2,
        "warn_relative_above": 1.0e-3,
        "error_relative_above": 1.0e-2,
    }

    result = OESCRModel(cfg).predict()

    assert result.quality_report.status == "pass"
    assert result.quality_report.convergence["energy_grid"]["refinement_factor"] == 2
    assert result.quality_report.convergence["wavelength_grid"]["refinement_factor"] == 2


def test_forward_diagnostics_payload_and_yaml_include_provenance(tmp_path: Path) -> None:
    benchmark_dir = ROOT / "examples" / "benchmarks" / "physical_band_analytic"
    result = OESCRModel.from_yaml(benchmark_dir / "combined_case.yaml").predict()
    output_path = tmp_path / "diagnostics.yaml"

    payload = forward_diagnostics_payload(result)
    write_forward_spectra(result.spectra, tmp_path, diagnostics=result)
    written = load_yaml(output_path)

    assert payload["quality"]["status"] == "pass"
    assert payload["zones"][0]["state_balances"]["X_excited"]
    assert written["provenance"] == result.provenance
    write_forward_spectra(result.spectra, tmp_path)
    assert not output_path.exists()
    assert (tmp_path / "combined_radiance_chord_0.csv").is_file()


def test_diagnostic_threshold_order_is_validated() -> None:
    cfg = _example_case()
    cfg.setdefault("diagnostics", {})["quality"] = {
        "thresholds": {
            "cr_condition_warn_above": 1.0e15,
            "cr_condition_error_above": 1.0e10,
        }
    }

    model = OESCRModel(cfg)
    spectra = model.predict_spectra()

    assert spectra
    with pytest.raises(ValueError, match="must be <="):
        model.predict()


def test_legacy_quenching_and_loss_are_normalized_to_reactions() -> None:
    cfg = _example_case()
    cfg["quenching"] = [
        {
            "state": "Ar_2p1",
            "collider": "O2",
            "rate_coefficient_m3_s": 1.5e-16,
        }
    ]
    cfg["losses"] = [{"state": "Ar_2p6", "rate_coefficient_s-1": 4.0e3}]

    normalized = normalize_case_config(cfg)

    assert "quenching" not in normalized
    assert "losses" not in normalized
    quenching, loss = normalized["reactions"][-2:]
    assert quenching["kind"] == "two_body"
    assert quenching["source_state"] == "Ar_2p1"
    assert quenching["colliders"] == ["O2"]
    assert loss["kind"] == "first_order"
    assert loss["coefficient_s-1"] == 4.0e3


def test_unimplemented_trapping_geometry_is_rejected() -> None:
    transition = {
        "A_s-1": 1.0e7,
        "trapping": {"kind": "escape_factor", "shape": "cylinder", "tau0": 1.0},
    }

    with pytest.raises(ValueError, match="not one of"):
        effective_A(transition)


def test_species_pack_adds_namespaced_state_and_provenance(tmp_path: Path) -> None:
    pack_path = tmp_path / "test_species.yaml"
    pack_path.write_text(
        "\n".join(
            [
                "kind: oescr_species_pack",
                "namespace: ignored_by_entry_override",
                "metadata:",
                "  source: unit-test",
                "states:",
                "  - id: X_excited",
                "    species: X",
                "    energy_eV: 1.0",
                "    solve: false",
            ]
        ),
        encoding="utf-8",
    )
    cfg = load_yaml(ROOT / "examples" / "case_init_cf4_o2_ar.yaml")
    cfg.setdefault("species_packs", []).append(
        {"yaml_file": str(pack_path), "namespace": "test"}
    )

    result = OESCRModel(cfg).predict()

    assert "test:X_excited" in result.state_registry.states
    added_pack = next(
        pack for pack in result.provenance["species_packs"] if pack["namespace"] == "test"
    )
    assert added_pack["metadata"]["source"] == "unit-test"


def test_multigas_example_composes_namespaced_packs_and_rebases_data_paths() -> None:
    model = OESCRModel.from_yaml(ROOT / "examples" / "case_truth_cf4_o2_ar.yaml")

    result = model.predict()
    oxygen_pack = next(
        pack for pack in result.provenance["species_packs"] if pack["namespace"] == "oxygen"
    )
    excitation = next(
        reaction
        for reaction in model.cfg["reactions"]
        if reaction["id"] == "oxygen:exc_O_to_3p5P"
    )

    assert "oxygen:O_3p5P" in result.state_registry.states
    assert "O_3p5P" not in result.state_registry.states
    assert excitation["source_state"] == "O"
    assert excitation["target_state"] == "oxygen:O_3p5P"
    assert Path(excitation["cross_section_file"]).is_file()
    assert oxygen_pack["metadata"]["evidence"].startswith("Illustrative")
    assert len(result.provenance["species_packs"]) == 2


def test_species_pack_rejects_duplicate_ids() -> None:
    cfg = load_yaml(ROOT / "examples" / "case_init_cf4_o2_ar.yaml")
    cfg.setdefault("species_packs", []).append(
        {
            "kind": "oescr_species_pack",
            "states": [{"id": "Ar_2p1", "species": "Ar", "energy_eV": 13.48, "solve": True}],
        }
    )

    with pytest.raises(SpeciesPackError, match="Duplicate states id"):
        OESCRModel(cfg)


def test_nonuniform_instrument_grid_uses_local_bin_widths() -> None:
    instrument = InstrumentSpec(
        {
            "id": "nonuniform",
            "wavelength_grid_nm": [500.0, 501.0, 503.0],
            "throughput": 1.0,
            "lsf": {"kind": "gaussian", "fwhm_nm": 0.01},
            "baseline": {"kind": "constant", "offset": 0.0},
        }
    )
    fine_wavelength = np.linspace(494.0, 509.0, 15001)

    observed = instrument.observe(fine_wavelength, np.ones_like(fine_wavelength))

    assert np.allclose(observed["intensity"], 1.0, rtol=2.0e-3, atol=2.0e-3)


def test_wall_loss_requires_mass_and_applies_explicit_flux_factor() -> None:
    with pytest.raises(ValueError, match="requires state mass_amu"):
        thermal_speed_m_s(None, 300.0)

    common = {
        "geometry_cfg": {"chamber_radius_m": 0.1, "chamber_height_m": 0.1},
        "gas_temperature_K": 300.0,
        "state_id": "Ar_meta",
        "species": "Ar",
        "mass_amu": 39.948,
    }
    full = effective_wall_loss_rate_s(
        wall_cfg={"model": "gamma_thermal", "gamma_default": 0.1, "thermal_flux_factor": 1.0},
        **common,
    )
    quarter = effective_wall_loss_rate_s(
        wall_cfg={"model": "gamma_thermal", "gamma_default": 0.1, "thermal_flux_factor": 0.25},
        **common,
    )

    assert np.isclose(quarter, 0.25 * full)
