from __future__ import annotations

import csv
import shutil
from pathlib import Path

import pytest
import yaml
from scripts.package_model_ready_oes import (
    package_model_ready_observation,
    package_model_ready_observations,
)

from oescr.data.provenance import file_sha256
from oescr.inverse.measurements import load_measurements
from oescr.inverse.optimize import InverseSolver
from oescr.inverse.reporting import write_fit_result
from oescr.io.project import load_project
from oescr.io.yaml_loader import load_yaml


def _write_manifest(
    root: Path,
    *,
    source_hash: str | None = None,
    extra: dict[str, object] | None = None,
) -> Path:
    source = root / "external_calibrated.csv"
    calibration = root / "lamp_calibration.yaml"
    manifest: dict[str, object] = {
        "format": "oescr_model_ready_package/v1",
        "source": {
            "file": source.name,
            "sha256": source_hash or file_sha256(source),
            "stage": "calibrated",
        },
        "calibration_artifact": {
            "id": "lamp-2026-10-04",
            "file": calibration.name,
            "sha256": file_sha256(calibration),
        },
        "spectral_axis": {
            "unit": "nm",
            "wavelength_medium": "air",
            "sampling": "bin_average",
        },
        "observation": {
            "instrument_id": "uvvis",
            "id": "condition-1-view-0-rep-0",
            "prediction_key": "chord_0",
            "condition_id": "condition-1",
            "state_group_id": "condition-1-stationary-a",
            "view_id": "view-0",
            "replicate_id": "rep-0",
            "output_basis": "spectral_radiance_W_m-2_sr-1_nm-1",
            "output_unit": "W_m-2_sr-1_nm-1",
            "calibration_reference": "NIST-traceable lamp 2026-10-04",
            "calibration_group_id": "lamp-session-2026-10-04",
        },
        "columns": {
            "wavelength_nm": "Lambda (nm)",
            "intensity": "Radiance",
            "sigma": "Standard uncertainty",
            "pixel_status": "Detector flag",
            "lower_bound": "Lower limit",
            "upper_bound": "Upper limit",
        },
        "status_map": {"GOOD": "valid", "OVER": "saturated", "NO_DATA": "missing"},
        "outputs": {
            "spectrum_file": "package/spectrum.csv",
            "measurement_file": "package/measurement.yaml",
            "provenance_file": "package/provenance.yaml",
        },
    }
    manifest.update(extra or {})
    path = root / "package_manifest.yaml"
    path.write_text(yaml.safe_dump(manifest, sort_keys=False), encoding="utf-8")
    return path


@pytest.fixture
def calibrated_package_inputs(tmp_path: Path) -> Path:
    (tmp_path / "external_calibrated.csv").write_text(
        "Lambda (nm),Radiance,Standard uncertainty,Detector flag,Lower limit,Upper limit\n"
        "750.0000,1.23000E-04,2.500E-06,GOOD,,\n"
        "751.0000,9.999E-04,,OVER,9.000E-04,\n"
        "752.0000,,,NO_DATA,,\n",
        encoding="utf-8",
    )
    (tmp_path / "lamp_calibration.yaml").write_text(
        "reference: NIST-traceable lamp 2026-10-04\nrevision: 3\n",
        encoding="utf-8",
    )
    return _write_manifest(tmp_path)


def _read_output_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(line for line in stream if not line.startswith("#")))


def test_adapter_verifies_artifacts_and_builds_deterministic_canonical_package(
    calibrated_package_inputs: Path,
) -> None:
    result = package_model_ready_observation(calibrated_package_inputs)
    spectrum = Path(result["spectrum_file"])
    measurement_yaml = Path(result["measurement_file"])
    provenance_yaml = Path(result["provenance_file"])

    rows = _read_output_rows(spectrum)
    assert [row["wavelength_nm"] for row in rows] == ["750.0000", "751.0000", "752.0000"]
    assert [row["intensity"] for row in rows] == ["1.23000E-04", "9.999E-04", ""]
    assert [row["sigma"] for row in rows] == ["2.500E-06", "", ""]
    assert [row["lower_bound"] for row in rows] == ["", "9.000E-04", ""]
    assert [row["pixel_status"] for row in rows] == ["valid", "saturated", "missing"]

    loaded = load_measurements(load_yaml(measurement_yaml))["uvvis"][0]
    assert loaded.id == "condition-1-view-0-rep-0"
    assert loaded.stage == "model_ready"
    assert loaded.condition_id == "condition-1"
    assert loaded.state_group_id == "condition-1-stationary-a"
    assert loaded.ordinary_residual_mask is not None
    assert loaded.ordinary_residual_mask.tolist() == [True, False, False]
    assert loaded.calibration_artifact_id == "lamp-2026-10-04"
    assert loaded.calibration_artifact_sha256 == file_sha256(
        calibrated_package_inputs.parent / "lamp_calibration.yaml"
    )
    assert loaded.metadata is not None
    assert loaded.metadata["calibration_reference"] == "NIST-traceable lamp 2026-10-04"
    assert loaded.metadata["spectral_axis_unit"] == "nm"
    assert loaded.metadata["wavelength_medium"] == "air"
    assert loaded.metadata["spectral_sampling"] == "bin_average"

    provenance = yaml.safe_load(provenance_yaml.read_text(encoding="utf-8"))
    assert provenance["source"]["sha256"] == file_sha256(
        calibrated_package_inputs.parent / "external_calibrated.csv"
    )
    assert provenance["calibration_artifact"]["sha256"] == file_sha256(
        calibrated_package_inputs.parent / "lamp_calibration.yaml"
    )
    assert provenance["source"]["stage"] == "calibrated"
    assert provenance["spectral_axis"] == {
        "unit": "nm",
        "wavelength_medium": "air",
        "sampling": "bin_average",
    }
    assert provenance["transform"] == {
        "kind": "column_rename_and_status_map_only",
        "columns": {
            "wavelength_nm": "Lambda (nm)",
            "intensity": "Radiance",
            "sigma": "Standard uncertainty",
            "pixel_status": "Detector flag",
            "lower_bound": "Lower limit",
            "upper_bound": "Upper limit",
        },
        "status_map": {"GOOD": "valid", "OVER": "saturated", "NO_DATA": "missing"},
        "numeric_tokens_copied_verbatim": True,
        "resampling": False,
        "interpolation": False,
        "smoothing": False,
        "normalization": False,
        "raw_count_calibration": False,
    }

    first_bytes = {
        path: path.read_bytes() for path in (spectrum, measurement_yaml, provenance_yaml)
    }
    repeated = package_model_ready_observation(calibrated_package_inputs)
    assert repeated["spectrum_sha256"] == result["spectrum_sha256"]
    assert repeated["measurement_sha256"] == result["measurement_sha256"]
    assert all(path.read_bytes() == contents for path, contents in first_bytes.items())


def test_adapter_rejects_source_hash_mismatch_before_writing_outputs(
    calibrated_package_inputs: Path,
) -> None:
    manifest = _write_manifest(
        calibrated_package_inputs.parent,
        source_hash="0" * 64,
    )

    with pytest.raises(ValueError, match="Source artifact SHA-256 mismatch"):
        package_model_ready_observation(manifest)

    assert not (manifest.parent / "package").exists()


def test_adapter_rejects_an_unmapped_external_status(
    calibrated_package_inputs: Path,
) -> None:
    source = calibrated_package_inputs.parent / "external_calibrated.csv"
    source.write_text(
        source.read_text(encoding="utf-8").replace("GOOD", "QUESTIONABLE"),
        encoding="utf-8",
    )
    manifest = _write_manifest(calibrated_package_inputs.parent)

    with pytest.raises(ValueError, match="unmapped pixel status 'QUESTIONABLE'"):
        package_model_ready_observation(manifest)

    assert not (manifest.parent / "package").exists()


def test_adapter_rejects_physics_or_window_policy_fields(
    calibrated_package_inputs: Path,
) -> None:
    manifest = _write_manifest(
        calibrated_package_inputs.parent,
        extra={"windows": {"fit": ["ar750"]}},
    )

    with pytest.raises(ValueError, match="unsupported fields: windows"):
        package_model_ready_observation(manifest)

    assert not (manifest.parent / "package").exists()


def test_adapter_rejects_raw_or_ambiguous_spectral_axis_contracts(
    calibrated_package_inputs: Path,
) -> None:
    raw_manifest = yaml.safe_load(calibrated_package_inputs.read_text(encoding="utf-8"))
    raw_manifest["source"]["stage"] = "raw"
    calibrated_package_inputs.write_text(
        yaml.safe_dump(raw_manifest, sort_keys=False), encoding="utf-8"
    )
    with pytest.raises(ValueError, match="source.stage must be 'calibrated'"):
        package_model_ready_observation(calibrated_package_inputs)

    raw_manifest["source"]["stage"] = "calibrated"
    raw_manifest["spectral_axis"]["wavelength_medium"] = None
    calibrated_package_inputs.write_text(
        yaml.safe_dump(raw_manifest, sort_keys=False), encoding="utf-8"
    )
    with pytest.raises(ValueError, match="spectral_axis.wavelength_medium"):
        package_model_ready_observation(calibrated_package_inputs)


def test_adapter_requires_pointwise_uncertainty_mapping(
    calibrated_package_inputs: Path,
) -> None:
    manifest = yaml.safe_load(calibrated_package_inputs.read_text(encoding="utf-8"))
    del manifest["columns"]["sigma"]
    calibrated_package_inputs.write_text(
        yaml.safe_dump(manifest, sort_keys=False), encoding="utf-8"
    )

    with pytest.raises(ValueError, match="missing canonical targets: sigma"):
        package_model_ready_observation(calibrated_package_inputs)


def test_committed_contract_fixture_is_runnable(tmp_path: Path) -> None:
    source = Path(__file__).resolve().parents[1] / "examples" / "model_ready_package"
    fixture = tmp_path / "model_ready_package"
    shutil.copytree(source, fixture)

    result = package_model_ready_observation(fixture / "package_manifest.yaml")

    assert Path(result["spectrum_file"]).is_file()
    assert Path(result["measurement_file"]).is_file()
    assert Path(result["provenance_file"]).is_file()


def test_multiple_packages_compose_into_one_rebased_measurement_set(
    calibrated_package_inputs: Path,
    tmp_path: Path,
) -> None:
    source_root = calibrated_package_inputs.parent
    manifests: list[Path] = []
    for repeat_index in range(2):
        package_root = tmp_path / f"package-{repeat_index}"
        package_root.mkdir()
        shutil.copy(source_root / "external_calibrated.csv", package_root)
        shutil.copy(source_root / "lamp_calibration.yaml", package_root)
        manifest = _write_manifest(package_root)
        document = yaml.safe_load(manifest.read_text(encoding="utf-8"))
        document["observation"]["id"] = f"condition-1-view-0-rep-{repeat_index}"
        document["observation"]["replicate_id"] = f"rep-{repeat_index}"
        manifest.write_text(yaml.safe_dump(document, sort_keys=False), encoding="utf-8")
        manifests.append(manifest)

    destination = tmp_path / "combined" / "measurement_set.yaml"
    result = package_model_ready_observations(manifests, destination)

    assert result["measurement_count"] == 2
    combined = load_yaml(destination)
    assert [entry["id"] for entry in combined["measurements"]] == [
        "condition-1-view-0-rep-0",
        "condition-1-view-0-rep-1",
    ]
    assert all(not Path(entry["file"]).is_absolute() for entry in combined["measurements"])
    loaded = load_measurements(combined)["uvvis"]
    assert [measurement.id for measurement in loaded] == [
        "condition-1-view-0-rep-0",
        "condition-1-view-0-rep-1",
    ]


@pytest.mark.parametrize(
    "conflict",
    ["measurement_set_is_source", "measurement_set_is_output", "shared_package_output", "output_is_other_input"],
)
def test_package_composition_rejects_path_conflicts_before_writing(
    calibrated_package_inputs: Path,
    conflict: str,
) -> None:
    root = calibrated_package_inputs.parent
    manifests = [calibrated_package_inputs]
    destination = root / "combined" / "measurement_set.yaml"
    if conflict == "measurement_set_is_source":
        destination = root / "external_calibrated.csv"
    elif conflict == "measurement_set_is_output":
        destination = root / "package" / "measurement.yaml"
    else:
        first = yaml.safe_load(calibrated_package_inputs.read_text(encoding="utf-8"))
        second = yaml.safe_load(calibrated_package_inputs.read_text(encoding="utf-8"))
        second["observation"]["id"] = "another-observation"
        if conflict == "output_is_other_input":
            other_source = root / "other_source.csv"
            shutil.copyfile(root / "external_calibrated.csv", other_source)
            first["outputs"]["spectrum_file"] = other_source.name
            second["source"]["file"] = other_source.name
            second["outputs"] = {
                name: f"other_package/{Path(value).name}"
                for name, value in second["outputs"].items()
            }
            calibrated_package_inputs.write_text(yaml.safe_dump(first), encoding="utf-8")
        second_manifest = root / "second_manifest.yaml"
        second_manifest.write_text(yaml.safe_dump(second), encoding="utf-8")
        manifests.append(second_manifest)

    original_files = {path: path.read_bytes() for path in root.iterdir() if path.is_file()}
    with pytest.raises(ValueError, match="Output path"):
        package_model_ready_observations(manifests, destination)
    assert all(path.read_bytes() == original for path, original in original_files.items())
    assert not any(path.is_dir() for path in root.iterdir())


def test_packaged_fragment_runs_through_the_normal_project_fit(tmp_path: Path) -> None:
    examples = Path(__file__).resolve().parents[1] / "examples"
    source = examples / "model_ready_project"
    fixture = tmp_path / "examples" / "model_ready_project"
    shutil.copytree(source, fixture)
    case_fixture = tmp_path / "examples" / "use_cases" / "two_band" / "case_truth.yaml"
    case_fixture.parent.mkdir(parents=True)
    shutil.copyfile(examples / "use_cases" / "two_band" / "case_truth.yaml", case_fixture)

    packaged = package_model_ready_observations(
        [fixture / "package_manifest.yaml"],
        fixture / "generated" / "measurement_set.yaml",
    )
    project = load_project(fixture / "project.yaml")
    inverse = project.load_inverse_config()

    assert inverse is not None
    assert Path(packaged["packages"][0]["provenance_file"]).is_file()
    assert Path(packaged["measurement_file"]).name == "measurement_set.yaml"
    assert len(inverse["measurements"]) == 1
    assert "source" not in inverse["measurements"][0]
    solver = InverseSolver(load_yaml(project.case_yaml), inverse)
    result = solver.fit()
    write_fit_result(result, project.default_output_dir)

    persisted = load_yaml(project.default_output_dir / "result.yaml")
    assert persisted["success"] is True
    assert persisted["parameters"]["electron_density_m3"] == pytest.approx(
        3.0e16,
        rel=1.0e-6,
    )
    assert (project.default_output_dir / "spectra").is_dir()
