from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import numpy as np
import pytest

from oescr.inverse.optimize import FitResult
from oescr.inverse.reporting import (
    fit_result_summary,
    load_fit_result,
    write_fit_result,
)
from oescr.inverse.spectral_fit import SpectralFit
from oescr.io.yaml_loader import load_yaml, resolve_path, save_yaml


def _fit_result() -> FitResult:
    return FitResult(
        x_opt=np.asarray([3.5]),
        case_opt={"plasma_state": {"te_shells_eV": [3.5]}},
        cost=1.25,
        success=True,
        message="converged",
        aux={"selected_windows": {"uvvis": ["Ar_750"]}},
        parameters={"electron_temperature_eV": 3.5},
    )


def test_fit_result_summary_names_physical_parameters() -> None:
    summary = fit_result_summary(_fit_result())

    assert summary["parameters"] == {"electron_temperature_eV": 3.5}
    assert "x_opt" not in summary
    assert "uncertainty" not in summary
    assert "identifiability" not in summary
    assert "forward_quality" not in summary
    assert "assessment" not in summary
    assert "calibration_uncertainty" not in summary
    assert "optimization_trace" not in summary
    assert "parameter_profiles" not in summary
    assert "warnings" not in summary
    assert "gain_offset" not in summary
    assert "declared_windows" not in summary


def test_fit_result_summary_uses_stable_gain_records() -> None:
    fit = _fit_result()
    fit.aux["gain_offset"] = {
        ("uvvis", "view-b"): {"gain": 2.0, "offset": 0.1, "tilt": 0.0},
        ("uvvis", "view-a"): {"gain": 1.5, "offset": 0.0, "tilt": 0.01},
    }

    summary = fit_result_summary(fit)

    assert summary["gain_offset"] == [
        {
            "instrument_id": "uvvis",
            "observation_id": "view-a",
            "gain": 1.5,
            "offset": 0.0,
            "tilt": 0.01,
        },
        {
            "instrument_id": "uvvis",
            "observation_id": "view-b",
            "gain": 2.0,
            "offset": 0.1,
            "tilt": 0.0,
        },
    ]
    assert all("(" not in str(record) for record in summary["gain_offset"])


def test_write_fit_result_uses_one_shared_output_contract(tmp_path: Path) -> None:
    fit = _fit_result()
    source_dir = tmp_path / "source"
    source_dir.mkdir()
    save_yaml({"id": "uvvis"}, source_dir / "instrument.yaml")
    fit.case_opt["__base_dir__"] = str(source_dir)
    fit.case_opt["instruments"] = [{"yaml_file": "instrument.yaml"}]
    fit.spectral_fits = [
        SpectralFit(
            instrument_id="uvvis",
            observation_id="view/0",
            prediction_key="chord_0",
            output_basis="relative_instrument_signal",
            output_unit="arb",
            wavelength_nm=np.asarray([500.0, 501.0]),
            measured=np.asarray([2.0, 3.0]),
            predicted=np.asarray([2.1, 2.9]),
            sigma=np.asarray([0.2, 0.3]),
            used_for_fit=np.asarray([True, False]),
        )
    ]
    write_fit_result(fit, tmp_path)

    result = load_yaml(tmp_path / "result.yaml")
    optimized_case = load_yaml(tmp_path / "case_opt.yaml")
    assert result["parameters"] == {"electron_temperature_eV": 3.5}
    assert result["spectral_fits"][0]["observation_id"] == "view/0"
    spectrum_path = tmp_path / result["spectral_fits"][0]["file"]
    assert spectrum_path.name == "00_view_0.csv"
    assert spectrum_path.read_text(encoding="utf-8").splitlines() == [
        "wavelength_nm,measured,predicted,residual,sigma,used_for_fit",
        "500.0,2.0,2.1,0.10000000000000009,0.2,1",
        "501.0,3.0,2.9,-0.10000000000000009,0.3,0",
    ]
    assert optimized_case["plasma_state"]["te_shells_eV"] == [3.5]
    assert resolve_path(
        optimized_case,
        optimized_case["instruments"][0]["yaml_file"],
    ) == (source_dir / "instrument.yaml").resolve()

    user_file = tmp_path / "spectra" / "notes.txt"
    user_file.write_text("measurement notes", encoding="utf-8")
    fit.spectral_fits = [replace(fit.spectral_fits[0], observation_id="new-view")]
    write_fit_result(fit, tmp_path)
    assert not spectrum_path.exists()
    assert (tmp_path / "spectra" / "00_new-view.csv").is_file()
    assert user_file.read_text(encoding="utf-8") == "measurement notes"

    fit.spectral_fits = []
    write_fit_result(fit, tmp_path)
    assert "spectral_fits" not in load_fit_result(tmp_path / "result.yaml")
    assert list((tmp_path / "spectra").iterdir()) == [user_file]


def test_write_fit_result_separates_optional_audit_payloads(tmp_path: Path) -> None:
    fit = _fit_result()
    fit.assessment = {"mode": "relative_shape", "warnings": ["inspect fit"]}
    fit.calibration_uncertainty = {"uvvis": 0.02}
    fit.uncertainty = {"standard_deviation": {"electron_temperature_eV": 0.1}}
    fit.identifiability = {"rank_estimate": 1, "n_parameters": 1}
    fit.forward_quality = {"status": "pass", "events": []}
    fit.optimization_trace = [
        {"evaluation": 0, "stage": "final", "loss": 1.25, "x": [3.5]}
    ]
    fit.parameter_profiles = {
        "basis": "measurement_data_only",
        "profiles": {"electron_temperature_eV": {"points": []}},
    }

    write_fit_result(fit, tmp_path)

    result = load_yaml(tmp_path / "result.yaml")
    assert result["assessment"] == {"mode": "relative_shape"}
    assert result["warnings"] == ["inspect fit"]
    assert result["calibration_uncertainty"] == {"uvvis": 0.02}
    for field in (
        "uncertainty",
        "identifiability",
        "forward_quality",
        "optimization_trace",
        "parameter_profiles",
    ):
        assert field not in result
        artifact_path = tmp_path / result["audit"][field]["file"]
        assert artifact_path.is_file()

    uncertainty = load_yaml(tmp_path / result["audit"]["uncertainty"]["file"])
    assert uncertainty["standard_deviation"] == {"electron_temperature_eV": 0.1}
    trace = load_yaml(tmp_path / result["audit"]["optimization_trace"]["file"])
    assert trace["optimization_trace"] == fit.optimization_trace
    profiles = load_yaml(tmp_path / result["audit"]["parameter_profiles"]["file"])
    assert profiles["basis"] == "measurement_data_only"

    compact = load_fit_result(tmp_path / "result.yaml")
    assert "uncertainty" not in compact
    assert "optimization_trace" not in compact

    expanded = load_fit_result(tmp_path / "result.yaml", include_audit=True)
    assert expanded["uncertainty"] == fit.uncertainty
    assert expanded["identifiability"] == fit.identifiability
    assert expanded["forward_quality"] == fit.forward_quality
    assert expanded["optimization_trace"] == fit.optimization_trace
    assert expanded["parameter_profiles"] == fit.parameter_profiles

    user_file = tmp_path / "audit" / "notes.txt"
    user_file.write_text("audit notes", encoding="utf-8")
    write_fit_result(_fit_result(), tmp_path)
    result = load_yaml(tmp_path / "result.yaml")
    assert "audit" not in result
    assert list((tmp_path / "audit").iterdir()) == [user_file]
    user_file.unlink()
    write_fit_result(_fit_result(), tmp_path)
    assert not (tmp_path / "audit").exists()


def test_load_fit_result_preserves_legacy_top_level_audits(tmp_path: Path) -> None:
    legacy = {
        "success": True,
        "parameters": {"electron_temperature_eV": 3.5},
        "uncertainty": {"std_opt_space": {"electron_temperature_eV": 0.2}},
        "optimization_trace": [
            {"evaluation": 0, "stage": "final", "loss": 1.25, "x": [3.5]}
        ],
    }
    save_yaml(legacy, tmp_path / "result.yaml")

    assert load_fit_result(tmp_path / "result.yaml") == legacy
    assert load_fit_result(tmp_path / "result.yaml", include_audit=True) == legacy


def test_load_fit_result_rejects_audit_path_traversal(tmp_path: Path) -> None:
    save_yaml(
        {"audit": {"uncertainty": {"file": "../uncertainty.yaml"}}},
        tmp_path / "result.yaml",
    )
    save_yaml({"std_opt_space": {}}, tmp_path.parent / "uncertainty.yaml")

    compact = load_fit_result(tmp_path / "result.yaml")
    assert compact["audit"]["uncertainty"]["file"] == "../uncertainty.yaml"
    with pytest.raises(ValueError, match="relative path below the result directory"):
        load_fit_result(tmp_path / "result.yaml", include_audit=True)
