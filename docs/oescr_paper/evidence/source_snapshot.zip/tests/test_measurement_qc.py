from __future__ import annotations

from dataclasses import replace

import numpy as np
import pytest

from oescr.analysis.benchmark_contract import measurement_sha256
from oescr.inverse.measurements import (
    load_measurement_csv,
    load_measurements,
    spectrum_residual_blocks,
)
from oescr.io.normalize import normalize_measurement_bindings
from oescr.io.validators import validate_inverse_structural


def _write_csv(path, contents: str) -> None:
    path.write_text(contents, encoding="utf-8")


def test_legacy_two_column_csv_is_explicitly_all_valid(tmp_path) -> None:
    path = tmp_path / "legacy.csv"
    _write_csv(path, "wavelength_nm,intensity\n500,1\n501,2\n")

    measurement = load_measurement_csv(path, measurement_id="legacy", prediction_key="chord_0")

    assert measurement.stage == "legacy_scaled"
    assert measurement.output_basis == "unspecified"
    assert measurement.output_unit == "arb"
    assert measurement.pixel_status is not None
    assert measurement.ordinary_residual_mask is not None
    assert measurement.pixel_status.tolist() == ["valid", "valid"]
    assert measurement.ordinary_residual_mask.tolist() == [True, True]
    residual = spectrum_residual_blocks([(measurement, np.array([2.0, 4.0]))])[0]
    assert np.array_equal(residual, [2.0, 4.0])


def test_model_ready_metadata_round_trips_from_one_observation_entry(tmp_path) -> None:
    path = tmp_path / "observation.csv"
    _write_csv(path, "wavelength_nm,intensity,sigma\n500,1,0.1\n501,2,0.1\n")
    artifact_hash = "ab" * 32
    item = {
        "instrument_id": "uvvis",
        "id": "c001-v0-r0",
        "prediction_key": "chord_0",
        "condition_id": "c001",
        "state_group_id": "c001-stationary-a",
        "view_id": "view-0",
        "replicate_id": "rep-0",
        "stage": "model_ready",
        "file": path.name,
        "output_basis": "relative_instrument_signal",
        "output_unit": "arb",
        "calibration_artifact": {"id": "relative-response-v1", "sha256": artifact_hash},
    }
    inverse = {"__base_dir__": str(tmp_path), "measurements": [item]}

    loaded = load_measurements(inverse)["uvvis"][0]

    assert loaded.condition_id == "c001"
    assert loaded.state_group_id == "c001-stationary-a"
    assert loaded.view_id == "view-0"
    assert loaded.replicate_id == "rep-0"
    assert loaded.stage == "model_ready"
    assert loaded.output_basis == "relative_instrument_signal"
    assert loaded.output_unit == "arb"
    assert loaded.calibration_artifact_id == "relative-response-v1"
    assert loaded.calibration_artifact_sha256 == artifact_hash


def test_inverse_schema_accepts_model_ready_observation_metadata() -> None:
    validate_inverse_structural(
        {
            "measurements": [
                {
                    "instrument_id": "uvvis",
                    "id": "observation-1",
                    "prediction_key": "chord_0",
                    "condition_id": "condition-1",
                    "state_group_id": "state-1",
                    "view_id": "view-1",
                    "replicate_id": "replicate-1",
                    "stage": "model_ready",
                    "file": "observation.csv",
                    "output_basis": "relative_instrument_signal",
                    "output_unit": "arb",
                    "calibration_artifact": {"id": "response-v1", "sha256": "01" * 32},
                }
            ],
            "parameters": [
                {
                    "name": "te",
                    "path": "plasma_state.te_shells_eV[0]",
                    "bounds": [1.0, 10.0],
                }
            ],
        }
    )


@pytest.mark.parametrize(
    "measurement",
    [
        {
            "instrument_id": "uvvis",
            "file": "observation.csv",
            "condition_id": "condition-1",
        },
        {
            "instrument_id": "uvvis",
            "files": ["observation-a.csv", "observation-b.csv"],
            "condition_id": "condition-1",
            "state_group_id": "state-1",
            "stage": "model_ready",
            "output_basis": "relative_instrument_signal",
            "output_unit": "arb",
            "calibration_artifact": {
                "id": "response-v1",
                "sha256": "01" * 32,
            },
        },
    ],
)
def test_inverse_schema_accepts_individually_optional_observation_metadata(
    measurement: dict[str, object],
) -> None:
    validate_inverse_structural(
        {
            "measurements": [measurement],
            "parameters": [
                {
                    "name": "te",
                    "path": "plasma_state.te_shells_eV[0]",
                    "bounds": [1.0, 10.0],
                }
            ],
        }
    )


def test_measurement_entry_rejects_multiple_source_forms(tmp_path) -> None:
    measurement = {
        "instrument_id": "uvvis",
        "file": "observation.csv",
        "files": ["observation.csv"],
    }
    inverse = {"measurements": [measurement], "parameters": []}

    with pytest.raises(ValueError):
        validate_inverse_structural(inverse)
    with pytest.raises(ValueError, match="exactly one of file, files, or files_glob"):
        normalize_measurement_bindings({"__base_dir__": str(tmp_path), **inverse})


@pytest.mark.parametrize("field", ["condition_id", "state_group_id"])
def test_one_inverse_rejects_multiple_conditions_or_state_groups(tmp_path, field: str) -> None:
    common = {
        "instrument_id": "uvvis",
        "condition_id": "condition-a",
        "state_group_id": "state-a",
        "view_id": "view-a",
        "replicate_id": "rep-a",
        "stage": "model_ready",
        "output_basis": "relative_instrument_signal",
        "output_unit": "arb",
        "calibration_artifact": {"id": "response-v1", "sha256": "12" * 32},
    }
    first = {**common, "id": "a", "prediction_key": "chord_0", "file": "a.csv"}
    second = {
        **common,
        "id": "b",
        "prediction_key": "chord_1",
        "file": "b.csv",
        "view_id": "view-b",
        "replicate_id": "rep-b",
        field: f"{field}-b",
    }

    with pytest.raises(ValueError, match=f"only one {field}"):
        normalize_measurement_bindings(
            {"__base_dir__": str(tmp_path), "measurements": [first, second]}
        )


def test_plural_metadata_requires_singular_view_and_replicate_records(tmp_path) -> None:
    with pytest.raises(ValueError, match="scalar view_id or replicate_id"):
        normalize_measurement_bindings(
            {
                "__base_dir__": str(tmp_path),
                "measurements": [
                    {
                        "instrument_id": "uvvis",
                        "files": ["a.csv", "b.csv"],
                        "condition_id": "condition-a",
                        "view_id": "view-a",
                    }
                ],
            }
        )


def test_plural_measurements_may_share_condition_and_calibration_metadata(tmp_path) -> None:
    normalized = normalize_measurement_bindings(
        {
            "__base_dir__": str(tmp_path),
            "measurements": [
                {
                    "instrument_id": "uvvis",
                    "files": ["a.csv", "b.csv"],
                    "prediction_key": "chord_0",
                    "condition_id": "condition-a",
                    "state_group_id": "state-a",
                    "output_basis": "relative_instrument_signal",
                    "output_unit": "arb",
                }
            ],
        }
    )

    assert len(normalized) == 2
    assert {item["condition_id"] for item in normalized} == {"condition-a"}
    assert {item["state_group_id"] for item in normalized} == {"state-a"}
    assert [item["prediction_key"] for item in normalized] == ["chord_0", "chord_0"]


def test_missing_provenance_does_not_create_a_false_second_state(tmp_path) -> None:
    normalized = normalize_measurement_bindings(
        {
            "__base_dir__": str(tmp_path),
            "measurements": [
                {
                    "instrument_id": "uvvis",
                    "file": "a.csv",
                    "condition_id": "condition-a",
                },
                {"instrument_id": "uvvis", "file": "b.csv"},
            ],
        }
    )

    assert normalized[0]["condition_id"] == "condition-a"
    assert normalized[1]["condition_id"] == "condition-a"


def test_qc_status_excludes_nonvalid_pixels_from_residual(tmp_path) -> None:
    path = tmp_path / "qc.csv"
    _write_csv(
        path,
        "wavelength_nm,intensity,sigma,pixel_status,lower_bound,upper_bound\n"
        "500,1,1,valid,,\n"
        "501,999,,saturated,900,\n"
        "502,,,missing,,\n"
        "503,999,,spike,,\n"
        "504,5,1,valid,,\n",
    )
    measurement = load_measurement_csv(path, measurement_id="qc", prediction_key="chord_0")
    predicted = np.array([2.0, -10.0, -20.0, -30.0, 7.0])

    residual = spectrum_residual_blocks([(measurement, predicted)])[0]
    assert measurement.ordinary_residual_mask is not None
    assert measurement.ordinary_residual_mask.tolist() == [True, False, False, False, True]
    assert np.array_equal(residual, [1.0, 2.0])


def test_saturated_pixel_requires_lower_bound(tmp_path) -> None:
    path = tmp_path / "saturated.csv"
    _write_csv(
        path,
        "wavelength_nm,intensity,pixel_status\n"
        "500,1,valid\n"
        "501,10,saturated\n",
    )

    with pytest.raises(ValueError, match="finite lower_bound"):
        load_measurement_csv(path)


def test_covariance_is_refactored_on_final_valid_subset(tmp_path) -> None:
    path = tmp_path / "covariance.csv"
    covariance_path = tmp_path / "covariance_matrix.csv"
    _write_csv(
        path,
        "wavelength_nm,intensity,pixel_status,lower_bound\n"
        "500,1,valid,\n"
        "501,99,saturated,90\n"
        "502,3,valid,\n",
    )
    covariance = np.array([[4.0, 0.2, 1.0], [0.2, 16.0, 0.3], [1.0, 0.3, 9.0]])
    np.savetxt(covariance_path, covariance, delimiter=",")
    measurement = load_measurement_csv(path, covariance_path)
    predicted = np.array([3.0, -100.0, 6.0])

    residual = spectrum_residual_blocks([(measurement, predicted)])[0]
    expected = np.linalg.solve(
        np.linalg.cholesky(covariance[np.ix_([True, False, True], [True, False, True])]),
        np.array([2.0, 3.0]),
    )

    assert measurement.covariance is not None
    assert measurement.covariance_cholesky is not None
    assert measurement.covariance.shape == (3, 3)
    assert measurement.covariance_cholesky.shape == (2, 2)
    assert np.allclose(residual, expected)

    fit_window_mask = np.array([True, False, False])
    spectrum_residual_blocks([(measurement, predicted)], analysis_masks=[fit_window_mask])
    cache_size = len(measurement._covariance_cholesky_cache)
    spectrum_residual_blocks([(measurement, predicted)], analysis_masks=[fit_window_mask])
    assert len(measurement._covariance_cholesky_cache) == cache_size


def test_analysis_mask_is_intersected_with_qc_and_changes_fingerprint(tmp_path) -> None:
    path = tmp_path / "mask.csv"
    _write_csv(path, "wavelength_nm,intensity,sigma\n500,1,1\n501,2,1\n502,3,1\n")
    measurement = load_measurement_csv(path, measurement_id="m", prediction_key="chord_0")

    residual = spectrum_residual_blocks(
        [(measurement, np.array([2.0, 4.0, 8.0]))],
        analysis_masks=[np.array([True, False, True])],
    )[0]
    excluded = replace(
        measurement,
        pixel_status=np.array(["valid", "user_excluded", "valid"]),
        ordinary_residual_mask=np.array([True, False, True]),
    )

    assert np.array_equal(residual, [1.0, 5.0])
    assert measurement_sha256({"uvvis": [measurement]}) != measurement_sha256(
        {"uvvis": [excluded]}
    )
