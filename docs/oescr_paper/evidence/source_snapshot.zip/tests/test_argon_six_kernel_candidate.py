from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import numpy as np
import pytest
from scripts.run_argon_six_kernel_candidate import run_benchmark

from oescr.data.cross_section_db import CrossSectionLibrary
from oescr.data.lxcat import curve_data_sha256
from oescr.data.provenance import file_sha256
from oescr.forward.model import OESCRModel
from oescr.io.species_packs import SpeciesPackError, compose_species_packs
from oescr.io.yaml_loader import load_yaml

ROOT = Path(__file__).resolve().parents[1]
BUNDLE_DIR = ROOT / "examples" / "data" / "cross_sections_external" / "argon_zenodo_8192503"
BUNDLE_MANIFEST = BUNDLE_DIR / "manifest.yaml"
PACK_PATH = ROOT / "examples" / "data" / "species_packs" / "ar_4p_six_kernel_candidate.yaml"
NIST_BRANCH_ARTIFACT = ROOT / "examples" / "data" / "species_packs" / "ar_4p_six_kernel_nist_branches.yaml"
CASE_PATH = ROOT / "examples" / "benchmarks" / "ar_six_kernel_candidate" / "case_truth.yaml"


@pytest.fixture(scope="module")
def candidate_model() -> OESCRModel:
    return OESCRModel.from_yaml(CASE_PATH)


def test_zenodo_manifest_pins_each_cross_section_curve() -> None:
    manifest = load_yaml(BUNDLE_MANIFEST)
    source = manifest["source"]
    records = manifest["files"]

    assert manifest["format"] == "oescr_external_cross_section_bundle/v1"
    assert source["doi"] == "10.5281/zenodo.8192503"
    assert source["license"] == "CC-BY-4.0"
    assert source["size_bytes"] == 2_710_441
    assert source["md5"] == "c0c1073f5ea940568ce4925b8b242e1a"
    assert source["sha256"] == "a203418d62b3ff62d34f0d1d8ad670df27058bd62bb7d88a8f1405a6bdfa1c1b"
    assert [record["excitation_ordinal"] for record in records] == [10, 11, 12, 13, 14, 18]
    assert len(records) == 6

    library = CrossSectionLibrary()
    for record in records:
        path = BUNDLE_DIR / record["file"]
        curve = library.load(path)

        assert file_sha256(path) == record["file_sha256"]
        assert len(curve.energy_eV) == record["row_count"] == 200
        assert curve_data_sha256(curve.energy_eV, curve.sigma_m2) == record["curve_data_sha256"]
        assert curve.energy_eV[0] == pytest.approx(record["threshold_eV"])
        assert curve.sigma_m2[0] == 0.0


def test_candidate_inventory_has_six_distinct_upper_state_kernels(
    candidate_model: OESCRModel,
) -> None:
    inventory = candidate_model.compiled.emission_kernel_inventory
    records = inventory["records"]

    assert (
        len(candidate_model.cfg["states"]),
        len(candidate_model.cfg["reactions"]),
        len(candidate_model.cfg["transitions"]),
    ) == (6, 6, 17)
    assert inventory["kernel_count"] == 6
    assert inventory["upper_state_count"] == 6
    assert inventory["process_count"] == 6
    assert inventory["transition_count"] == 17
    assert inventory["evidence_counts"] == {"validation_candidate": 6}

    upper_states = {record["upper_state"] for record in records}
    process_ids = {process_id for record in records for process_id in record["process_ids"]}
    transition_ids = {transition_id for record in records for transition_id in record["transition_ids"]}
    assert len(upper_states) == 6
    assert len(process_ids) == 6
    assert len(transition_ids) == 17
    assert all(record["pathway"] == "direct_ground" for record in records)
    assert all(record["evidence"]["status"] == "validation_candidate" for record in records)
    assert all(len(record["process_ids"]) == 1 for record in records)
    assert all(len(record["evidence"]["process_artifacts"]) == 1 for record in records)

    verified_sources = candidate_model.compiled.species_pack_provenance[0]["verified_source_artifacts"]
    assert {artifact["id"] for artifact in verified_sources} == {
        "cross_section_manifest",
        "atomic_branches",
    }
    assert all(file_sha256(artifact["file"]) == artifact["sha256"] for artifact in verified_sources)

    manifest = load_yaml(BUNDLE_MANIFEST)
    manifest_by_state = {record["target_state"]: record for record in manifest["files"]}
    for record in records:
        artifact = record["evidence"]["process_artifacts"][0]
        assert artifact["process_id"] == record["process_ids"][0]
        assert artifact["sha256"] == manifest_by_state[record["upper_state"]]["file_sha256"]


def test_candidate_pack_matches_pinned_nist_branch_artifact() -> None:
    pack = load_yaml(PACK_PATH)
    artifact = load_yaml(NIST_BRANCH_ARTIFACT)
    pack_states = {state["id"]: state for state in pack["states"]}
    pack_transitions = {transition["id"]: transition for transition in pack["transitions"]}
    pack_kernels = {kernel["upper_state"]: kernel for kernel in pack["emission_kernels"]}

    assert artifact["format"] == "oescr_atomic_branch_artifact/v1"
    assert artifact["source"]["database"] == "NIST Atomic Spectra Database"
    assert artifact["source"]["version"] == 5.12
    assert artifact["source"]["doi"] == "10.18434/T4W30F"
    assert artifact["source"]["selection"] == ("all classified 4p-to-4s branches for the six declared upper states")

    artifact_states = {state["id"]: state for state in artifact["upper_states"]}
    artifact_branches = {
        branch["id"]: (upper["id"], branch) for upper in artifact["upper_states"] for branch in upper["branches"]
    }
    assert set(pack_states) == set(artifact_states)
    assert set(pack_transitions) == set(artifact_branches)
    assert len(artifact_branches) == 17

    for upper_id, upper in artifact_states.items():
        assert pack_states[upper_id]["energy_eV"] == upper["energy_eV"]
        assert set(pack_kernels[upper_id]["transition_ids"]) == {branch["id"] for branch in upper["branches"]}

    for transition_id, (upper_id, branch) in artifact_branches.items():
        transition = pack_transitions[transition_id]
        assert transition["upper"] == upper_id
        assert transition["lower"] == branch["lower"]
        assert transition["wavelength_nm"] == branch["wavelength_nm"]
        assert transition["A_s-1"] == branch["A_s-1"]


def test_species_pack_rejects_changed_pack_level_source_artifact() -> None:
    pack = deepcopy(load_yaml(PACK_PATH))
    pack["metadata"]["source_artifacts"]["atomic_branches"]["sha256"] = "0" * 64

    with pytest.raises(SpeciesPackError, match="source artifact 'atomic_branches'.*SHA-256 mismatch"):
        compose_species_packs({"species_packs": [pack]})


def test_candidate_forward_produces_finite_positive_emission(
    candidate_model: OESCRModel,
) -> None:
    result = candidate_model.predict()
    populations = np.asarray(list(result.zone_populations[0].values()), dtype=float)
    line_details = result.atomic_line_details[0]
    excitation_processes = [
        process for process in result.zone_diagnostics[0].processes if process["kind"] == "electron_excitation"
    ]
    rate_coefficients = np.asarray(
        [process["coefficient_value"] for process in excitation_processes],
        dtype=float,
    )

    assert populations.size == 6
    assert np.all(np.isfinite(populations))
    assert np.all(populations > 0.0)
    assert len(excitation_processes) == 6
    assert np.all(np.isfinite(rate_coefficients))
    assert np.all(rate_coefficients > 0.0)
    for process in excitation_processes:
        coverage = process["cross_section"]
        assert coverage["lower_extrapolation"] == "zero_below_threshold"
        assert coverage["covered_probability"] == pytest.approx(1.0, abs=1.0e-10)
        assert coverage["probability_below_data"] > 0.8
        assert coverage["probability_above_data"] == pytest.approx(0.0)
        assert coverage["probability_below_threshold"] > 0.8
        assert coverage["probability_below_threshold"] == pytest.approx(coverage["probability_below_data"])
        assert coverage["uncovered_probability"] == pytest.approx(0.0)
    assert len(line_details) == 17
    assert all(np.isfinite(line["integrated_emissivity_W_m3_sr"]) for line in line_details)
    assert all(line["integrated_emissivity_W_m3_sr"] > 0.0 for line in line_details)
    assert np.all(np.isfinite(result.zone_emissivity))
    assert float(np.max(result.zone_emissivity)) > 0.0
    assert set(result.spectra) == {"vis_650_850", "nir_840_1050"}

    for chord_map in result.spectra.values():
        for spectrum in chord_map.values():
            wavelength_nm = np.asarray(spectrum["wavelength_nm"], dtype=float)
            intensity = np.asarray(spectrum["intensity"], dtype=float)
            assert np.all(np.isfinite(wavelength_nm))
            assert np.all(np.isfinite(intensity))
            assert float(np.max(intensity)) > 0.0
            assert float(np.trapezoid(intensity, wavelength_nm)) > 0.0

    assert result.provenance["emission_kernels"] == candidate_model.compiled.emission_kernel_inventory


def test_candidate_benchmark_recovers_temperature_and_writes_auditable_bundle(
    tmp_path: Path,
) -> None:
    result = run_benchmark(tmp_path)
    summary = result["summary"]
    claim = result["claim"]

    assert summary["software_recovery_pass"] is True
    assert summary["measurement_count"] == 6
    assert summary["model_ready_package_count"] == 6
    assert summary["spectral_channel_count"] == 2
    assert summary["fit_distinct_kernel_count"] == 5
    assert summary["heldout_distinct_kernel_count"] == 1
    assert summary["heldout_distinct_kernel_ids"] == ["Ar_ground_2p10"]
    assert summary["estimated_te_eV"] == pytest.approx(4.0, rel=0.01)
    assert summary["score_metrics"]["distinct_kernel_holdout"]["standardized_rmse"] < 1.0
    assert summary["kernel_log_sensitivity_span_at_truth"] > 1.0
    assert claim["scientific_status"] == "abstain_external_validation"
    assert claim["electron_density"] == "fixed_input_not_estimated"
    assert claim["eedf"] == "derived_from_fitted_te_not_independently_reconstructed"

    expected_files = [
        "case_opt.yaml",
        "claim.yaml",
        "derived_maxwellian_eedf.csv",
        "fit_summary.yaml",
        "inverse_config.yaml",
        "kernel_inventory.yaml",
        "kernel_sensitivity.yaml",
        "measurement_set.yaml",
        "optimization_trace.csv",
        "result.yaml",
        "temperature_profile.csv",
        "figures/benchmark_overview.png",
        "figures/benchmark_overview.svg",
    ]
    assert all((tmp_path / relative_path).is_file() for relative_path in expected_files)
    package_dirs = list((tmp_path / "observation_packages").iterdir())
    assert len(package_dirs) == 6
    assert all((path / "package_manifest.yaml").is_file() for path in package_dirs)
    assert all((path / "generated" / "provenance.yaml").is_file() for path in package_dirs)
    assert len(list((tmp_path / "spectra").glob("*.csv"))) == 6
    assert len(list((tmp_path / "audit_spectra").glob("*.csv"))) == 6

    measurement_set = load_yaml(tmp_path / "measurement_set.yaml")
    assert len(measurement_set["measurements"]) == 6
    assert {entry["condition_id"] for entry in measurement_set["measurements"]} == {
        "ar_candidate_condition_001"
    }
    assert {entry["state_group_id"] for entry in measurement_set["measurements"]} == {
        "ar_candidate_shared_state_001"
    }

    canonical_result = load_yaml(tmp_path / "result.yaml")
    assert canonical_result["parameters"]["electron_temperature_eV"] == pytest.approx(4.0, rel=0.01)
    assert len(canonical_result["spectral_fits"]) == 6

    spectrum_header = (tmp_path / "audit_spectra" / "vis_650_850_rep_0.csv").read_text(
        encoding="utf-8"
    ).splitlines()[0]
    assert spectrum_header.split(",") == [
        "wavelength_nm",
        "measured",
        "initial_prediction",
        "predicted",
        "sigma",
        "pixel_status",
        "fit_mask",
        "score_mask",
    ]
