from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from oescr.data.cross_section_db import CrossSectionLibrary
from oescr.physics.rates import RateCalculator


def _write_curve(path: Path, *, metadata: str = "") -> None:
    path.write_text(
        f"{metadata}energy_eV,sigma_m2\n5.0,0.0\n7.0,2.0e-20\n10.0,1.0e-20\n",
        encoding="utf-8",
    )


def _calculator() -> tuple[RateCalculator, np.ndarray]:
    energy_eV = np.linspace(0.0, 10.0, 101)
    eedf_pdf = np.full(energy_eV.shape, 0.1)
    return RateCalculator(energy_eV, CrossSectionLibrary()), eedf_pdf


def test_declared_threshold_zero_region_counts_as_evaluable_coverage(
    tmp_path: Path,
) -> None:
    path = tmp_path / "thresholded.csv"
    _write_curve(
        path,
        metadata=("# threshold_eV: 5.0\n# lower_extrapolation: zero_below_threshold\n"),
    )
    calculator, eedf_pdf = _calculator()

    coverage = calculator.cross_section_coverage(str(path), eedf_pdf)

    assert coverage.covered_probability == pytest.approx(1.0)
    assert coverage.probability_below_data > 0.45
    assert coverage.probability_above_data == pytest.approx(0.0)
    assert coverage.probability_below_threshold > 0.45
    assert coverage.probability_below_threshold == pytest.approx(coverage.probability_below_data)
    assert coverage.uncovered_probability == pytest.approx(0.0)
    assert coverage.threshold_eV == pytest.approx(5.0)
    assert coverage.lower_extrapolation == "zero_below_threshold"


def test_undeclared_lower_range_remains_uncovered(tmp_path: Path) -> None:
    path = tmp_path / "uncovered.csv"
    _write_curve(path)
    calculator, eedf_pdf = _calculator()

    coverage = calculator.cross_section_coverage(str(path), eedf_pdf)

    assert coverage.covered_probability < 0.55
    assert coverage.probability_below_data > 0.45
    assert coverage.probability_below_threshold == pytest.approx(0.0)
    assert coverage.uncovered_probability == pytest.approx(coverage.probability_below_data)
    assert coverage.threshold_eV is None
    assert coverage.lower_extrapolation == "uncovered"


@pytest.mark.parametrize(
    "metadata, message",
    [
        ("# lower_extrapolation: zero_below_threshold\n", "no threshold_eV"),
        (
            "# threshold_eV: 4.9\n# lower_extrapolation: zero_below_threshold\n",
            "must equal its first tabulated energy",
        ),
        (
            "# threshold_eV: 5.0\n# lower_extrapolation: unsupported\n",
            "unsupported lower_extrapolation",
        ),
    ],
)
def test_invalid_lower_boundary_contract_is_rejected(
    tmp_path: Path,
    metadata: str,
    message: str,
) -> None:
    path = tmp_path / "invalid.csv"
    _write_curve(path, metadata=metadata)
    calculator, eedf_pdf = _calculator()

    with pytest.raises(ValueError, match=message):
        calculator.rate_from_cross_section_file(str(path), eedf_pdf)
