import subprocess
import sys
from copy import deepcopy
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from oescr.forward.model import OESCRModel
from oescr.inverse.measurements import load_measurements
from oescr.inverse.optimize import InverseSolver
from oescr.io.project import load_project
from oescr.io.yaml_loader import load_yaml

EXAMPLES = Path('examples')
BENCH = EXAMPLES / 'benchmarks'


def test_yaml_include_for_case_init():
    case = load_yaml(EXAMPLES / 'case_init_cf4_o2_ar.yaml')
    assert len(case['species_packs']) == 2
    assert case['bands']
    assert case['plasma_state']['te_shells_eV'][0] == 2.1


def test_root_import_does_not_eagerly_load_optimizer():
    output = subprocess.check_output(
        [
            sys.executable,
            "-c",
            "import sys, oescr; print('scipy.optimize' in sys.modules)",
        ],
        cwd=Path(__file__).resolve().parents[1],
        text=True,
    )
    assert output.strip() == "False"


@pytest.mark.parametrize(
    "indices, expected_names",
    [("all", ["ne0", "ne1", "ne2", "te0", "te1", "te2"]),
     ([0, 2], ["ne0", "ne2", "te0", "te1", "te2"])],
)
def test_parameter_groups_expand_for_inverse(indices, expected_names):
    inverse = load_yaml(EXAMPLES / 'inverse_cf4_o2_ar.yaml')
    inverse['parameter_groups'][0]['indices'] = indices
    solver = InverseSolver(load_yaml(EXAMPLES / 'case_init_cf4_o2_ar.yaml'), inverse)
    assert [parameter.name for parameter in solver.params.params] == expected_names


def test_yaml_preserves_quoted_identifiers_and_reads_plain_scientific_notation(tmp_path):
    source = tmp_path / 'input.yaml'
    source.write_text(
        'id: "001"\ncondition_id: "20261027"\n'
        'sha256: "' + '0' * 64 + '"\n'
        'density: 1e16\nrate: 2.5e-15\nquoted_number: "1e16"\n',
        encoding='utf-8',
    )
    loaded = load_yaml(source)
    assert loaded['id'] == '001'
    assert loaded['condition_id'] == '20261027'
    assert loaded['sha256'] == '0' * 64
    assert loaded['quoted_number'] == '1e16'
    assert loaded['density'] == 1e16
    assert loaded['rate'] == 2.5e-15


@pytest.mark.parametrize("pattern", ["*.csv", "${THIS_DIR}/*.csv"])
def test_included_measurement_glob_uses_fragment_directory(tmp_path, pattern):
    fragment_dir = tmp_path / 'fragments'
    fragment_dir.mkdir()
    measurement_text = 'wavelength_nm,intensity,sigma\n500,1,0.1\n501,2,0.1\n'
    (fragment_dir / 'right.csv').write_text(measurement_text, encoding='utf-8')
    (tmp_path / 'wrong.csv').write_text(measurement_text.replace(',1,', ',9,'), encoding='utf-8')
    (fragment_dir / 'inverse.yaml').write_text(
        f'measurements:\n  - instrument_id: uvvis\n    files_glob: "{pattern}"\n'
        '    prediction_key: chord_0\n',
        encoding='utf-8',
    )
    project = tmp_path / 'inverse.yaml'
    project.write_text('include: fragments/inverse.yaml\n', encoding='utf-8')
    measurements = load_measurements(load_yaml(project))['uvvis']
    assert len(measurements) == 1
    np.testing.assert_array_equal(measurements[0].intensity, [1.0, 2.0])


def test_project_case_runs():
    project = load_project(BENCH / 'nf3_ar_ccp_clean_2023' / 'project.yaml')
    model = OESCRModel.from_yaml(project.case_yaml)
    result = model.predict()
    assert 'nf3_benchmark_uvvis' in result.spectra


def test_runtime_parameter_override_reuses_compiled_structure():
    model = OESCRModel.from_yaml(EXAMPLES / 'case_init_cf4_o2_ar.yaml')
    runtime_cfg = deepcopy(model.cfg)
    runtime_cfg['plasma_state']['te_shells_eV'][0] *= 1.1

    _, plan = model._execution_plan(runtime_cfg)

    assert plan is model.compiled


def test_structural_reaction_override_is_recompiled_and_changes_prediction():
    model = OESCRModel.from_yaml(EXAMPLES / 'case_init_cf4_o2_ar.yaml')
    baseline = model.predict()
    changed_cfg = deepcopy(model.cfg)
    changed_cfg['reactions'][0].pop('cross_section_file')
    changed_cfg['reactions'][0]['coefficient_m3_s'] = 0.0

    _, plan = model._execution_plan(changed_cfg)
    changed = model.predict(changed_cfg)

    assert plan is not model.compiled
    assert not np.array_equal(changed.zone_emissivity, baseline.zone_emissivity)
    assert '_fine_wavelength_nm' not in model.cfg
    assert '_instrument_cfgs' not in model.cfg


def test_mutating_public_model_config_cannot_bypass_recompilation():
    model = OESCRModel.from_yaml(EXAMPLES / 'case_init_cf4_o2_ar.yaml')
    baseline = model.predict()
    model.cfg['reactions'][0].pop('cross_section_file')
    model.cfg['reactions'][0]['coefficient_m3_s'] = 0.0

    changed = model.predict()

    assert not np.array_equal(changed.zone_emissivity, baseline.zone_emissivity)


def test_forward_result_exposes_component_and_solver_diagnostics():
    model = OESCRModel.from_yaml(EXAMPLES / 'case_init_cf4_o2_ar.yaml')
    result = model.predict()

    assert np.allclose(
        result.zone_emissivity,
        result.zone_atomic_emissivity + result.zone_band_emissivity,
    )
    for zone_index, components in enumerate(result.zone_band_components):
        component_sum = np.sum(list(components.values()), axis=0)
        assert np.allclose(result.zone_band_emissivity[zone_index], component_sum)

    for diagnostics in result.zone_diagnostics:
        assert np.isclose(diagnostics.eedf.normalization, 1.0)
        assert diagnostics.eedf.mean_energy_eV > 0.0
        assert diagnostics.cr.matrix_rank > 0
        assert diagnostics.cr.relative_residual >= 0.0
        cross_sections = [
            reaction['cross_section']
            for reaction in diagnostics.reactions
            if 'cross_section' in reaction
        ]
        assert cross_sections
        assert all(len(item['sha256']) == 64 for item in cross_sections)
        assert all(0.0 <= item['covered_probability'] <= 1.0 + 1.0e-12 for item in cross_sections)

    assert result.emission_basis.startswith('mixed')
    assert result.emission_component_bases['atomic_lines'].startswith('spectral_radiant_power')


def test_spectrum_only_prediction_matches_full_prediction_without_audit_work(monkeypatch):
    model = OESCRModel.from_yaml(EXAMPLES / 'case_init_cf4_o2_ar.yaml')
    expected = model.predict().spectra

    def audit_work_is_not_allowed(*_args, **_kwargs):
        raise AssertionError('spectrum-only prediction must not construct audit diagnostics')

    monkeypatch.setattr(model.compiled.atomic_solver, 'solve_zone', audit_work_is_not_allowed)
    monkeypatch.setattr(
        model.compiled.rate_calculator,
        'cross_section_coverage',
        audit_work_is_not_allowed,
    )
    monkeypatch.setattr(model, '_build_quality_report', audit_work_is_not_allowed)

    actual = model.predict_spectra()

    assert actual.keys() == expected.keys()
    for instrument_id, expected_chords in expected.items():
        assert actual[instrument_id].keys() == expected_chords.keys()
        for chord_key, expected_spectrum in expected_chords.items():
            assert np.array_equal(
                actual[instrument_id][chord_key]['wavelength_nm'],
                expected_spectrum['wavelength_nm'],
            )
            assert np.allclose(
                actual[instrument_id][chord_key]['intensity'],
                expected_spectrum['intensity'],
                rtol=1.0e-13,
                atol=0.0,
            )

    monkeypatch.setattr(model, '_execution_plan', audit_work_is_not_allowed)
    compiled_actual = model.runtime_spectrum_model().predict_spectra(model.cfg)
    for instrument_id, chords in actual.items():
        for chord_key, spectrum in chords.items():
            assert np.array_equal(
                compiled_actual[instrument_id][chord_key]['intensity'],
                spectrum['intensity'],
            )


def test_runtime_spectrum_prediction_rejects_invalid_density_values() -> None:
    model = OESCRModel.from_yaml(
        EXAMPLES / 'use_cases' / 'two_band' / 'case_absolute_init.yaml'
    )

    missing_zone = deepcopy(model.cfg)
    missing_zone['plasma_state']['ne_shells_m3'] = []
    with np.testing.assert_raises_regex(ValueError, 'has no value for zone 0'):
        model.runtime_spectrum_model().predict_spectra(missing_zone)

    negative_density = deepcopy(model.cfg)
    negative_density['plasma_state']['ne_shells_m3'][0] = -1.0
    with np.testing.assert_raises_regex(ValueError, 'finite, non-negative densities'):
        model.runtime_spectrum_model().predict_spectra(negative_density)


def test_runtime_spectrum_model_rejects_structural_changes() -> None:
    model = OESCRModel.from_yaml(
        EXAMPLES / 'use_cases' / 'two_band' / 'case_absolute_init.yaml'
    )
    changed = deepcopy(model.cfg)
    changed['instruments'][0]['wavelength_grid_nm'][1] += 0.1

    with np.testing.assert_raises_regex(ValueError, 'runtime-state changes only'):
        model.runtime_spectrum_model().predict_spectra(changed)
