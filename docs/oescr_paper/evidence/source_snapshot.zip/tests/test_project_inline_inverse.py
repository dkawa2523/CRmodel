from __future__ import annotations

import subprocess
import sys
from copy import deepcopy
from pathlib import Path
from shutil import copyfile
from typing import Any

import numpy as np
import pytest
from scripts import dump_resolved_config, run_project, validate_project

from oescr import cli
from oescr.forward.model import OESCRModel
from oescr.inverse.optimize import InverseSolver
from oescr.inverse.reporting import write_fit_result
from oescr.io.normalize import normalize_inverse_config
from oescr.io.project import load_project
from oescr.io.schema import ConfigSchemaError
from oescr.io.yaml_loader import load_yaml, save_yaml

ROOT = Path(__file__).resolve().parents[1]
TWO_BAND = ROOT / "examples" / "use_cases" / "two_band"
QUICKSTART = ROOT / "examples" / "project_quickstart_ar_o2.yaml"


def _public_config(path: Path) -> dict[str, Any]:
    config = deepcopy(load_yaml(path))
    config.pop("__base_dir__", None)
    config.pop("__path__", None)
    return config


def test_external_inverse_path_remains_supported() -> None:
    project_path = ROOT / "examples" / "project_cf4_o2_ar.yaml"
    project = load_project(project_path)

    assert project.inverse_yaml == (project_path.parent / "inverse_cf4_o2_ar.yaml").resolve()
    assert project.inverse_yaml is not None
    assert project.inline_inverse is None
    assert project.load_inverse_config() == load_yaml(project.inverse_yaml)


def test_dumped_group_config_runs_and_optimized_case_reloads(tmp_path: Path, monkeypatch) -> None:
    source = tmp_path / "source"
    source.mkdir()
    case_cfg = _public_config(TWO_BAND / "case_absolute_init.yaml")
    instrument = case_cfg["instruments"][0]
    save_yaml(instrument, source / "instrument.yaml")
    case_cfg["instruments"] = [{"id": instrument["id"], "yaml_file": "instrument.yaml"}]
    save_yaml(case_cfg, source / "case.yaml")
    for name in ("measurement.csv", "windows.yaml"):
        copyfile(TWO_BAND / name, source / name)
    inverse = _public_config(TWO_BAND / "inverse_absolute.yaml")
    parameter = inverse.pop("parameters")[0]
    inverse["parameter_groups"] = [{
        "path": "plasma_state.ne_shells_m3", "name_prefix": "ne",
        "scale": parameter["scale"], "bounds": parameter["bounds"],
    }]
    save_yaml(inverse, source / "inverse.yaml")

    exported = tmp_path / "exported"
    monkeypatch.setattr(sys, "argv", [
        "dump_resolved_config.py", str(source / "case.yaml"), str(source / "inverse.yaml"),
        "--out", str(exported),
    ])
    dump_resolved_config.main()
    resolved_case = load_yaml(exported / "case_resolved.yaml")
    resolved_inverse = load_yaml(exported / "inverse_resolved.yaml")
    assert resolved_inverse == normalize_inverse_config(resolved_case, resolved_inverse)
    assert "parameter_groups" not in resolved_inverse

    solver = InverseSolver(resolved_case, resolved_inverse)
    fit = solver.fit()
    assert fit.success
    assert fit.parameters["ne0"] == pytest.approx(3.0e16)
    output = tmp_path / "fit"
    write_fit_result(fit, output)
    reloaded = OESCRModel.from_yaml(output / "case_opt.yaml").predict_spectra()
    np.testing.assert_allclose(
        reloaded["two_band_radiance"]["chord_0"]["intensity"], fit.spectral_fits[0].predicted,
    )


def test_forward_only_project_defaults_to_forward_and_preserves_fragment_output_dir(
    tmp_path: Path, monkeypatch,
) -> None:
    fragment = tmp_path / "fragment"
    fragment.mkdir()
    save_yaml({
        "kind": "oescr_project", "case": str(TWO_BAND / "case_truth.yaml"),
        "outputs": {"default_dir": "outputs"},
    }, fragment / "project.yaml")
    root_project = tmp_path / "project.yaml"
    root_project.write_text("include: fragment/project.yaml\n", encoding="utf-8")
    monkeypatch.setattr(sys, "argv", ["run_project.py", str(root_project)])
    run_project.main()
    assert (fragment / "outputs" / "two_band_radiance_chord_0.csv").is_file()


def test_validate_project_compiles_the_case_once(monkeypatch) -> None:
    import oescr.forward.model as model_module

    original_compile = model_module.compile_case
    calls = []

    def tracked_compile(cfg):
        calls.append(cfg)
        return original_compile(cfg)

    monkeypatch.setattr(model_module, "compile_case", tracked_compile)
    monkeypatch.setattr(sys, "argv", ["validate_project.py", str(QUICKSTART)])
    validate_project.main()
    assert len(calls) == 1


def test_inline_inverse_paths_are_relative_to_project_directory(tmp_path: Path) -> None:
    copyfile(TWO_BAND / "measurement.csv", tmp_path / "measurement.csv")
    copyfile(TWO_BAND / "windows.yaml", tmp_path / "windows.yaml")
    project_path = tmp_path / "project.yaml"
    inline_inverse = _public_config(TWO_BAND / "inverse_ratio.yaml")
    save_yaml(
        {
            "kind": "oescr_project",
            "case": str((TWO_BAND / "case_truth.yaml").resolve()),
            "inverse": inline_inverse,
        },
        project_path,
    )

    project = load_project(project_path)
    loaded_inverse = project.load_inverse_config()

    assert project.inverse_yaml is None
    assert loaded_inverse is not None
    assert loaded_inverse["__base_dir__"] == str(tmp_path.resolve())
    solver = InverseSolver(load_yaml(project.case_yaml), loaded_inverse)
    assert list(solver.measurements) == ["two_band_radiance"]
    assert [window["name"] for window in solver.windows] == [
        "target_500",
        "actinometer_510",
    ]


def test_shared_maxwellian_quickstart_runs_without_fit_or_audit_configuration() -> None:
    project = load_project(QUICKSTART)
    inverse_config = project.load_inverse_config()

    assert inverse_config is not None
    assert "fit" not in inverse_config
    assert "window_selection" not in inverse_config
    assert inverse_config["parameters"][0]["path"] == "eedf.zones[0].te_eV"

    solver = InverseSolver(load_yaml(project.case_yaml), inverse_config)
    assert solver.inv_cfg["window_selection"] == {"mode": "full_spectrum"}
    result = solver.fit()

    assert result.success
    assert result.parameters["electron_temperature_eV"] == pytest.approx(3.5, rel=0.02)
    assert result.parameters["electron_density_m3"] == pytest.approx(2.0e16, rel=0.04)
    assert result.identifiability is None
    assert result.uncertainty is None
    assert result.parameter_profiles is None


def test_installed_cli_forward_and_inverse_write_standard_results(tmp_path: Path) -> None:
    forward = tmp_path / "forward"
    assert cli.main(["forward", str(TWO_BAND / "case_truth.yaml"), "--out", str(forward), "--audit"]) == 0
    assert (forward / "two_band_radiance_chord_0.csv").is_file()
    assert (forward / "diagnostics.yaml").is_file()
    inverse = tmp_path / "inverse"
    assert cli.main([
        "inverse", str(TWO_BAND / "case_absolute_init.yaml"), str(TWO_BAND / "inverse_absolute.yaml"),
        "--out", str(inverse), "--record-trace",
    ]) == 0
    persisted = load_yaml(inverse / "result.yaml")
    assert persisted["success"]
    assert persisted["parameters"]["electron_density_m3"] == pytest.approx(3.0e16)
    assert "optimization_trace" in persisted["audit"]


def test_cli_input_errors_are_short_and_internal_errors_propagate(tmp_path: Path, capsys, monkeypatch) -> None:
    invalid = tmp_path / "invalid.yaml"
    invalid.write_text("case: [\n", encoding="utf-8")
    for path in (tmp_path / "missing.yaml", invalid):
        assert cli.main(["validate", str(path)]) == 2
        error = capsys.readouterr().err
        assert error.startswith("oescr:")
        assert "Traceback" not in error

    def unexpected_error(_args):
        raise RuntimeError("internal failure")

    monkeypatch.setattr(cli, "_execute", unexpected_error)
    with pytest.raises(RuntimeError, match="internal failure"):
        cli.main(["forward", "case.yaml"])


def test_cli_help_and_version_do_not_import_numerical_workflows() -> None:
    subprocess.run(
        [sys.executable, "-c", """
import sys
from oescr.cli import main
for args in (["--help"], ["--version"], ["run", "--help"]):
    try:
        main(args)
    except SystemExit as exc:
        assert exc.code == 0
assert not any(name in sys.modules for name in ("numpy", "scipy", "yaml"))
"""],
        cwd=ROOT, check=True, capture_output=True, text=True,
    )


@pytest.mark.parametrize("inverse", [[], 1, True])
def test_project_rejects_non_path_non_mapping_inverse(tmp_path: Path, inverse: object) -> None:
    project_path = tmp_path / "project.yaml"
    save_yaml(
        {
            "kind": "oescr_project",
            "case": "case.yaml",
            "inverse": inverse,
        },
        project_path,
    )

    with pytest.raises(ConfigSchemaError, match="inverse"):
        load_project(project_path)
