from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

import pytest

import oescr.forward.compiled as compiled_module
import oescr.io.normalize as normalize_module
import oescr.io.species_packs as species_packs_module
from oescr.forward.model import OESCRModel
from oescr.inverse.optimize import InverseSolver
from oescr.io.yaml_loader import load_yaml, save_yaml

ROOT = Path(__file__).resolve().parents[1]


def test_instrument_reference_owns_its_alias_and_loaded_ids_are_unique(tmp_path: Path) -> None:
    cfg = load_yaml(ROOT / "examples" / "benchmarks" / "physical_band_analytic" / "case.yaml")
    instrument_file = tmp_path / "instrument.yaml"
    save_yaml(cfg["instruments"][0], instrument_file)
    cfg["instruments"] = [{"id": "channel_a", "yaml_file": str(instrument_file)}]
    model = OESCRModel(cfg)
    assert list(model.predict_spectra()) == ["channel_a"]
    cfg["instruments"] = [{"yaml_file": str(instrument_file)}] * 2
    with pytest.raises(ValueError, match="Duplicate effective instrument id"):
        compiled_module.load_instrument_configs(cfg)


def _track_pack_composition(monkeypatch) -> list[Dict[str, Any]]:
    calls: list[Dict[str, Any]] = []
    original = species_packs_module.compose_species_packs

    def tracked(cfg: Dict[str, Any]):
        calls.append(cfg)
        return original(cfg)

    monkeypatch.setattr(compiled_module, "compose_species_packs", tracked)
    monkeypatch.setattr(normalize_module, "compose_species_packs", tracked)
    return calls


def test_model_compilation_composes_species_packs_once(monkeypatch) -> None:
    calls = _track_pack_composition(monkeypatch)
    case_cfg = load_yaml(
        ROOT / "examples" / "benchmarks" / "ar_six_kernel_candidate" / "case_truth.yaml"
    )

    model = OESCRModel(case_cfg)

    assert len(calls) == 1
    assert "species_packs" not in model.cfg
    assert model.compiled.species_pack_provenance


def test_inverse_solver_reuses_the_compiled_canonical_case(monkeypatch) -> None:
    calls = _track_pack_composition(monkeypatch)
    case_cfg = load_yaml(ROOT / "examples" / "case_init_cf4_o2_ar.yaml")
    inverse_cfg = load_yaml(ROOT / "examples" / "inverse_cf4_o2_ar.yaml")

    solver = InverseSolver(case_cfg, inverse_cfg)

    assert len(calls) == 1
    assert solver.case_cfg == solver.model.cfg
