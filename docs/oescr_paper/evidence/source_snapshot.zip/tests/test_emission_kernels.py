from __future__ import annotations

import json
from pathlib import Path

import pytest

from oescr.data.emission_kernels import EmissionKernelError
from oescr.data.provenance import file_sha256
from oescr.forward.compiled import compile_case
from oescr.forward.model import OESCRModel
from oescr.io.schema import ConfigSchemaError


def _write_cross_section(path: Path) -> None:
    path.write_text(
        "energy_eV,sigma_m2\n0.0,0.0\n1.0,1.0e-20\n10.0,2.0e-20\n",
        encoding="utf-8",
    )


def _case(cross_section: Path) -> dict:
    return {
        "plasma_mode": "te",
        "gas_mixture": {
            "total_pressure_Pa": 1.0,
            "gas_temperature_K": 300.0,
            "fractions": {"Ar": 1.0},
        },
        "geometry": {
            "mode": "axisym_shell",
            "chamber_radius_m": 0.1,
            "chord_r_m": [0.0],
            "n_shells": 1,
        },
        "plasma_state": {
            "ne_shells_m3": [1.0e16],
            "te_shells_eV": [2.0],
        },
        "states": [
            {
                "id": "Ar_upper",
                "species": "Ar",
                "energy_eV": 1.0,
                "solve": True,
            }
        ],
        "reactions": [
            {
                "id": "excitation",
                "kind": "electron_excitation",
                "source_state": "Ar",
                "target_state": "Ar_upper",
                "cross_section_file": str(cross_section),
            }
        ],
        "transitions": [
            {
                "id": "line",
                "upper": "Ar_upper",
                "lower": "Ar_ground",
                "wavelength_nm": 500.0,
                "A_s-1": 1.0e7,
            }
        ],
        "emission_kernels": [
            {
                "id": "Ar_direct",
                "upper_state": "Ar_upper",
                "process_ids": ["excitation"],
                "transition_ids": ["line"],
                "pathway": "direct_ground",
                "evidence": {
                    "status": "validation_candidate",
                    "reference": "Unit-test source",
                    "limitations": ["Synthetic test curve"],
                    "process_artifacts": [
                        {
                            "process_id": "excitation",
                            "sha256": file_sha256(cross_section),
                        }
                    ],
                },
            }
        ],
        "instruments": [
            {
                "id": "spectrometer",
                "wavelength_min_nm": 499.0,
                "wavelength_max_nm": 501.0,
                "bin_nm": 0.2,
                "throughput": 1.0,
                "lsf": {"kind": "gaussian", "fwhm_nm": 0.1},
                "baseline": {"kind": "constant", "offset": 0.0},
            }
        ],
    }


def test_compiled_inventory_is_serializable_and_propagates_to_provenance(tmp_path: Path) -> None:
    cross_section = tmp_path / "excitation.csv"
    _write_cross_section(cross_section)
    cfg = _case(cross_section)

    model = OESCRModel(cfg)
    inventory = model.compiled.emission_kernel_inventory

    assert inventory == {
        "kernel_count": 1,
        "upper_state_count": 1,
        "process_count": 1,
        "transition_count": 1,
        "evidence_counts": {"validation_candidate": 1},
        "records": cfg["emission_kernels"],
    }
    json.dumps(inventory)
    assert model.predict().provenance["emission_kernels"] == inventory


def test_cases_without_emission_kernels_remain_supported(tmp_path: Path) -> None:
    cross_section = tmp_path / "excitation.csv"
    _write_cross_section(cross_section)
    cfg = _case(cross_section)
    cfg.pop("emission_kernels")

    inventory = compile_case(cfg).emission_kernel_inventory

    assert inventory["kernel_count"] == 0
    assert inventory["records"] == []


@pytest.mark.parametrize(
    ("mutation", "message"),
    [
        (lambda cfg: cfg["emission_kernels"][0]["process_ids"].append("missing"), "unknown reaction"),
        (
            lambda cfg: cfg["reactions"][0].update(target_state="Ar_other"),
            "must target upper_state",
        ),
        (
            lambda cfg: cfg["transitions"][0].update(upper="Ar_other"),
            "must use upper_state",
        ),
    ],
)
def test_kernel_references_must_resolve_to_the_declared_upper_state(
    tmp_path: Path,
    mutation,
    message: str,
) -> None:
    cross_section = tmp_path / "excitation.csv"
    _write_cross_section(cross_section)
    cfg = _case(cross_section)
    cfg["states"].append({"id": "Ar_other", "species": "Ar", "energy_eV": 2.0, "solve": True})
    mutation(cfg)

    with pytest.raises(EmissionKernelError, match=message):
        compile_case(cfg)


def test_process_artifact_hash_is_structurally_and_physically_verified(tmp_path: Path) -> None:
    cross_section = tmp_path / "excitation.csv"
    _write_cross_section(cross_section)
    cfg = _case(cross_section)
    artifact = cfg["emission_kernels"][0]["evidence"]["process_artifacts"][0]

    artifact["sha256"] = "not-a-sha"
    with pytest.raises(ConfigSchemaError, match="sha256"):
        compile_case(cfg)

    artifact["sha256"] = "0" * 64
    with pytest.raises(EmissionKernelError, match="SHA-256 mismatch"):
        compile_case(cfg)


@pytest.mark.parametrize("status", ["validation_candidate", "qualified"])
def test_candidate_and_qualified_evidence_require_every_process_artifact(
    tmp_path: Path,
    status: str,
) -> None:
    cross_section = tmp_path / "excitation.csv"
    _write_cross_section(cross_section)
    cfg = _case(cross_section)
    evidence = cfg["emission_kernels"][0]["evidence"]
    evidence["status"] = status
    evidence.pop("process_artifacts")

    with pytest.raises(EmissionKernelError, match="requires verified artifacts for every process"):
        compile_case(cfg)


def test_species_pack_namespaces_kernel_and_all_internal_references(tmp_path: Path) -> None:
    cross_section = tmp_path / "pack_curve.csv"
    _write_cross_section(cross_section)
    digest = file_sha256(cross_section)
    pack_path = tmp_path / "pack.yaml"
    pack_path.write_text(
        "\n".join(
            [
                "kind: oescr_species_pack",
                "states:",
                "  - id: upper",
                "    species: Ar",
                "    energy_eV: 1.0",
                "    solve: true",
                "reactions:",
                "  - id: process",
                "    kind: electron_excitation",
                "    source_state: Ar",
                "    target_state: upper",
                "    cross_section_file: pack_curve.csv",
                "transitions:",
                "  - id: transition",
                "    upper: upper",
                "    lower: ground",
                "    wavelength_nm: 500.0",
                "    A_s-1: 1.0e7",
                "emission_kernels:",
                "  - id: kernel",
                "    upper_state: upper",
                "    process_ids: [process]",
                "    transition_ids: [transition]",
                "    pathway: direct_ground",
                "    evidence:",
                "      status: qualified",
                "      reference: Unit-test pack",
                "      limitations: []",
                "      process_artifacts:",
                "        - process_id: process",
                f"          sha256: {digest}",
            ]
        ),
        encoding="utf-8",
    )
    cfg = _case(cross_section)
    cfg["states"] = []
    cfg["reactions"] = []
    cfg["transitions"] = []
    cfg.pop("emission_kernels")
    cfg["species_packs"] = [{"yaml_file": str(pack_path), "namespace": "test"}]

    record = compile_case(cfg).emission_kernel_inventory["records"][0]

    assert record["id"] == "test:kernel"
    assert record["upper_state"] == "test:upper"
    assert record["process_ids"] == ["test:process"]
    assert record["transition_ids"] == ["test:transition"]
    assert record["evidence"]["process_artifacts"][0]["process_id"] == "test:process"
