#!/usr/bin/env python
"""Compatibility wrapper for ``oescr run``."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from oescr.cli import main as cli_main


def main() -> None:
    status = cli_main(["run", *sys.argv[1:]])
    if status:
        raise SystemExit(status)


if __name__ == "__main__":
    main()
