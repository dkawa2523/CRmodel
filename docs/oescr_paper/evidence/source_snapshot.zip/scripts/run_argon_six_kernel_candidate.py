#!/usr/bin/env python
"""Run the focused six-upper-state Maxwellian Ar benchmark.

The benchmark is deliberately small: one plasma condition, two broad spectral
channels, three deterministic repeats per channel, and one fitted parameter
(the Maxwellian effective electron temperature).  It exercises the real
forward/inverse path while keeping the scientific claim separate from the
software recovery result.
"""

from __future__ import annotations

import argparse
import csv
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.package_model_ready_oes import package_model_ready_observations

from oescr.analysis.recovery_bundle import (
    TemperatureRecoveryFigureSpec,
    write_single_temperature_recovery_bundle,
)
from oescr.data.provenance import file_sha256
from oescr.forward.model import OESCRModel
from oescr.inverse.optimize import InverseSolver
from oescr.inverse.reporting import write_fit_result
from oescr.io.yaml_loader import load_yaml, save_yaml

ROOT = Path(__file__).resolve().parents[1]
BENCHMARK_DIR = ROOT / "examples" / "benchmarks" / "ar_six_kernel_candidate"
TRUTH_TE_EV = 4.0
INITIAL_TE_EV = 2.5
REPEAT_COUNT = 3


def _deterministic_repeat(
    wavelength_nm: np.ndarray,
    intensity: np.ndarray,
    repeat_index: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Return a reproducible measurement-like repeat without a random seed."""

    peak = max(float(np.max(np.abs(intensity))), 1.0e-30)
    sigma = 0.007 * np.maximum(np.abs(intensity), 0.015 * peak)
    sample = np.arange(len(wavelength_nm), dtype=float)
    standardized_perturbation = 0.55 * np.sin(2.0 * np.pi * (sample + 7.0 * repeat_index) / 37.0) + 0.30 * np.cos(
        2.0 * np.pi * (sample + 11.0 * repeat_index) / 83.0
    )
    return intensity + sigma * standardized_perturbation, sigma


def _write_calibrated_source_fixture(
    path: Path,
    wavelength_nm: np.ndarray,
    intensity: np.ndarray,
    sigma: np.ndarray,
) -> None:
    """Write the external-CSV side of the adapter contract fixture."""

    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["Wavelength (nm)", "Relative signal", "Standard uncertainty", "Quality flag"])
        writer.writerows(
            zip(
                wavelength_nm,
                intensity,
                sigma,
                np.full(len(wavelength_nm), "GOOD", dtype=object),
                strict=True,
            )
        )


def _write_package_manifest(
    package_dir: Path,
    *,
    source_path: Path,
    calibration_path: Path,
    instrument_id: str,
    repeat_index: int,
) -> Path:
    measurement_id = f"{instrument_id}_rep_{repeat_index}"
    manifest = {
        "format": "oescr_model_ready_package/v1",
        "source": {
            "file": source_path.name,
            "sha256": file_sha256(source_path),
            "stage": "calibrated",
        },
        "calibration_artifact": {
            "id": "ar-six-kernel-response-v1",
            "file": str(calibration_path.resolve()),
            "sha256": file_sha256(calibration_path),
        },
        "spectral_axis": {
            "unit": "nm",
            "wavelength_medium": "air",
            "sampling": "bin_average",
        },
        "observation": {
            "instrument_id": instrument_id,
            "id": measurement_id,
            "prediction_key": "chord_0",
            "condition_id": "ar_candidate_condition_001",
            "state_group_id": "ar_candidate_shared_state_001",
            "view_id": "view_0",
            "replicate_id": f"rep_{repeat_index}",
            "output_basis": "relative_instrument_signal",
            "output_unit": "arb",
            "calibration_reference": "Generated Ar six-kernel response fixture v1",
            "calibration_group_id": f"{instrument_id}_synthetic_response",
        },
        "columns": {
            "wavelength_nm": "Wavelength (nm)",
            "intensity": "Relative signal",
            "sigma": "Standard uncertainty",
            "pixel_status": "Quality flag",
        },
        "status_map": {"GOOD": "valid"},
        "outputs": {
            "spectrum_file": "generated/spectrum.csv",
            "measurement_file": "generated/measurement.yaml",
            "provenance_file": "generated/provenance.yaml",
        },
    }
    manifest_path = package_dir / "package_manifest.yaml"
    save_yaml(manifest, manifest_path)
    return manifest_path


def _package_measurements(output_dir: Path, truth_result: Any) -> dict[str, Any]:
    calibration_path = BENCHMARK_DIR / "synthetic_response_artifact.yaml"
    package_root = output_dir / "observation_packages"
    manifests: list[Path] = []

    for instrument_id, chord_map in truth_result.spectra.items():
        truth_spectrum = chord_map["chord_0"]
        wavelength_nm = np.asarray(truth_spectrum["wavelength_nm"], dtype=float)
        truth_intensity = np.asarray(truth_spectrum["intensity"], dtype=float)
        for repeat_index in range(REPEAT_COUNT):
            measurement_id = f"{instrument_id}_rep_{repeat_index}"
            measured, sigma = _deterministic_repeat(
                wavelength_nm,
                truth_intensity,
                repeat_index,
            )
            package_dir = package_root / measurement_id
            source_path = package_dir / "calibrated_source.csv"
            _write_calibrated_source_fixture(
                source_path,
                wavelength_nm,
                measured,
                sigma,
            )
            manifests.append(
                _write_package_manifest(
                    package_dir,
                    source_path=source_path,
                    calibration_path=calibration_path,
                    instrument_id=instrument_id,
                    repeat_index=repeat_index,
                )
            )
    return package_model_ready_observations(
        manifests,
        output_dir / "measurement_set.yaml",
    )


def _inverse_config(output_dir: Path, measurements: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "__base_dir__": str(output_dir.resolve()),
        "inference_mode": "relative_shape",
        "window_selection": {
            "mode": "window_union",
            "registry": str((BENCHMARK_DIR / "windows.yaml").resolve()),
        },
        "measurements": measurements,
        "fit": {
            "objective": {
                "spectrum_weight": 1.0,
                "window_fit_weight": 0.0,
                "area_weight": 0.0,
                "peak_weight": 0.0,
                "auto_gain_fit": True,
                "auto_offset_fit": False,
                "auto_gain_tilt_fit": False,
                "auto_gain_scope": "instrument",
                "window_ratio_weight": 0.0,
            },
            "global": {"enabled": False},
            "local": {"enabled": True, "max_nfev": 100},
            "uncertainty": {"laplace": True},
            "identifiability": {"enabled": True, "rank_rtol": 1.0e-8},
            "profile": {
                "enabled": True,
                "max_nfev": 60,
                "parameters": [
                    {
                        "name": "electron_temperature_eV",
                        "range": [1.5, 7.0],
                        "points": 13,
                    }
                ],
            },
        },
        "parameters": [
            {
                "name": "electron_temperature_eV",
                "path": "plasma_state.te_shells_eV[0]",
                "scale": "linear",
                "role": "target",
                "bounds": [1.5, 7.0],
            }
        ],
    }


def _excitation_rate_map(result: Any) -> dict[str, float]:
    return {
        str(process["id"]): float(process["coefficient_value"])
        for process in result.zone_diagnostics[0].processes
        if str(process.get("kind", "")) == "electron_excitation"
    }


def _kernel_sensitivity_report(
    model: OESCRModel,
    truth_result: Any,
    inventory: dict[str, Any],
) -> dict[str, Any]:
    log_step = 0.02
    perturbed_rates: dict[int, dict[str, float]] = {}
    for direction in (-1, 1):
        case = deepcopy(model.cfg)
        case["plasma_state"]["te_shells_eV"][0] = TRUTH_TE_EV * np.exp(direction * log_step)
        perturbed_rates[direction] = _excitation_rate_map(model.predict(case))

    truth_rates = _excitation_rate_map(truth_result)
    records: list[dict[str, Any]] = []
    for kernel in inventory["records"]:
        process_id = str(kernel["process_ids"][0])
        sensitivity = (np.log(perturbed_rates[1][process_id]) - np.log(perturbed_rates[-1][process_id])) / (
            2.0 * log_step
        )
        records.append(
            {
                "kernel_id": str(kernel["id"]),
                "upper_state": str(kernel["upper_state"]),
                "process_id": process_id,
                "rate_coefficient_m3_s_at_truth": truth_rates[process_id],
                "d_log_rate_d_log_te": float(sensitivity),
            }
        )
    sensitivities = [float(record["d_log_rate_d_log_te"]) for record in records]
    return {
        "definition": "central finite difference of log(rate coefficient) with respect to log(Te)",
        "truth_te_eV": TRUTH_TE_EV,
        "log_te_step": log_step,
        "sensitivity_min": min(sensitivities),
        "sensitivity_max": max(sensitivities),
        "sensitivity_span": max(sensitivities) - min(sensitivities),
        "interpretation": (
            "Distinct upper-state identities do not by themselves prove independent information; "
            "the fitted and held-out spectrum plus the measurement Jacobian remain decisive."
        ),
        "records": records,
    }


def run_benchmark(output_dir: Path) -> dict[str, Any]:
    output_dir = output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    truth_model = OESCRModel.from_yaml(BENCHMARK_DIR / "case_truth.yaml")
    truth_result = truth_model.predict()
    packaged = _package_measurements(output_dir, truth_result)
    measurement_set = load_yaml(packaged["measurement_file"])
    measurements = measurement_set["measurements"]
    inverse_config = _inverse_config(output_dir, measurements)
    case_initial = load_yaml(BENCHMARK_DIR / "case_initial.yaml")
    solver = InverseSolver(case_initial, inverse_config)
    fit = solver.fit(record_trace=True, audit=True)

    estimate_te_eV = float(fit.x_opt[0])
    relative_error = abs(estimate_te_eV - TRUTH_TE_EV) / TRUTH_TE_EV
    bundle = write_single_temperature_recovery_bundle(
        output_dir,
        solver,
        fit,
        TemperatureRecoveryFigureSpec(
            truth_te_eV=TRUTH_TE_EV,
            initial_te_eV=INITIAL_TE_EV,
            channel_order=("vis_650_850", "nir_840_1050"),
            channel_titles=("(a) VIS channel", "(b) NIR channel"),
            title=("Six-upper-state Ar candidate benchmark: shared Maxwellian effective temperature"),
        ),
        spectrum_directory="audit_spectra",
    )
    score_metrics = bundle.score_metrics
    score_standardized_rmse = float(score_metrics["all"]["standardized_rmse"])
    distinct_holdout_rmse = float(score_metrics["distinct_kernel_holdout"]["standardized_rmse"])
    inventory = truth_result.provenance["emission_kernels"]
    kernel_sensitivity = _kernel_sensitivity_report(
        truth_model,
        truth_result,
        inventory,
    )
    fit_kernel_ids = {
        str(window["kernel_id"]) for window in solver.windows if str(window.get("analysis_role", "fit")) == "fit"
    }
    heldout_kernel_ids = {
        str(window["kernel_id"])
        for window in solver.windows
        if str(window.get("analysis_role", "fit")) == "score" and str(window["kernel_id"]) not in fit_kernel_ids
    }
    software_recovery_pass = bool(
        fit.success and relative_error <= 0.03 and score_standardized_rmse <= 2.0 and distinct_holdout_rmse <= 2.0
    )
    summary = {
        "benchmark": "ar_six_kernel_candidate",
        "truth_te_eV": TRUTH_TE_EV,
        "initial_te_eV": INITIAL_TE_EV,
        "estimated_te_eV": estimate_te_eV,
        "relative_te_error": relative_error,
        "score_standardized_rmse": score_standardized_rmse,
        "score_metrics": score_metrics,
        "measurement_count": len(measurements),
        "model_ready_package_count": packaged["measurement_count"],
        "spectral_channel_count": len(truth_result.spectra),
        "fit_distinct_kernel_count": len(fit_kernel_ids),
        "heldout_distinct_kernel_count": len(heldout_kernel_ids),
        "fit_kernel_ids": sorted(fit_kernel_ids),
        "heldout_distinct_kernel_ids": sorted(heldout_kernel_ids),
        "kernel_log_sensitivity_span_at_truth": kernel_sensitivity["sensitivity_span"],
        "software_recovery_pass": software_recovery_pass,
        "optimizer_success": bool(fit.success),
        "cost": float(fit.cost),
        "identifiability": fit.identifiability,
        "parameter_profiles": fit.parameter_profiles,
    }
    claim = {
        "scientific_status": "abstain_external_validation",
        "software_status": "pass" if software_recovery_pass else "fail",
        "permitted_estimand": "Maxwellian effective electron temperature",
        "electron_density": "fixed_input_not_estimated",
        "eedf": "derived_from_fitted_te_not_independently_reconstructed",
        "kernel_evidence": inventory["evidence_counts"],
        "blockers": [
            "all six kernels are validation_candidate rather than qualified",
            "the spectra are deterministic same-model fixtures rather than experimental OES",
            "metastable stepwise excitation, cascade, quenching, and trapping are not closed",
            "no independent, colocated electron-temperature reference is attached",
        ],
    }

    save_yaml(inverse_config, output_dir / "inverse_config.yaml")
    save_yaml(summary, output_dir / "fit_summary.yaml")
    save_yaml(claim, output_dir / "claim.yaml")
    save_yaml(inventory, output_dir / "kernel_inventory.yaml")
    save_yaml(kernel_sensitivity, output_dir / "kernel_sensitivity.yaml")
    write_fit_result(fit, output_dir)
    return {"summary": summary, "claim": claim, "output_dir": str(output_dir)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--out",
        type=Path,
        default=ROOT / ".local_outputs" / "ar_six_kernel_candidate",
    )
    args = parser.parse_args()
    result = run_benchmark(args.out)
    summary = result["summary"]
    print(f"output: {result['output_dir']}")
    print(
        "Te: "
        f"initial={summary['initial_te_eV']:.3f} eV, "
        f"truth={summary['truth_te_eV']:.3f} eV, "
        f"estimated={summary['estimated_te_eV']:.6f} eV"
    )
    print(f"software recovery: {summary['software_recovery_pass']}")
    print("scientific status: abstain_external_validation")
    raise SystemExit(0 if summary["software_recovery_pass"] else 1)


if __name__ == "__main__":
    main()
