#!/usr/bin/env python
"""Package one calibrated external CSV as an OESCR model-ready observation.

The adapter is deliberately narrow.  It verifies the source and calibration
artifacts, renames columns, maps externally defined quality flags, and writes
the existing canonical CSV/YAML boundary.  It never calibrates raw counts or
changes numerical samples.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import os
import sys
import tempfile
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from oescr.data.provenance import file_sha256
from oescr.inverse.measurements import PIXEL_STATUSES, load_measurement_csv
from oescr.io.yaml_loader import rebase_config_paths, save_yaml

PACKAGE_FORMAT = "oescr_model_ready_package/v1"
SPECTRUM_FORMAT = "oescr_model_ready_spectrum/v1"
PROVENANCE_FORMAT = "oescr_model_ready_provenance/v1"

_CANONICAL_NUMERIC_COLUMNS = (
    "wavelength_nm",
    "intensity",
    "sigma",
    "lower_bound",
    "upper_bound",
)
_COLUMN_KEYS = frozenset((*_CANONICAL_NUMERIC_COLUMNS, "pixel_status"))
_REQUIRED_OBSERVATION_FIELDS = (
    "instrument_id",
    "id",
    "prediction_key",
    "condition_id",
    "state_group_id",
    "view_id",
    "replicate_id",
    "output_basis",
    "output_unit",
    "calibration_reference",
)


@dataclass(frozen=True)
class PackageContract:
    manifest_path: Path
    base_dir: Path
    source_path: Path
    source_sha256: str
    source_stage: str
    delimiter: str
    calibration_id: str
    calibration_path: Path
    calibration_sha256: str
    spectral_axis: dict[str, str]
    observation: dict[str, str]
    columns: dict[str, str]
    status_map: dict[str, str]
    spectrum_path: Path
    measurement_path: Path
    provenance_path: Path


def _mapping(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{label} must be a mapping.")
    return {str(key): item for key, item in value.items()}


def _check_keys(
    value: Mapping[str, Any],
    *,
    label: str,
    required: set[str],
    allowed: set[str],
) -> None:
    missing = required.difference(value)
    if missing:
        raise ValueError(f"{label} is missing: {', '.join(sorted(missing))}.")
    unknown = set(value).difference(allowed)
    if unknown:
        raise ValueError(f"{label} has unsupported fields: {', '.join(sorted(unknown))}.")


def _required_text(value: Any, label: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{label} must be a non-empty string.")
    text = value.strip()
    if not text:
        raise ValueError(f"{label} must be a non-empty string.")
    if "\n" in text or "\r" in text:
        raise ValueError(f"{label} must not contain a line break.")
    return text


def _expected_sha256(value: Any, label: str) -> str:
    digest = _required_text(value, label).lower()
    try:
        valid = len(digest) == 64 and int(digest, 16) >= 0
    except ValueError:
        valid = False
    if not valid:
        raise ValueError(f"{label} must be a 64-digit hexadecimal SHA-256.")
    return digest


def _resolve_file(base_dir: Path, value: Any, label: str) -> Path:
    declared = Path(_required_text(value, label))
    path = declared if declared.is_absolute() else base_dir / declared
    resolved = path.resolve()
    if not resolved.is_file():
        raise FileNotFoundError(f"{label} does not exist or is not a file: {resolved}")
    return resolved


def _resolve_output(base_dir: Path, value: Any, label: str) -> Path:
    declared = Path(_required_text(value, label))
    return (declared if declared.is_absolute() else base_dir / declared).resolve()


def _verify_artifact(path: Path, expected: str, label: str) -> str:
    actual = file_sha256(path)
    if actual != expected:
        raise ValueError(
            f"{label} SHA-256 mismatch for '{path}': expected {expected}, got {actual}."
        )
    return actual


def _portable_path(path: Path, base_dir: Path) -> str:
    try:
        return Path(os.path.relpath(path, start=base_dir)).as_posix()
    except ValueError:
        return path.as_posix()


def _read_source_rows(
    source_path: Path,
    *,
    delimiter: str,
    columns: Mapping[str, str],
    status_map: Mapping[str, str],
) -> list[dict[str, str]]:
    with source_path.open("r", encoding="utf-8-sig", newline="") as stream:
        source_lines = (
            line for line in stream if line.strip() and not line.lstrip().startswith("#")
        )
        reader = csv.DictReader(source_lines, delimiter=delimiter)
        if reader.fieldnames is None:
            raise ValueError(f"Source CSV '{source_path}' has no header.")
        if len(set(reader.fieldnames)) != len(reader.fieldnames):
            raise ValueError(f"Source CSV '{source_path}' has duplicate column names.")
        missing = set(columns.values()).difference(reader.fieldnames)
        if missing:
            raise ValueError(
                f"Source CSV '{source_path}' is missing mapped columns: "
                f"{', '.join(sorted(missing))}."
            )

        output_rows: list[dict[str, str]] = []
        for row_number, row in enumerate(reader, start=2):
            if None in row:
                raise ValueError(
                    f"Source CSV '{source_path}' row {row_number} has more cells than its header."
                )
            output: dict[str, str] = {}
            for canonical in _CANONICAL_NUMERIC_COLUMNS:
                source_column = columns.get(canonical)
                if source_column is not None:
                    cell = row.get(source_column)
                    if cell is None:
                        raise ValueError(
                            f"Source CSV '{source_path}' row {row_number} has no value for "
                            f"mapped column '{source_column}'."
                        )
                    # Preserve the numeric token exactly.  csv.writer may quote it,
                    # but no float conversion or formatting is performed here.
                    output[canonical] = cell

            status_column = columns.get("pixel_status")
            if status_column is None:
                output["pixel_status"] = "valid"
            else:
                source_status = str(row.get(status_column) or "").strip()
                if source_status not in status_map:
                    raise ValueError(
                        f"Source CSV '{source_path}' row {row_number} has unmapped "
                        f"pixel status {source_status!r}."
                    )
                output["pixel_status"] = status_map[source_status]
            output_rows.append(output)

    if not output_rows:
        raise ValueError(f"Source CSV '{source_path}' contains no data rows.")
    return output_rows


def _canonical_csv_text(
    rows: list[dict[str, str]],
    *,
    source_sha256: str,
    calibration_id: str,
    calibration_sha256: str,
    observation: Mapping[str, str],
    spectral_axis: Mapping[str, str],
    columns: Mapping[str, str],
) -> str:
    output_columns = ["wavelength_nm", "intensity"]
    if "sigma" in columns:
        output_columns.append("sigma")
    output_columns.append("pixel_status")
    for optional in ("lower_bound", "upper_bound"):
        if optional in columns:
            output_columns.append(optional)

    stream = io.StringIO(newline="")
    metadata = (
        ("package_format", SPECTRUM_FORMAT),
        ("source_file_sha256", source_sha256),
        ("calibration_artifact_id", calibration_id),
        ("calibration_artifact_sha256", calibration_sha256),
        ("calibration_reference", observation["calibration_reference"]),
        ("spectral_axis_unit", spectral_axis["unit"]),
        ("wavelength_medium", spectral_axis["wavelength_medium"]),
        ("spectral_sampling", spectral_axis["sampling"]),
        ("output_basis", observation["output_basis"]),
        ("output_unit", observation["output_unit"]),
    )
    for key, value in metadata:
        stream.write(f"# {key}: {value}\n")
    writer = csv.DictWriter(stream, fieldnames=output_columns, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return stream.getvalue()


def _yaml_text(value: Mapping[str, Any]) -> str:
    return yaml.safe_dump(
        dict(value),
        sort_keys=False,
        allow_unicode=True,
        default_flow_style=False,
    )


def _validate_generated_spectrum(text: str) -> None:
    with tempfile.TemporaryDirectory(prefix="oescr-model-ready-") as directory:
        path = Path(directory) / "spectrum.csv"
        path.write_text(text, encoding="utf-8", newline="\n")
        load_measurement_csv(path)


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")


def _load_manifest_document(manifest_path: Path) -> dict[str, Any]:
    with manifest_path.open("r", encoding="utf-8") as stream:
        loaded = yaml.safe_load(stream) or {}
    manifest = _mapping(loaded, "Manifest")
    _check_keys(
        manifest,
        label="Manifest",
        required={
            "format",
            "source",
            "calibration_artifact",
            "spectral_axis",
            "observation",
            "columns",
            "outputs",
        },
        allowed={
            "format",
            "source",
            "calibration_artifact",
            "spectral_axis",
            "observation",
            "columns",
            "status_map",
            "outputs",
        },
    )
    if manifest["format"] != PACKAGE_FORMAT:
        raise ValueError(f"Manifest format must be '{PACKAGE_FORMAT}'.")
    return manifest


def _source_contract(
    manifest: Mapping[str, Any], base_dir: Path
) -> tuple[Path, str, str, str]:
    source = _mapping(manifest["source"], "source")
    _check_keys(
        source,
        label="source",
        required={"file", "sha256", "stage"},
        allowed={"file", "sha256", "stage", "delimiter"},
    )
    stage = _required_text(source["stage"], "source.stage")
    if stage != "calibrated":
        raise ValueError("source.stage must be 'calibrated'; raw-count calibration is out of scope.")
    delimiter = _required_text(source.get("delimiter", ","), "source.delimiter")
    if len(delimiter) != 1:
        raise ValueError("source.delimiter must be exactly one character.")
    path = _resolve_file(base_dir, source["file"], "source.file")
    expected_hash = _expected_sha256(source["sha256"], "source.sha256")
    return path, _verify_artifact(path, expected_hash, "Source artifact"), stage, delimiter


def _calibration_contract(
    manifest: Mapping[str, Any], base_dir: Path
) -> tuple[str, Path, str]:
    calibration = _mapping(manifest["calibration_artifact"], "calibration_artifact")
    _check_keys(
        calibration,
        label="calibration_artifact",
        required={"id", "file", "sha256"},
        allowed={"id", "file", "sha256"},
    )
    artifact_id = _required_text(calibration["id"], "calibration_artifact.id")
    path = _resolve_file(base_dir, calibration["file"], "calibration_artifact.file")
    expected_hash = _expected_sha256(
        calibration["sha256"], "calibration_artifact.sha256"
    )
    return artifact_id, path, _verify_artifact(path, expected_hash, "Calibration artifact")


def _spectral_axis_contract(manifest: Mapping[str, Any]) -> dict[str, str]:
    raw = _mapping(manifest["spectral_axis"], "spectral_axis")
    _check_keys(
        raw,
        label="spectral_axis",
        required={"unit", "wavelength_medium", "sampling"},
        allowed={"unit", "wavelength_medium", "sampling"},
    )
    spectral_axis = {
        field: _required_text(raw[field], f"spectral_axis.{field}")
        for field in ("unit", "wavelength_medium", "sampling")
    }
    expected = {"unit": "nm", "wavelength_medium": "air", "sampling": "bin_average"}
    if spectral_axis != expected:
        raise ValueError(
            "spectral_axis v1 requires unit='nm', wavelength_medium='air', "
            "and sampling='bin_average'."
        )
    return spectral_axis


def _observation_contract(manifest: Mapping[str, Any]) -> dict[str, str]:
    raw = _mapping(manifest["observation"], "observation")
    _check_keys(
        raw,
        label="observation",
        required=set(_REQUIRED_OBSERVATION_FIELDS),
        allowed={*_REQUIRED_OBSERVATION_FIELDS, "calibration_group_id"},
    )
    observation = {
        field: _required_text(raw[field], f"observation.{field}")
        for field in _REQUIRED_OBSERVATION_FIELDS
    }
    if "calibration_group_id" in raw:
        observation["calibration_group_id"] = _required_text(
            raw["calibration_group_id"], "observation.calibration_group_id"
        )
    return observation


def _column_contract(manifest: Mapping[str, Any]) -> tuple[dict[str, str], dict[str, str]]:
    raw = _mapping(manifest["columns"], "columns")
    unknown = set(raw).difference(_COLUMN_KEYS)
    if unknown:
        raise ValueError(f"columns has unsupported targets: {', '.join(sorted(unknown))}.")
    missing = {"wavelength_nm", "intensity", "sigma"}.difference(raw)
    if missing:
        raise ValueError(
            f"columns is missing canonical targets: {', '.join(sorted(missing))}."
        )
    columns = {
        canonical: _required_text(source_name, f"columns.{canonical}")
        for canonical, source_name in raw.items()
    }
    if len(set(columns.values())) != len(columns):
        raise ValueError("Each source column may map to only one canonical column.")

    status_raw = _mapping(manifest.get("status_map", {}), "status_map")
    status_map = {
        str(source_status): _required_text(target, f"status_map.{source_status}").lower()
        for source_status, target in status_raw.items()
    }
    invalid = sorted(set(status_map.values()).difference(PIXEL_STATUSES))
    if invalid:
        raise ValueError(
            f"status_map targets unsupported canonical statuses: {', '.join(invalid)}."
        )
    if "pixel_status" in columns and not status_map:
        raise ValueError("status_map is required when columns.pixel_status is mapped.")
    if "pixel_status" not in columns and status_map:
        raise ValueError("status_map requires columns.pixel_status.")
    return columns, status_map


def _output_contract(
    manifest: Mapping[str, Any],
    base_dir: Path,
    protected: set[Path],
) -> tuple[Path, Path, Path]:
    outputs = _mapping(manifest["outputs"], "outputs")
    fields = {"spectrum_file", "measurement_file", "provenance_file"}
    _check_keys(outputs, label="outputs", required=fields, allowed=fields)
    generated = (
        _resolve_output(base_dir, outputs["spectrum_file"], "outputs.spectrum_file"),
        _resolve_output(base_dir, outputs["measurement_file"], "outputs.measurement_file"),
        _resolve_output(base_dir, outputs["provenance_file"], "outputs.provenance_file"),
    )
    if len(set(generated)) != len(generated):
        raise ValueError("Output files must be three distinct paths.")
    overlap = protected.intersection(generated)
    if overlap:
        raise ValueError(f"Output paths must not overwrite inputs: {sorted(str(p) for p in overlap)}")
    return generated


def _load_package_contract(manifest_path: str | Path) -> PackageContract:
    path = Path(manifest_path).resolve()
    manifest = _load_manifest_document(path)
    base_dir = path.parent
    source_path, source_hash, source_stage, delimiter = _source_contract(manifest, base_dir)
    calibration_id, calibration_path, calibration_hash = _calibration_contract(
        manifest, base_dir
    )
    spectral_axis = _spectral_axis_contract(manifest)
    observation = _observation_contract(manifest)
    columns, status_map = _column_contract(manifest)
    spectrum_path, measurement_path, provenance_path = _output_contract(
        manifest,
        base_dir,
        {path, source_path, calibration_path},
    )
    return PackageContract(
        manifest_path=path,
        base_dir=base_dir,
        source_path=source_path,
        source_sha256=source_hash,
        source_stage=source_stage,
        delimiter=delimiter,
        calibration_id=calibration_id,
        calibration_path=calibration_path,
        calibration_sha256=calibration_hash,
        spectral_axis=spectral_axis,
        observation=observation,
        columns=columns,
        status_map=status_map,
        spectrum_path=spectrum_path,
        measurement_path=measurement_path,
        provenance_path=provenance_path,
    )


def _measurement_document(contract: PackageContract) -> dict[str, Any]:
    observation = contract.observation
    entry: dict[str, Any] = {
        "instrument_id": observation["instrument_id"],
        "id": observation["id"],
        "prediction_key": observation["prediction_key"],
        "condition_id": observation["condition_id"],
        "state_group_id": observation["state_group_id"],
        "view_id": observation["view_id"],
        "replicate_id": observation["replicate_id"],
        "stage": "model_ready",
        "file": _portable_path(contract.spectrum_path, contract.measurement_path.parent),
        "output_basis": observation["output_basis"],
        "output_unit": observation["output_unit"],
        "calibration_artifact": {
            "id": contract.calibration_id,
            "sha256": contract.calibration_sha256,
        },
    }
    if "calibration_group_id" in observation:
        entry["calibration_group_id"] = observation["calibration_group_id"]
    return {"measurements": [entry]}


def _provenance_yaml(
    contract: PackageContract,
    *,
    row_count: int,
    spectrum_sha256: str,
    measurement_sha256: str,
) -> str:
    provenance: dict[str, Any] = {
        "format": PROVENANCE_FORMAT,
        "manifest": {
            "file": _portable_path(contract.manifest_path, contract.base_dir),
            "sha256": file_sha256(contract.manifest_path),
        },
        "source": {
            "file": _portable_path(contract.source_path, contract.base_dir),
            "sha256": contract.source_sha256,
            "stage": contract.source_stage,
            "row_count": row_count,
        },
        "calibration_artifact": {
            "id": contract.calibration_id,
            "file": _portable_path(contract.calibration_path, contract.base_dir),
            "sha256": contract.calibration_sha256,
        },
        "spectral_axis": dict(contract.spectral_axis),
        "observation_id": contract.observation["id"],
        "transform": {
            "kind": "column_rename_and_status_map_only",
            "columns": dict(contract.columns),
            "status_map": dict(contract.status_map),
            "numeric_tokens_copied_verbatim": True,
            "resampling": False,
            "interpolation": False,
            "smoothing": False,
            "normalization": False,
            "raw_count_calibration": False,
        },
        "outputs": {
            "spectrum_file": _portable_path(contract.spectrum_path, contract.base_dir),
            "spectrum_sha256": spectrum_sha256,
            "measurement_file": _portable_path(contract.measurement_path, contract.base_dir),
            "measurement_sha256": measurement_sha256,
        },
    }
    return _yaml_text(provenance)


def package_model_ready_observation(manifest_path: str | Path) -> dict[str, Any]:
    """Build one deterministic model-ready package from ``manifest_path``."""

    return _package_observation(_load_package_contract(manifest_path))


def _package_observation(contract: PackageContract) -> dict[str, Any]:
    rows = _read_source_rows(
        contract.source_path,
        delimiter=contract.delimiter,
        columns=contract.columns,
        status_map=contract.status_map,
    )
    spectrum_text = _canonical_csv_text(
        rows,
        source_sha256=contract.source_sha256,
        calibration_id=contract.calibration_id,
        calibration_sha256=contract.calibration_sha256,
        observation=contract.observation,
        spectral_axis=contract.spectral_axis,
        columns=contract.columns,
    )
    # Reuse the canonical reader as the single owner of sample-grid, QC,
    # uncertainty, and saturation-bound validation before committing outputs.
    _validate_generated_spectrum(spectrum_text)
    measurement_text = _yaml_text(_measurement_document(contract))
    spectrum_output_hash = hashlib.sha256(spectrum_text.encode("utf-8")).hexdigest()
    measurement_output_hash = hashlib.sha256(measurement_text.encode("utf-8")).hexdigest()
    provenance_text = _provenance_yaml(
        contract,
        row_count=len(rows),
        spectrum_sha256=spectrum_output_hash,
        measurement_sha256=measurement_output_hash,
    )

    _write_text(contract.spectrum_path, spectrum_text)
    _write_text(contract.measurement_path, measurement_text)
    _write_text(contract.provenance_path, provenance_text)

    return {
        "spectrum_file": contract.spectrum_path,
        "measurement_file": contract.measurement_path,
        "provenance_file": contract.provenance_path,
        "spectrum_sha256": spectrum_output_hash,
        "measurement_sha256": measurement_output_hash,
        "source_sha256": contract.source_sha256,
        "calibration_artifact_sha256": contract.calibration_sha256,
    }


def package_model_ready_observations(
    manifest_paths: Sequence[str | Path],
    measurement_set_path: str | Path,
) -> dict[str, Any]:
    """Package observations and compose their canonical measurement entries.

    A package manifest intentionally describes one observation.  This helper
    keeps that small adapter contract while providing the missing boundary for
    a shared-state inverse fit: it rebases and concatenates the generated
    one-entry fragments into one ordinary ``measurements`` document.
    """

    contracts = [_load_package_contract(path) for path in manifest_paths]
    if not contracts:
        raise ValueError("At least one package manifest is required.")

    destination = Path(measurement_set_path).resolve()
    protected = {
        path
        for contract in contracts
        for path in (contract.manifest_path, contract.source_path, contract.calibration_path)
    }
    generated = {destination}
    observation_ids: set[str] = set()
    for contract in contracts:
        observation_id = contract.observation["id"]
        if observation_id in observation_ids:
            raise ValueError(f"Duplicate observation id '{observation_id}' across package manifests.")
        observation_ids.add(observation_id)
        for path in (contract.spectrum_path, contract.measurement_path, contract.provenance_path):
            if path in generated:
                raise ValueError(f"Output path is reused across packages or the measurement set: {path}")
            generated.add(path)
    overlap = protected.intersection(generated)
    if overlap:
        raise ValueError(f"Output paths must not overwrite inputs: {sorted(str(path) for path in overlap)}")

    measurements: list[dict[str, Any]] = []
    packages: list[dict[str, Any]] = []
    for contract in contracts:
        package = _package_observation(contract)
        fragment = rebase_config_paths(
            {"__base_dir__": str(contract.measurement_path.parent), **_measurement_document(contract)},
            destination.parent,
        )
        measurements.extend(fragment["measurements"])
        packages.append(
            {
                "manifest_file": contract.manifest_path,
                "observation_id": contract.observation["id"],
                **package,
            }
        )

    save_yaml({"measurements": measurements}, destination)
    return {
        "measurement_file": destination,
        "measurement_count": len(measurements),
        "packages": packages,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "manifest",
        type=Path,
        nargs="+",
        help="One or more model-ready package manifest YAML files.",
    )
    parser.add_argument(
        "--measurement-set",
        type=Path,
        help="Compose all packaged observations into this measurement YAML.",
    )
    args = parser.parse_args()
    if args.measurement_set is not None:
        result = package_model_ready_observations(args.manifest, args.measurement_set)
        print(f"measurements: {result['measurement_file']} ({result['measurement_count']} observations)")
        return
    if len(args.manifest) != 1:
        parser.error("multiple manifests require --measurement-set")
    result = package_model_ready_observation(args.manifest[0])
    print(f"spectrum: {result['spectrum_file']} ({result['spectrum_sha256']})")
    print(f"measurement: {result['measurement_file']} ({result['measurement_sha256']})")
    print(f"provenance: {result['provenance_file']}")


if __name__ == "__main__":
    main()
