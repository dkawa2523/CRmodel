#!/usr/bin/env python
"""Check shared Maxwellian-state recovery on committed synthetic narrow spectra.

This checks numerical recovery, held-out channels and grid refinement. It does
not validate experimental Te/ne or independently reconstruct an EEDF. All run
artifacts use the ordinary fit-result format and stay under --out.
"""
from __future__ import annotations

import argparse
import csv
import sys
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from oescr.analysis.benchmark_metrics import aggregate_spectral_relative_l2, spectral_relative_l2
from oescr.forward.model import OESCRModel
from oescr.inverse.objectives import residual_vector
from oescr.inverse.optimize import FitResult, InverseSolver
from oescr.inverse.reporting import write_fit_result
from oescr.io.pathmap import get_path
from oescr.io.yaml_loader import rebase_config_paths, save_yaml

REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = REPO_ROOT / ".local_outputs" / "common_state_benchmarks"
CMA_SEED = 20261002
MEASUREMENT_SEED = 20261002


@dataclass(frozen=True)
class BenchmarkCase:
    key: str
    title: str
    directory: Path
    feature_labels: dict[str, str]
    fit_excitation_kernel_ids: tuple[str, ...]
    modeled_pathway_ids: tuple[str, ...]
    held_out_spectra: tuple[str, ...]
    limitation: str

    @property
    def truth_path(self) -> Path:
        return self.directory / "case_truth.yaml"

    @property
    def init_path(self) -> Path:
        return self.directory / "case_init.yaml"

    @property
    def inverse_path(self) -> Path:
        return self.directory / "inverse.yaml"


CASES = (
    BenchmarkCase(
        key="ar_o2",
        title="Ar/O$_2$ common-state recovery",
        directory=REPO_ROOT / "examples" / "benchmarks" / "common_state_ar_o2",
        feature_labels={
            "ar750": "Ar I 750.4 nm",
            "ar763": "Ar I 763.5 nm",
            "o777": "O I 777.4 nm",
            "ar800": "Ar I 800.6 nm",
            "ar922": "Ar I 922.4 nm",
        },
        fit_excitation_kernel_ids=(
            "ArI_750.4_direct",
            "ArI_763.5_direct",
            "OI_777.4_multiplet",
        ),
        modeled_pathway_ids=(
            "ArI_750.4_direct",
            "ArI_763.5_800.6_922.4_shared_upper",
            "OI_777.4_multiplet",
        ),
        held_out_spectra=("ar800", "ar922"),
        limitation="Ar branches share two upper states; O I 844.6 nm is not yet covered.",
    ),
    BenchmarkCase(
        key="ar_cl2",
        title="Ar/Cl$_2$ common-state recovery",
        directory=REPO_ROOT / "examples" / "benchmarks" / "common_state_ar_cl2",
        feature_labels={
            "cl725": "Cl I 725.7 nm",
            "ar750": "Ar I 750.4 nm",
            "cl755": "Cl I 754.7 nm",
            "ar763": "Ar I 763.5 nm",
            "ar800": "Ar I 800.6 nm",
            "cl822": "Cl I 822.2 nm",
            "ar922": "Ar I 922.4 nm",
        },
        fit_excitation_kernel_ids=(
            "ArI_750.4_direct",
            "ArI_763.5_800.6_922.4_shared_upper",
        ),
        modeled_pathway_ids=(
            "ArI_750.4_direct",
            "ArI_763.5_800.6_922.4_shared_upper",
            "ClI_725.7_effective_emitter",
            "ClI_754.7_effective_emitter",
            "Cl2_822.2_dissociative_effective_emitter",
        ),
        held_out_spectra=("cl725", "cl755", "cl822"),
        limitation="The three Cl channels use illustrative effective-emitter curves, not state-resolved data.",
    ),
)


def generate_measurements(case: BenchmarkCase, rng: np.random.Generator) -> None:
    """Explicitly refresh the committed same-model fixtures; ordinary runs only read them."""
    spectra = OESCRModel.from_yaml(case.truth_path).predict_spectra()
    for instrument_id, chords in spectra.items():
        spectrum = chords["chord_0"]
        truth = np.asarray(spectrum["intensity"], dtype=float)
        sigma = np.sqrt((0.015 * truth) ** 2 + (0.0015 * max(float(np.max(truth)), 1.0e-30)) ** 2)
        measured = truth + rng.normal(0.0, sigma)
        destination = case.directory / "measurements" / f"{instrument_id}.csv"
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("w", encoding="utf-8", newline="") as stream:
            for key in ("output_basis", "output_unit", "calibration_reference"):
                stream.write(f"# {key}: {spectrum[key]}\n")
            stream.write("# generator: OESCR truth case with 1.5% point noise and 0.15% peak floor\n")
            stream.write(f"# measurement_seed: {MEASUREMENT_SEED}\n")
            writer = csv.writer(stream)
            writer.writerow(["wavelength_nm", "intensity", "sigma"])
            writer.writerows(
                (f"{wavelength:.8f}", f"{value:.12e}", f"{uncertainty:.12e}")
                for wavelength, value, uncertainty in zip(
                    spectrum["wavelength_nm"], measured, sigma, strict=True,
                )
            )


def _case_from_vector(solver: InverseSolver, vector: np.ndarray) -> dict[str, Any]:
    cfg = deepcopy(solver.case_cfg)
    solver.params.apply_to_case(cfg, vector)
    return cfg


def _objective(solver: InverseSolver, vector: np.ndarray) -> float:
    residual, _ = residual_vector(
        solver.model, _case_from_vector(solver, vector), solver.inv_cfg,
        solver.measurements, solver.windows, collect_details=False,
    )
    return 0.5 * float(np.dot(residual, residual))


def run_cma_es(solver: InverseSolver) -> tuple[np.ndarray, dict[str, Any]]:
    """Optional optimizer comparison with the same bounds and measurement loss."""
    try:
        import cma
    except ImportError as exc:
        raise RuntimeError("--cross-check requires the optional cma package.") from exc
    lower, upper = solver.params.bounds()
    scale = upper - lower
    initial = (solver.params.initial_vector(solver.case_cfg) - lower) / scale

    def decode(normalized: np.ndarray) -> np.ndarray:
        return lower + np.clip(np.asarray(normalized, dtype=float), 0.0, 1.0) * scale

    strategy = cma.CMAEvolutionStrategy(
        np.clip(initial, 0.0, 1.0), 0.22,
        {"bounds": [0.0, 1.0], "popsize": 12, "maxiter": 90,
         "seed": CMA_SEED, "tolfun": 1.0e-12, "tolx": 1.0e-10,
         "verbose": -9, "verb_disp": 0, "verb_log": 0},
    )
    while not strategy.stop():
        candidates = strategy.ask()
        strategy.tell(candidates, [_objective(solver, decode(item)) for item in candidates])
    return decode(np.asarray(strategy.result.xbest, dtype=float)), dict(strategy.stop() or {})


def _predictions(model: OESCRModel, cfg: dict[str, Any]) -> dict[str, dict[str, np.ndarray]]:
    return {
        instrument_id: {
            "wavelength_nm": chords["chord_0"]["wavelength_nm"],
            "intensity": chords["chord_0"]["intensity"],
        }
        for instrument_id, chords in model.predict_spectra(cfg).items()
    }


def _acceptance_assessment(
    *, fit_success: bool, target_full_rank: bool,
    errors: dict[str, dict[str, float]],
    held_out_truth_nrmse: dict[str, float], numerical_difference: float,
) -> dict[str, Any]:
    checks: dict[str, dict[str, Any]] = {
        "optimizer_success": {"value": fit_success, "passed": fit_success},
        "projected_target_jacobian_full_rank": {
            "value": target_full_rank, "passed": target_full_rank,
        },
    }
    for method in (name for name in ("oescr", "cma") if name in errors):
        for parameter in ("te_relative", "ne_relative"):
            value = errors[method][parameter]
            checks[f"{method}_{parameter}"] = {
                "value": value, "operator": "<", "threshold": 0.05,
                "passed": value < 0.05,
            }
        value = held_out_truth_nrmse[method]
        checks[f"{method}_held_out_truth_nrmse"] = {
            "value": value, "operator": "<", "threshold": 0.05,
            "passed": value < 0.05,
        }
    checks["numerical_refinement_relative_l2"] = {
        "value": numerical_difference, "operator": "<", "threshold": 0.01,
        "passed": numerical_difference < 0.01,
    }
    return {"passed": all(check["passed"] for check in checks.values()), "checks": checks}


def _validated_fit_spectra(case: BenchmarkCase, fit: FitResult) -> list[str]:
    selected = {
        instrument_id
        for (instrument_id, _measurement_id), selection in fit.aux.get("fit_pixel_selection", {}).items()
        if selection["selected_count"] > 0
    }
    expected = set(case.feature_labels).difference(case.held_out_spectra)
    if selected != expected:
        raise RuntimeError(
            f"Benchmark role mismatch for {case.key}: selected {sorted(selected)}, "
            f"expected {sorted(expected)}."
        )
    return [name for name in case.feature_labels if name in selected]


def _numerical_refinement(truth: dict[str, Any], predictions: dict[str, Any]) -> dict[str, float]:
    differences: dict[str, float] = {}
    for name in ("energy_grid", "wavelength_grid"):
        cfg = deepcopy(truth)
        if name == "energy_grid":
            cfg["energy_grid"]["n_points"] = 1201
        else:
            cfg.setdefault("numerics", {})["wavelength_refinement_factor"] = 2.0
        refined = _predictions(OESCRModel(cfg), cfg)
        differences[name] = max(
            spectral_relative_l2(predictions[key], reference)
            for key, reference in refined.items()
        )
    return differences


def run_case(case: BenchmarkCase, output_dir: Path, *, cross_check: bool = False) -> dict[str, Any]:
    solver = InverseSolver.from_yaml(case.init_path, case.inverse_path)
    truth = OESCRModel.from_yaml(case.truth_path).cfg
    fit = solver.fit(audit=True)
    case_output = output_dir / case.key
    write_fit_result(fit, case_output)
    configs = {"truth": truth, "initial": solver.case_cfg, "oescr": fit.case_opt}
    costs = {"oescr": fit.cost}
    if cross_check:
        vector, stop = run_cma_es(solver)
        configs["cma"] = _case_from_vector(solver, vector)
        costs["cma"] = _objective(solver, vector)
        save_yaml(
            {"cost": costs["cma"], "seed": CMA_SEED, "stop": stop},
            case_output / "cross_check.yaml",
        )
        save_yaml(rebase_config_paths(configs["cma"], case_output), case_output / "case_cma.yaml")
    parameters = {
        name: {parameter.name: float(get_path(cfg, parameter.path)) for parameter in solver.params.params}
        for name, cfg in configs.items()
    }
    errors = {
        name: {
            "te_relative": abs(values["electron_temperature_eV"] / parameters["truth"]["electron_temperature_eV"] - 1.0),
            "ne_relative": abs(values["electron_density_m3"] / parameters["truth"]["electron_density_m3"] - 1.0),
        }
        for name, values in parameters.items() if name != "truth"
    }
    predictions = {name: _predictions(solver.model, cfg) for name, cfg in configs.items()}
    measurements = {
        key: {"wavelength_nm": items[0].wavelength_nm, "intensity": items[0].intensity}
        for key, items in solver.measurements.items()
    }
    fit_spectra = _validated_fit_spectra(case, fit)
    metrics = {
        name: {
            "fit_nrmse_vs_measurement": aggregate_spectral_relative_l2(prediction, measurements, fit_spectra),
            "held_out_nrmse_vs_truth": aggregate_spectral_relative_l2(prediction, predictions["truth"], case.held_out_spectra),
            "held_out_nrmse_vs_measurement": aggregate_spectral_relative_l2(prediction, measurements, case.held_out_spectra),
        }
        for name, prediction in predictions.items() if name != "truth"
    }
    refinement = _numerical_refinement(truth, predictions["truth"])
    identifiability = fit.identifiability or {}
    targets = identifiability.get("projected_target", identifiability)
    target_full_rank = bool(targets and targets["rank_estimate"] == targets["n_parameters"])
    acceptance = _acceptance_assessment(
        fit_success=fit.success, target_full_rank=target_full_rank, errors=errors,
        held_out_truth_nrmse={name: values["held_out_nrmse_vs_truth"] for name, values in metrics.items()},
        numerical_difference=max(refinement.values()),
    )
    summary = {
        "case": case.key, "status": "pass" if acceptance["passed"] else "fail",
        "interpretation": "synthetic_same_model_recovery",
        "measurement_input": "committed_synthetic_narrow_spectra",
        "fit_result": f"{case.key}/result.yaml",
        "fit_spectra": fit_spectra, "held_out_spectra": list(case.held_out_spectra),
        "fit_excitation_kernel_ids": list(case.fit_excitation_kernel_ids),
        "modeled_excitation_pathway_ids": list(case.modeled_pathway_ids),
        "parameters": parameters, "relative_errors": errors, "spectral_metrics": metrics,
        "objective": costs, "numerical_refinement": refinement,
        "acceptance": acceptance, "limitation": case.limitation,
    }
    return summary


def _write_run_summary(results: list[dict[str, Any]], output: Path) -> None:
    save_yaml({"cases": results}, output / "summary.yaml")
    with (output / "summary.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=[
            "case", "method", "status", "te_relative_error", "ne_relative_error",
            "held_out_nrmse_vs_truth", "cost",
        ])
        writer.writeheader()
        for result in results:
            for method, cost in result["objective"].items():
                writer.writerow({
                    "case": result["case"], "method": method, "status": result["status"],
                    "te_relative_error": result["relative_errors"][method]["te_relative"],
                    "ne_relative_error": result["relative_errors"][method]["ne_relative"],
                    "held_out_nrmse_vs_truth": result["spectral_metrics"][method]["held_out_nrmse_vs_truth"],
                    "cost": cost,
                })


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--case", choices=[case.key for case in CASES], action="append")
    parser.add_argument("--cross-check", action="store_true", help="Also compare the fit with optional CMA-ES.")
    parser.add_argument(
        "--generate-fixtures", action="store_true",
        help="Explicitly overwrite the committed synthetic measurement fixtures before fitting.",
    )
    args = parser.parse_args()
    cases = [case for case in CASES if args.case is None or case.key in args.case]
    if args.generate_fixtures:
        rng = np.random.default_rng(MEASUREMENT_SEED)
        for case in CASES:
            generate_measurements(case, rng)
    results = []
    for case in cases:
        result = run_case(case, args.out, cross_check=args.cross_check)
        results.append(result)
        print(f"{case.key}: {result['status']} ({args.out / case.key / 'result.yaml'})")
    _write_run_summary(results, args.out)
    if any(result["status"] != "pass" for result in results):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
